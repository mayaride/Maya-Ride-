import React, { useState, useEffect } from 'react';
import { useRide } from '../../context/RideContext';
import { Driver, Ride, VehicleType } from '../../types';
import { InteractiveMap } from '../InteractiveMap';
import { DriverAuthModal } from '../auth/DriverAuthModal';
import confetti from 'canvas-confetti';
import {
  Car,
  Bike,
  ShieldCheck,
  Power,
  Navigation,
  Clock,
  CheckCircle,
  XCircle,
  DollarSign,
  TrendingUp,
  Award,
  Wallet,
  Phone,
  MessageSquare,
  AlertCircle,
  FileText,
  UserPlus,
  KeyRound,
  RotateCcw,
  Sparkles,
  ArrowUpRight,
  LogIn,
  LogOut,
  Edit3,
  ShieldAlert,
  Bell,
  LocateFixed,
  ExternalLink,
  Upload,
  CheckCircle2,
  Calendar,
  ArrowUp,
  ArrowDownLeft,
} from 'lucide-react';

export const DriverApp: React.FC = () => {
  const {
    currentUser,
    drivers,
    rides,
    fareSettings,
    activeDriver,
    acceptRide,
    rejectRide,
    updateRideStatus,
    toggleDriverOnline,
    registerDriver,
    updateDriverProfile,
    uploadAndSetDriverDocument,
    requestDriverPayout,
    getDriverDailySummary,
    getDriverMonthlySummary,
    notifications,
    markNotificationRead,
    transactions,
    logoutAccount,
    switchRole,
  } = useRide();

  // Navigation tab within Driver App
  const [driverTab, setDriverTab] = useState<'duty' | 'earnings' | 'vehicle'>('duty');

  // Driver Authentication Modal state
  const [showDriverAuthModal, setShowDriverAuthModal] = useState(false);

  // Selected driver switch (so user can test Bike, Auto, or Car driver quickly)
  const [selectedDriverId, setSelectedDriverId] = useState<string>(
    activeDriver?.id || drivers[0]?.id || ''
  );

  const currentDriver = drivers.find((d) => d.id === selectedDriverId) || activeDriver || drivers[0];

  // Inline Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editForm, setEditForm] = useState({
    name: currentDriver?.name || '',
    phone: currentDriver?.phone || '',
    vehicleModel: currentDriver?.vehicleModel || '',
    vehicleNumber: currentDriver?.vehicleNumber || '',
    licenseNumber: currentDriver?.licenseNumber || '',
  });
  const [driverProfileSavedNotice, setDriverProfileSavedNotice] = useState<string | null>(null);

  // Driver Registration modal state
  const [showRegModal, setShowRegModal] = useState(false);
  const [regForm, setRegForm] = useState({
    name: currentUser.name || 'Captain Vikram Patel',
    phone: currentUser.phone || '+91 99360 55667',
    vehicleType: 'car' as VehicleType,
    vehicleModel: 'Maruti Suzuki Dzire AC',
    vehicleNumber: 'UP-96-C-9011',
    licenseNumber: 'UP962022003411',
  });

  // OTP input for starting ride
  const [inputOtp, setInputOtp] = useState('');
  const [otpError, setOtpError] = useState(false);
  const [collectPaymentModal, setCollectPaymentModal] = useState<Ride | null>(null);

  // Driver notifications, GPS sync, payout & document upload states
  const [showNotifDrawer, setShowNotifDrawer] = useState(false);
  const [driverNotice, setDriverNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSyncingGps, setIsSyncingGps] = useState(false);
  const [uploadingDocType, setUploadingDocType] = useState<'license' | 'rc' | null>(null);
  const [isPayoutLoading, setIsPayoutLoading] = useState(false);

  // Incoming ride alert countdown timer
  const [incomingTimer, setIncomingTimer] = useState(25);

  const driverNotifications = notifications.filter(
    (n) => n.userId === currentDriver?.id || n.role === 'driver' || n.role === 'all'
  );
  const unreadNotifCount = driverNotifications.filter((n) => !n.read).length;
  const driverTransactions = transactions.filter((t) => t.userId === currentDriver?.id);
  const dailySummary = currentDriver
    ? getDriverDailySummary(currentDriver.id)
    : { trips: 0, grossFare: 0, netEarnings: 0, commission: 0, avgRating: 4.9 };
  const monthlySummary = currentDriver
    ? getDriverMonthlySummary(currentDriver.id)
    : { trips: 0, grossFare: 0, netEarnings: 0, commission: 0 };
  const activeCommissionRate =
    fareSettings.find((f) => f.vehicleType === currentDriver?.vehicleType)?.commissionPercent ??
    (currentDriver?.vehicleType === 'bike' ? 12 : currentDriver?.vehicleType === 'auto' ? 15 : 18);

  // Find incoming requested ride matching this driver's vehicle type
  const incomingRide = rides.find(
    (r) =>
      r.status === 'requested' &&
      r.vehicleType === currentDriver?.vehicleType &&
      currentDriver?.isOnline &&
      currentDriver?.approvalStatus === 'approved'
  );

  // Countdown timer for incoming ride
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (incomingRide) {
      setIncomingTimer(25);
      interval = setInterval(() => {
        setIncomingTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [incomingRide?.id]);

  // Find active ride assigned to current driver
  const assignedRide = rides.find(
    (r) =>
      r.driverId === currentDriver?.id &&
      (r.status === 'accepted' || r.status === 'arriving' || r.status === 'in_progress')
  );

  // Driver trips history
  const driverTrips = rides.filter(
    (r) => r.driverId === currentDriver?.id && r.status === 'completed'
  );

  // Handle Driver Registration submission
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newDriver = await registerDriver(regForm);
    setSelectedDriverId(newDriver.id);
    setShowRegModal(false);
    setDriverNotice({
      type: 'success',
      text: 'Captain registration submitted! Your account stays Pending until approved by Maya Admin.',
    });
  };

  // Sync live GPS coordinates of captain
  const handleSyncDriverGps = () => {
    if (!currentDriver || !navigator.geolocation) {
      setDriverNotice({ type: 'error', text: 'Device geolocation is not available in this browser.' });
      return;
    }
    setIsSyncingGps(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        setIsSyncingGps(false);
        const lat = Number(pos.coords.latitude.toFixed(5));
        const lng = Number(pos.coords.longitude.toFixed(5));
        await updateDriverProfile(currentDriver.id, {
          currentLocation: {
            name: `Captain Live GPS (${lat}° N, ${lng}° E)`,
            address: `Karwi / Chitrakoot Sector (±${Math.round(pos.coords.accuracy || 20)}m)`,
            lat,
            lng,
            isGpsDetected: true,
            category: 'gps',
          },
        });
        setDriverNotice({ type: 'success', text: `GPS synced: ${lat}° N, ${lng}° E` });
        setTimeout(() => setDriverNotice(null), 4000);
      },
      (err) => {
        setIsSyncingGps(false);
        setDriverNotice({
          type: 'error',
          text:
            err.code === err.PERMISSION_DENIED
              ? 'Location permission denied. Enable browser GPS permission to sync captain position.'
              : 'Unable to acquire GPS signal right now.',
        });
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // Handle Document File Upload (Licence or Vehicle RC)
  const handleDocFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>,
    docType: 'license' | 'rc'
  ) => {
    const file = e.target.files?.[0];
    if (!file || !currentDriver) return;
    setUploadingDocType(docType);
    try {
      await uploadAndSetDriverDocument(currentDriver.id, file, docType);
      setDriverNotice({
        type: 'success',
        text: `${docType === 'license' ? 'Driving Licence' : 'Vehicle RC'} uploaded & queued for Admin verification.`,
      });
      setTimeout(() => setDriverNotice(null), 4500);
    } catch {
      setDriverNotice({ type: 'error', text: 'Failed to upload document. Please try again.' });
    } finally {
      setUploadingDocType(null);
    }
  };

  // Handle OTP verification to start ride
  const handleVerifyOtpAndStart = async () => {
    if (!assignedRide) return;
    if (inputOtp.trim() === assignedRide.otp) {
      setOtpError(false);
      setInputOtp('');
      await updateRideStatus(assignedRide.id, 'in_progress');
    } else {
      setOtpError(true);
    }
  };

  // Complete ride and open payment dialog
  const handleCompleteRide = async () => {
    if (!assignedRide) return;
    await updateRideStatus(assignedRide.id, 'completed', { paymentStatus: 'paid' });
    setCollectPaymentModal(assignedRide);
    confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
  };

  // Real Payout request backed by RideContext
  const handleRequestPayout = async () => {
    if (!currentDriver) return;
    if ((currentDriver.walletBalance || 0) <= 0) {
      setDriverNotice({ type: 'error', text: 'No withdrawable balance available right now.' });
      return;
    }
    setIsPayoutLoading(true);
    try {
      const amount = currentDriver.walletBalance;
      await requestDriverPayout(currentDriver.id, amount);
      setDriverNotice({
        type: 'success',
        text: `Payout request of ₹${amount} processed to your payout ledger.`,
      });
      setTimeout(() => setDriverNotice(null), 4500);
    } catch (err: any) {
      setDriverNotice({ type: 'error', text: err?.message || 'Payout failed.' });
    } finally {
      setIsPayoutLoading(false);
    }
  };

  return (
    <div className="w-full flex justify-center py-4 px-2 sm:px-4">
      {/* Mobile Shell Container */}
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col min-h-[720px] text-slate-100">
        {/* Mobile Header Bar */}
        <div className="px-5 py-4 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 font-black flex items-center justify-center text-sm shadow-md">
              🚖
            </div>
            <div>
              <h2 className="font-bold text-sm tracking-tight text-white flex items-center gap-1.5">
                Maya Captain <span className="text-[10px] text-amber-400 font-semibold">DRIVER</span>
              </h2>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-400 truncate max-w-[130px]">
                  {currentDriver?.name}
                </span>
                <span className="text-[10px] font-bold uppercase text-amber-300 px-1 rounded bg-amber-400/10">
                  {currentDriver?.vehicleType}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions: Notifications, Switch or Captain Sign In */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShowNotifDrawer(!showNotifDrawer)}
              className={`relative p-1.5 rounded-lg border transition-all ${
                showNotifDrawer
                  ? 'bg-amber-400/20 text-amber-400 border-amber-400/40'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
              title="Captain Notifications"
            >
              <Bell className="w-3.5 h-3.5" />
              {unreadNotifCount > 0 && (
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-400 text-slate-950 font-black text-[8px] flex items-center justify-center">
                  {unreadNotifCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowDriverAuthModal(true)}
              className="px-2 py-1 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[11px] font-semibold flex items-center gap-1 hover:bg-amber-400/30"
              title="Captain Sign In / Register"
            >
              <LogIn className="w-3 h-3 text-amber-400" />
              <span>Login</span>
            </button>
            <select
              value={currentDriver?.id}
              onChange={(e) => {
                setSelectedDriverId(e.target.value);
                const chosen = drivers.find((d) => d.id === e.target.value);
                if (chosen) {
                  setEditForm({
                    name: chosen.name,
                    phone: chosen.phone,
                    vehicleModel: chosen.vehicleModel,
                    vehicleNumber: chosen.vehicleNumber,
                    licenseNumber: chosen.licenseNumber,
                  });
                }
              }}
              className="bg-slate-900 border border-slate-800 text-[11px] text-amber-400 font-semibold rounded-lg px-1.5 py-1 focus:outline-none max-w-[100px]"
            >
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name.split(' ')[0]} ({d.vehicleType.toUpperCase()})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Captain Notifications Drawer */}
        {showNotifDrawer && (
          <div className="bg-slate-950 border-b border-slate-800 p-3 space-y-2 max-h-56 overflow-y-auto">
            <div className="flex items-center justify-between text-[11px] font-bold uppercase text-amber-400">
              <span>Captain Alerts ({unreadNotifCount} unread)</span>
              <button
                type="button"
                onClick={() => setShowNotifDrawer(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            {driverNotifications.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-2">No captain alerts yet.</p>
            ) : (
              driverNotifications.slice(0, 6).map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => markNotificationRead(n.id)}
                  className={`w-full text-left p-2 rounded-xl border text-xs ${
                    n.read
                      ? 'bg-slate-900/60 border-slate-800 text-slate-400'
                      : 'bg-amber-400/10 border-amber-400/30 text-slate-100'
                  }`}
                >
                  <div className="flex justify-between font-bold text-white">
                    <span>{n.title}</span>
                    <span className="text-[9px] text-slate-500">
                      {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[11px] mt-0.5">{n.body}</p>
                </button>
              ))
            )}
          </div>
        )}

        {/* Driver Feedback Banner */}
        {driverNotice && (
          <div
            className={`p-2.5 border-b text-xs flex items-center justify-between gap-2 px-4 ${
              driverNotice.type === 'success'
                ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-200'
                : 'bg-red-500/20 border-red-500/30 text-red-200'
            }`}
          >
            <span className="text-[11px]">{driverNotice.text}</span>
            <button
              type="button"
              onClick={() => setDriverNotice(null)}
              className="font-bold text-xs"
            >
              ✕
            </button>
          </div>
        )}

        {/* Approval Status Banner (If Pending or Rejected) */}
        {currentDriver?.approvalStatus !== 'approved' && (
          <div className="p-3 bg-amber-500/15 border-b border-amber-500/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-amber-300">
              <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
              <div>
                <span className="font-bold block">
                  {currentDriver?.approvalStatus === 'rejected'
                    ? 'Account Rejected / Suspended'
                    : 'Pending Admin Approval'}
                </span>
                <span className="text-[10px] text-slate-300">
                  Must be approved & documents verified in Admin Dashboard before duty
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => switchRole('admin')}
              className="px-2 py-1 rounded bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-[10px] shrink-0"
            >
              Admin Review
            </button>
          </div>
        )}

        {/* Tab 1: ON DUTY / RIDE RADAR */}
        {driverTab === 'duty' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Online / Offline Availability Toggle Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`w-3 h-3 rounded-full ${
                      currentDriver?.isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
                    }`}
                  />
                  <h3 className="font-bold text-sm text-white">
                    {currentDriver?.isOnline ? 'You Are Online' : 'You Are Offline'}
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {currentDriver?.approvalStatus === 'pending'
                    ? 'Account pending Admin approval (Cannot go online yet)'
                    : currentDriver?.isOnline
                    ? `Ready to accept ${currentDriver?.vehicleType.toUpperCase()} rides`
                    : 'Turn on duty to start receiving ride alerts'}
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (currentDriver?.approvalStatus !== 'approved') {
                    setDriverNotice({
                      type: 'error',
                      text: 'Action Blocked: Captain account & documents must be approved by Admin before going online.',
                    });
                    return;
                  }
                  toggleDriverOnline(currentDriver.id, !currentDriver.isOnline);
                }}
                className={`p-3 rounded-2xl border transition-all ${
                  currentDriver?.approvalStatus !== 'approved'
                    ? 'bg-slate-900 text-slate-600 border-slate-800 cursor-not-allowed opacity-60'
                    : currentDriver?.isOnline
                    ? 'bg-emerald-500 text-white border-emerald-400 shadow-lg shadow-emerald-500/20'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
                title={currentDriver?.approvalStatus !== 'approved' ? 'Pending Admin Approval' : 'Toggle Online Duty'}
              >
                <Power className="w-5 h-5" />
              </button>
            </div>

            {/* Real Device GPS Sync Strip */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 text-xs">
              <div className="min-w-0">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">
                  Captain GPS Location
                </span>
                <p className="text-[11px] text-slate-200 truncate">
                  {currentDriver?.currentLocation
                    ? currentDriver.currentLocation.name
                    : 'GPS not synced yet (No fake coordinates shown)'}
                </p>
              </div>
              <button
                type="button"
                onClick={handleSyncDriverGps}
                disabled={isSyncingGps}
                className="px-2.5 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-[11px] font-semibold flex items-center gap-1 shrink-0"
              >
                <LocateFixed className="w-3.5 h-3.5" />
                <span>{isSyncingGps ? 'Syncing...' : 'Sync GPS'}</span>
              </button>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Today</span>
                <p className="text-base font-black text-amber-400">
                  ₹{dailySummary.netEarnings || currentDriver?.todayEarnings || 0}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Rating</span>
                <p className="text-base font-black text-white flex items-center justify-center gap-1">
                  ⭐ {currentDriver?.rating || 4.9}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Trips</span>
                <p className="text-base font-black text-white">
                  {currentDriver?.totalTrips || 0}
                </p>
              </div>
            </div>

            {/* INCOMING RIDE REQUEST ALERT (POPUPS/RADAR) */}
            {incomingRide && !assignedRide && (
              <div className="p-4 rounded-2xl bg-gradient-to-b from-amber-500/20 via-slate-950 to-slate-950 border-2 border-amber-400 shadow-2xl space-y-3.5 animate-bounce-subtle">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
                    <span className="text-xs font-black uppercase text-amber-300 tracking-wider">
                      Incoming Ride Alert!
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-xs">
                    {incomingTimer}s
                  </span>
                </div>

                {/* Earnings Highlight */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase block">Your Net Payout</span>
                    <p className="text-xl font-black text-emerald-400">
                      ₹{incomingRide.fare - incomingRide.platformFee}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase block">Distance</span>
                    <p className="text-xs font-bold text-white">
                      {incomingRide.distanceKm} km (~{incomingRide.estimatedMinutes}m)
                    </p>
                  </div>
                </div>

                {/* Passenger & Route info */}
                <div className="text-xs space-y-2 text-slate-300">
                  <div className="flex items-center gap-2 font-semibold text-white">
                    <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-[10px] text-amber-400">
                      👤
                    </div>
                    <span>{incomingRide.customerName}</span>
                    <span className="text-[10px] text-slate-400">({incomingRide.paymentMethod.toUpperCase()})</span>
                  </div>

                  <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800/80 space-y-1.5 text-[11px]">
                    <p className="truncate text-cyan-300">
                      <span className="text-slate-400 mr-1">PICKUP:</span>
                      {incomingRide.pickupAddress}
                    </p>
                    <p className="truncate text-amber-300">
                      <span className="text-slate-400 mr-1">DROP:</span>
                      {incomingRide.dropAddress}
                    </p>
                  </div>
                </div>

                {/* Action Buttons: Accept & Reject */}
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => rejectRide(incomingRide.id, currentDriver.id)}
                    className="flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-red-400 border border-red-500/30 text-xs font-bold"
                  >
                    Decline
                  </button>

                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await acceptRide(incomingRide.id, currentDriver.id);
                      } catch (err: any) {
                        setDriverNotice({
                          type: 'error',
                          text: err?.message || 'Unable to accept ride right now.',
                        });
                      }
                    }}
                    className="flex-2 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-lg shadow-amber-400/20 active:scale-95 transition-all"
                  >
                    Accept Ride ({incomingTimer}s)
                  </button>
                </div>
              </div>
            )}

            {/* ASSIGNED ACTIVE TRIP VIEW */}
            {assignedRide ? (
              <div className="space-y-4">
                <InteractiveMap
                  pickup={assignedRide.pickupCoords}
                  drop={assignedRide.dropCoords}
                  vehicleType={assignedRide.vehicleType}
                  status={assignedRide.status}
                  height="h-56"
                />

                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950">
                      Active: {assignedRide.status.replace('_', ' ')}
                    </span>
                    <span className="text-xs font-mono text-slate-400">
                      {assignedRide.id}
                    </span>
                  </div>

                  {/* Customer info */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <div>
                      <h4 className="font-bold text-white text-sm">
                        {assignedRide.customerName}
                      </h4>
                      <p className="text-xs text-slate-400">
                        {assignedRide.customerPhone}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${assignedRide.customerPhone}`}
                        onClick={() =>
                          setDriverNotice({
                            type: 'success',
                            text: `Passenger Contact: ${assignedRide.customerPhone}`,
                          })
                        }
                        className="p-2 rounded-xl bg-slate-800 text-emerald-400 hover:bg-slate-700"
                        title="Call Passenger"
                      >
                        <Phone className="w-4 h-4" />
                      </a>
                      <button
                        type="button"
                        onClick={() =>
                          setDriverNotice({
                            type: 'success',
                            text: `Quick alert sent to ${assignedRide.customerName}: "Captain is on the way!"`,
                          })
                        }
                        className="p-2 rounded-xl bg-slate-800 text-cyan-400 hover:bg-slate-700"
                        title="Send Quick Alert"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* External Turn-by-Turn Google Maps Navigation */}
                  <a
                    href={
                      assignedRide.status === 'in_progress'
                        ? `https://www.google.com/maps/dir/?api=1&origin=${assignedRide.pickupCoords.lat},${assignedRide.pickupCoords.lng}&destination=${assignedRide.dropCoords.lat},${assignedRide.dropCoords.lng}&travelmode=driving`
                        : `https://www.google.com/maps/dir/?api=1&destination=${assignedRide.pickupCoords.lat},${assignedRide.pickupCoords.lng}&travelmode=driving`
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>
                      {assignedRide.status === 'in_progress'
                        ? 'Navigate to Drop in Google Maps'
                        : 'Navigate to Pickup in Google Maps'}
                    </span>
                  </a>

                  {/* Progressive Stage Actions */}
                  {assignedRide.status === 'accepted' && (
                    <div className="space-y-2">
                      <p className="text-xs text-slate-300">
                        Drive to pickup: <span className="font-bold text-cyan-400">{assignedRide.pickupAddress}</span>
                      </p>
                      <button
                        type="button"
                        onClick={() => updateRideStatus(assignedRide.id, 'arriving')}
                        className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-md"
                      >
                        I Have Arrived at Pickup
                      </button>
                    </div>
                  )}

                  {assignedRide.status === 'arriving' && (
                    <div className="space-y-3">
                      <p className="text-xs text-slate-300">
                        Ask passenger for their <span className="text-amber-400 font-bold">4-digit Start OTP</span> to verify and start ride:
                      </p>

                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={4}
                          placeholder="Enter 4-Digit OTP"
                          value={inputOtp}
                          onChange={(e) => setInputOtp(e.target.value)}
                          className={`flex-1 bg-slate-900 border rounded-xl px-3 py-2 text-center text-sm font-mono tracking-widest text-white focus:outline-none ${
                            otpError ? 'border-red-500' : 'border-slate-700 focus:border-amber-400'
                          }`}
                        />
                        <button
                          type="button"
                          onClick={handleVerifyOtpAndStart}
                          className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
                        >
                          Verify & Start
                        </button>
                      </div>
                      {otpError && (
                        <p className="text-[11px] text-red-400 font-semibold">
                          Incorrect OTP! The passenger has OTP: {assignedRide.otp}
                        </p>
                      )}
                    </div>
                  )}

                  {assignedRide.status === 'in_progress' && (
                    <div className="space-y-2">
                      <div className="p-2.5 rounded-xl bg-slate-900 text-xs space-y-1">
                        <span className="text-[10px] text-slate-400 uppercase">Navigating To Drop</span>
                        <p className="font-bold text-amber-300">{assignedRide.dropAddress}</p>
                      </div>

                      <button
                        type="button"
                        onClick={handleCompleteRide}
                        className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20"
                      >
                        Destination Reached • Complete Ride
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              !incomingRide && (
                /* Idle Map & Waiting state */
                <div className="space-y-4">
                  <InteractiveMap
                    vehicleType={currentDriver?.vehicleType}
                    height="h-56"
                  />
                  <div className="text-center py-6 p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center mx-auto text-amber-400 text-lg">
                      📡
                    </div>
                    <h4 className="font-bold text-white text-sm">
                      {currentDriver?.isOnline ? 'Scanning for Rides...' : 'You are currently offline'}
                    </h4>
                    <p className="text-xs text-slate-400 max-w-xs mx-auto">
                      {currentDriver?.isOnline
                        ? 'Stay online to receive ride bookings. Open Customer App to book a ride and test live acceptance!'
                        : 'Switch on your duty above to start receiving bookings.'}
                    </p>
                    <button
                      type="button"
                      onClick={() => switchRole('customer')}
                      className="mt-2 text-xs text-amber-400 hover:text-amber-300 underline font-semibold"
                    >
                      Go to Customer App to book a ride
                    </button>
                  </div>
                </div>
              )
            )}
          </div>
        )}

        {/* Tab 2: DRIVER EARNINGS DASHBOARD & REPORTS */}
        {driverTab === 'earnings' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Balance Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-tr from-slate-950 via-slate-900 to-amber-950/40 border border-amber-400/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-amber-300 tracking-wider">
                  Withdrawable Wallet Balance
                </span>
                <Wallet className="w-4 h-4 text-amber-400" />
              </div>
              <p className="text-3xl font-black text-white">
                ₹{currentDriver?.walletBalance || 0}
              </p>
              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-400">Bank / UPI Settlement</span>
                <button
                  type="button"
                  disabled={isPayoutLoading || (currentDriver?.walletBalance || 0) <= 0}
                  onClick={handleRequestPayout}
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-md"
                >
                  {isPayoutLoading ? 'Processing...' : 'Withdraw'} <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Daily & Monthly Performance Reports */}
            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                <span className="text-[10px] uppercase font-bold text-cyan-400 flex items-center gap-1">
                  <Calendar className="w-3 h-3" /> Today&apos;s Report
                </span>
                <p className="text-lg font-black text-white">
                  ₹{dailySummary.netEarnings}
                </p>
                <div className="text-[10px] text-slate-400 space-y-0.5">
                  <div className="flex justify-between">
                    <span>Trips:</span>
                    <span className="text-slate-200 font-bold">{dailySummary.trips}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Commission:</span>
                    <span className="text-red-400">-₹{dailySummary.commission}</span>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                <span className="text-[10px] uppercase font-bold text-amber-400 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" /> Monthly Report
                </span>
                <p className="text-lg font-black text-emerald-400">
                  ₹{monthlySummary.netEarnings}
                </p>
                <div className="text-[10px] text-slate-400 space-y-0.5">
                  <div className="flex justify-between">
                    <span>Trips:</span>
                    <span className="text-slate-200 font-bold">{monthlySummary.trips}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gross Fare:</span>
                    <span className="text-slate-200">₹{monthlySummary.grossFare}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Lifetime Performance Breakdown */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-slate-400">Lifetime Net Earned</span>
                <p className="text-lg font-black text-emerald-400">
                  ₹{currentDriver?.totalEarnings || 0}
                </p>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-slate-400">Completed Trips</span>
                <p className="text-lg font-black text-white">
                  {currentDriver?.totalTrips || 0}
                </p>
              </div>
            </div>

            {/* Commission Breakdown Note */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>Maya Platform Commission Rate</span>
                <span className="text-amber-400 font-bold">
                  {activeCommissionRate}%
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Customer Satisfaction Rating</span>
                <span className="text-amber-400 font-bold">
                  ⭐ {currentDriver?.rating || 4.9} / 5.0
                </span>
              </div>
            </div>

            {/* Payout & Earnings Ledger */}
            {driverTransactions.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-bold text-xs text-white uppercase tracking-wider">
                  Payout & Settlement History
                </h4>
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {driverTransactions.slice(0, 6).map((t) => (
                    <div
                      key={t.id}
                      className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div className="min-w-0">
                        <p className="text-slate-200 font-medium truncate">{t.description}</p>
                        <span className="text-[10px] text-slate-500">
                          {new Date(t.createdAt).toLocaleDateString()} • {t.status.toUpperCase()}
                        </span>
                      </div>
                      <span className="font-bold text-amber-300 shrink-0 ml-2">
                        ₹{t.amount}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recent Trips History */}
            <div className="space-y-2">
              <h4 className="font-bold text-xs text-white uppercase tracking-wider">
                Recent Completed Trips
              </h4>
              {driverTrips.length === 0 ? (
                <p className="text-xs text-slate-500 py-3 text-center">
                  No trips completed yet today.
                </p>
              ) : (
                driverTrips.slice(0, 5).map((trip) => (
                  <div
                    key={trip.id}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1"
                  >
                    <div className="flex justify-between font-semibold">
                      <span className="text-white">{trip.customerName}</span>
                      <span className="text-emerald-400">
                        +₹{trip.fare - trip.platformFee}
                      </span>
                    </div>
                    <p className="text-slate-400 text-[11px] truncate">
                      {trip.pickupAddress} → {trip.dropAddress}
                    </p>
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>{new Date(trip.createdAt).toLocaleTimeString()}</span>
                      <span>Comm: -₹{trip.platformFee}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 3: VEHICLE & CAPTAIN DETAILS */}
        {driverTab === 'vehicle' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {driverProfileSavedNotice && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{driverProfileSavedNotice}</span>
              </div>
            )}

            {/* Profile Overview Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center gap-3">
                <img
                  src={currentDriver?.avatar || 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150'}
                  alt={currentDriver?.name}
                  className="w-14 h-14 rounded-2xl object-cover ring-2 ring-amber-400"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-white text-base truncate">{currentDriver?.name}</h3>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded uppercase font-bold border ${
                        currentDriver?.approvalStatus === 'approved'
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          : 'bg-amber-400/20 text-amber-300 border-amber-400/30'
                      }`}
                    >
                      {currentDriver?.approvalStatus}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 truncate">{currentDriver?.phone}</p>
                  <p className="text-[11px] text-amber-400/90 truncate">{currentDriver?.email}</p>
                </div>
              </div>

              {currentDriver?.approvalStatus === 'pending' && (
                <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] space-y-1">
                  <span className="font-bold flex items-center gap-1 text-amber-400">
                    <Clock className="w-3.5 h-3.5" /> Pending Admin Approval
                  </span>
                  <p className="text-slate-300 leading-tight">
                    Driver accounts must remain pending until approved by Admin. Your account cannot accept rides until approved.
                  </p>
                </div>
              )}

              <div className="border-t border-slate-900 pt-3 space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Vehicle Category</span>
                  <span className="font-bold text-amber-400 uppercase">
                    {currentDriver?.vehicleType}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Vehicle Model</span>
                  <span className="text-white font-medium">{currentDriver?.vehicleModel}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Registration Plate (UP-96)</span>
                  <span className="font-mono text-white px-2 py-0.5 rounded bg-slate-900 border border-slate-800 font-bold">
                    {currentDriver?.vehicleNumber}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Driving License Number</span>
                  <span className="font-mono text-amber-300">{currentDriver?.licenseNumber}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-900 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditingProfile(!isEditingProfile);
                    setEditForm({
                      name: currentDriver?.name || '',
                      phone: currentDriver?.phone || '',
                      vehicleModel: currentDriver?.vehicleModel || '',
                      vehicleNumber: currentDriver?.vehicleNumber || '',
                      licenseNumber: currentDriver?.licenseNumber || '',
                    });
                  }}
                  className="text-amber-400 hover:text-amber-300 text-xs font-semibold flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditingProfile ? 'Cancel Editing' : 'Edit Captain Profile & Vehicle'}</span>
                </button>
              </div>

              {/* Edit Driver Profile Form */}
              {isEditingProfile && (
                <div className="p-3 mt-2 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5 text-xs">
                  <h4 className="font-bold text-white text-xs">Edit Captain Profile</h4>
                  <div>
                    <label className="text-slate-400 block mb-1 text-[11px]">Full Name</label>
                    <input
                      type="text"
                      value={editForm.name}
                      onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1 text-[11px]">Mobile Phone</label>
                    <input
                      type="tel"
                      value={editForm.phone}
                      onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1 text-[11px]">Driving License Number</label>
                    <input
                      type="text"
                      value={editForm.licenseNumber}
                      onChange={(e) => setEditForm({ ...editForm, licenseNumber: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-amber-400 font-mono uppercase"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1 text-[11px]">Vehicle Make & Model</label>
                    <input
                      type="text"
                      value={editForm.vehicleModel}
                      onChange={(e) => setEditForm({ ...editForm, vehicleModel: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1 text-[11px]">Vehicle Plate (UP-96)</label>
                    <input
                      type="text"
                      value={editForm.vehicleNumber}
                      onChange={(e) => setEditForm({ ...editForm, vehicleNumber: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-amber-400 font-mono uppercase"
                    />
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsEditingProfile(false)}
                      className="flex-1 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-semibold text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!editForm.name.trim() || !editForm.phone.trim()) return;
                        await updateDriverProfile(currentDriver.id, editForm);
                        setIsEditingProfile(false);
                        setDriverProfileSavedNotice('Captain profile and vehicle updated successfully!');
                        setTimeout(() => setDriverProfileSavedNotice(null), 3500);
                      }}
                      className="flex-1 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* KYC Document Verification & Uploads Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-400" /> KYC Document Verification
                </span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full uppercase font-bold border ${
                    currentDriver?.documentStatus === 'verified'
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      : currentDriver?.documentStatus === 'rejected'
                      ? 'bg-red-500/20 text-red-400 border-red-500/30'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  }`}
                >
                  {currentDriver?.documentStatus || 'pending'}
                </span>
              </div>

              {currentDriver?.documentRejectionReason && currentDriver?.documentStatus === 'rejected' && (
                <div className="p-2.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-200 text-[11px]">
                  Admin Rejection Reason: {currentDriver.documentRejectionReason}
                </div>
              )}

              <div className="grid grid-cols-2 gap-2.5 text-xs">
                {/* Driving Licence Upload */}
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    Driving Licence
                  </span>
                  {currentDriver?.licenseDocUrl && (
                    <img
                      src={currentDriver.licenseDocUrl}
                      alt="Driving Licence"
                      className="w-full h-20 object-cover rounded-lg border border-slate-700"
                    />
                  )}
                  <label className="w-full py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-[11px] flex items-center justify-center gap-1 cursor-pointer">
                    <Upload className="w-3 h-3" />
                    <span>{uploadingDocType === 'license' ? 'Uploading...' : 'Upload DL'}</span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      className="hidden"
                      onChange={(e) => handleDocFileChange(e, 'license')}
                    />
                  </label>
                </div>

                {/* Vehicle RC Upload */}
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    Vehicle RC
                  </span>
                  {currentDriver?.vehicleRcDocUrl && (
                    <img
                      src={currentDriver.vehicleRcDocUrl}
                      alt="Vehicle RC"
                      className="w-full h-20 object-cover rounded-lg border border-slate-700"
                    />
                  )}
                  <label className="w-full py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-[11px] flex items-center justify-center gap-1 cursor-pointer">
                    <Upload className="w-3 h-3" />
                    <span>{uploadingDocType === 'rc' ? 'Uploading...' : 'Upload RC'}</span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      className="hidden"
                      onChange={(e) => handleDocFileChange(e, 'rc')}
                    />
                  </label>
                </div>
              </div>
              <p className="text-[10px] text-slate-500">
                Uploads to Firebase Storage when permitted, with local base64 preview fallback.
              </p>
            </div>

            {/* Account & Portal Actions */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => setShowDriverAuthModal(true)}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/30 text-amber-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-amber-400" />
                <span>Captain Sign In / Register (Firebase Auth)</span>
              </button>

              <button
                type="button"
                onClick={() => setShowRegModal(true)}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold flex items-center justify-center gap-2"
              >
                <UserPlus className="w-4 h-4 text-amber-400" />
                <span>Quick Add New Captain Profile</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  await logoutAccount();
                  setDriverProfileSavedNotice('Signed out of captain session.');
                  setTimeout(() => setDriverProfileSavedNotice(null), 3000);
                }}
                className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white text-xs font-medium flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out Captain</span>
              </button>
            </div>
          </div>
        )}

        {/* Mobile Bottom Navigation Dock */}
        <div className="p-2 bg-slate-950 border-t border-slate-800 flex items-center justify-around">
          <button
            type="button"
            onClick={() => setDriverTab('duty')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl text-[11px] font-semibold transition-all ${
              driverTab === 'duty' ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Car className="w-4 h-4" />
            <span>Duty</span>
          </button>

          <button
            type="button"
            onClick={() => setDriverTab('earnings')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl text-[11px] font-semibold transition-all ${
              driverTab === 'earnings' ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Earnings</span>
          </button>

          <button
            type="button"
            onClick={() => setDriverTab('vehicle')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl text-[11px] font-semibold transition-all ${
              driverTab === 'vehicle' ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Vehicle</span>
          </button>
        </div>
      </div>

      {/* DRIVER REGISTRATION MODAL */}
      {showRegModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                <UserPlus className="w-4 h-4 text-amber-400" />
                <span>Register New Maya Captain</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowRegModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={regForm.name}
                  onChange={(e) => setRegForm({ ...regForm, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Phone Number</label>
                <input
                  type="tel"
                  required
                  value={regForm.phone}
                  onChange={(e) => setRegForm({ ...regForm, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Vehicle Category</label>
                <select
                  value={regForm.vehicleType}
                  onChange={(e) =>
                    setRegForm({ ...regForm, vehicleType: e.target.value as VehicleType })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="bike">Bike (Moto)</option>
                  <option value="auto">Auto Rickshaw</option>
                  <option value="car">Prime Car (AC Sedan)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Vehicle Make & Model</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Maruti Dzire, TVS Apache, Bajaj RE"
                  value={regForm.vehicleModel}
                  onChange={(e) => setRegForm({ ...regForm, vehicleModel: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Registration / Plate Number</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. UP-96-AB-1234"
                  value={regForm.vehicleNumber}
                  onChange={(e) => setRegForm({ ...regForm, vehicleNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Driving License Number</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. UP-9620230012345"
                  value={regForm.licenseNumber}
                  onChange={(e) => setRegForm({ ...regForm, licenseNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-md mt-2"
              >
                Submit Application
              </button>
            </form>
          </div>
        </div>
      )}

      {/* COLLECT PAYMENT MODAL */}
      {collectPaymentModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto text-xl">
              ✓
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Ride Completed!</h3>
              <p className="text-xs text-slate-400">
                Collect fare from {collectPaymentModal.customerName}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Total Passenger Fare</span>
                <span className="font-bold text-white">₹{collectPaymentModal.fare}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Platform Commission</span>
                <span className="text-red-400">-₹{collectPaymentModal.platformFee}</span>
              </div>
              <div className="border-t border-slate-800 pt-2 flex justify-between font-black text-sm">
                <span className="text-white">Your Net Earnings</span>
                <span className="text-emerald-400">
                  +₹{collectPaymentModal.fare - collectPaymentModal.platformFee}
                </span>
              </div>
              <p className="text-[11px] text-amber-400 font-semibold pt-1">
                Payment Method: {collectPaymentModal.paymentMethod.toUpperCase()}
              </p>
            </div>

            <button
              type="button"
              onClick={() => setCollectPaymentModal(null)}
              className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
            >
              Confirm Payment & Return to Duty
            </button>
          </div>
        </div>
      )}

      {/* Driver Registration and Login with Firebase Auth */}
      <DriverAuthModal
        isOpen={showDriverAuthModal}
        onClose={() => setShowDriverAuthModal(false)}
      />
    </div>
  );
};
