import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { LocationPoint, Ride, VehicleType } from '../../types';
import { POPULAR_LOCATIONS } from '../../data/mockData';
import { InteractiveMap } from '../InteractiveMap';
import { CustomerAuthModal } from '../auth/CustomerAuthModal';
import confetti from 'canvas-confetti';
import {
  Car,
  Bike,
  MapPin,
  Navigation,
  Clock,
  Shield,
  CreditCard,
  ChevronRight,
  Phone,
  MessageSquare,
  AlertTriangle,
  Star,
  CheckCircle2,
  XCircle,
  History,
  User as UserIcon,
  Search,
  ArrowRight,
  Check,
  Percent,
  Copy,
  Receipt,
  RotateCcw,
  Sparkles,
  Compass,
  LocateFixed,
  Edit3,
  Landmark,
  Building2,
  TreePine,
  LogIn,
  LogOut,
  Save,
  ShieldCheck,
  Bell,
  Wallet,
  PlusCircle,
  ExternalLink,
  HelpCircle,
  ArrowUpRight,
  ArrowDownLeft,
  LifeBuoy,
} from 'lucide-react';
import { CustomerComplaint } from '../../types';

export const CustomerApp: React.FC = () => {
  const {
    currentUser,
    rides,
    fareSettings,
    calculateFare,
    bookRide,
    cancelRide,
    rateRide,
    switchRole,
    updateCustomerProfile,
    logoutAccount,
    notifications,
    markNotificationRead,
    transactions,
    topUpWallet,
    complaints,
    fileComplaint,
    fcmToken,
  } = useRide();

  // Navigation tab within Customer App
  const [activeTab, setActiveTab] = useState<'book' | 'history' | 'profile'>('book');

  // Customer Authentication Modal state
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState(currentUser.name);
  const [editPhone, setEditPhone] = useState(currentUser.phone);
  const [profileSavedNotice, setProfileSavedNotice] = useState<string | null>(null);

  // Booking Flow State - Default to Karwi Railway Station and Ramghat Chitrakoot
  const [pickup, setPickup] = useState<LocationPoint>(POPULAR_LOCATIONS[0]); // Karwi Railway Station (CKTD)
  const [drop, setDrop] = useState<LocationPoint>(POPULAR_LOCATIONS[7]); // Ramghat (Mandakini River), Chitrakoot
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>('auto');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'online' | 'wallet'>('online');
  const [isBookingLoading, setIsBookingLoading] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('Captain is taking too long to arrive');
  const [receiptRide, setReceiptRide] = useState<Ride | null>(null);

  // Search input dropdown states
  const [searchTarget, setSearchTarget] = useState<'pickup' | 'drop' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'all' | 'station' | 'temple' | 'market' | 'village'>('all');

  // Manual location input state
  const [manualName, setManualName] = useState('');
  const [manualAddress, setManualAddress] = useState('');
  const [showManualForm, setShowManualForm] = useState(false);

  // GPS detection state
  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [gpsSuccessNotice, setGpsSuccessNotice] = useState<string | null>(null);

  // Rating modal state for recently completed ride
  const [showRatingModal, setShowRatingModal] = useState<Ride | null>(null);
  const [ratingScore, setRatingScore] = useState(5);
  const [ratingComment, setRatingComment] = useState('');

  // Notifications, Wallet Top-Up & Complaints Modal state
  const [showNotifDrawer, setShowNotifDrawer] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);
  const [contactNotice, setContactNotice] = useState<string | null>(null);
  const [showTopUpModal, setShowTopUpModal] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState('250');
  const [topUpMethod, setTopUpMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [topUpLoading, setTopUpLoading] = useState(false);

  const [showComplaintModal, setShowComplaintModal] = useState(false);
  const [complaintRideId, setComplaintRideId] = useState<string | undefined>(undefined);
  const [complaintDriverName, setComplaintDriverName] = useState<string | undefined>(undefined);
  const [complaintCategory, setComplaintCategory] = useState<CustomerComplaint['category']>('overcharging');
  const [complaintSubject, setComplaintSubject] = useState('');
  const [complaintDetails, setComplaintDetails] = useState('');
  const [complaintLoading, setComplaintLoading] = useState(false);

  const customerNotifications = notifications.filter(
    (n) => n.userId === currentUser.id || n.role === 'customer' || n.role === 'all'
  );
  const unreadNotifCount = customerNotifications.filter((n) => !n.read).length;
  const customerTransactions = transactions.filter((t) => t.userId === currentUser.id);
  const customerComplaints = complaints.filter((c) => c.customerId === currentUser.id);

  // Find active ride for current customer
  const customerRides = rides.filter((r) => r.customerId === currentUser.id);
  const activeRide = customerRides.find(
    (r) =>
      r.status === 'requested' ||
      r.status === 'accepted' ||
      r.status === 'arriving' ||
      r.status === 'in_progress'
  );

  // Calculate realistic distance between points (lat/lng diff with road curvature)
  const calculateDistance = (p1: LocationPoint, p2: LocationPoint) => {
    const latDiff = Math.abs(p1.lat - p2.lat) * 111;
    const lngDiff = Math.abs(p1.lng - p2.lng) * 85;
    const direct = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);
    // Add 25% road curvature factor for rural/town roads
    return Math.max(1.5, Number((direct * 1.25).toFixed(1)));
  };

  const distanceKm = calculateDistance(pickup, drop);
  const currentFareCalc = calculateFare(selectedVehicle, distanceKm);

  // Detect Current GPS Location from browser device
  const handleDetectGps = (target: 'pickup' | 'drop' = 'pickup') => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      return;
    }

    setIsDetectingGps(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setIsDetectingGps(false);
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const accuracy = Math.round(position.coords.accuracy || 20);

        const gpsPoint: LocationPoint = {
          name: `Device GPS (${lat.toFixed(4)}° N, ${lng.toFixed(4)}° E)`,
          address: `Current Location • Karwi/Chitrakoot Zone (±${accuracy}m accuracy)`,
          lat,
          lng,
          landmark: 'Real Device GPS Sensor',
          isGpsDetected: true,
          category: 'gps',
        };

        if (target === 'pickup') {
          setPickup(gpsPoint);
        } else {
          setDrop(gpsPoint);
        }

        setGpsSuccessNotice(`GPS position verified: ${lat.toFixed(4)}° N, ${lng.toFixed(4)}° E`);
        setTimeout(() => setGpsSuccessNotice(null), 4000);
        if (searchTarget) setSearchTarget(null);
      },
      (error) => {
        setIsDetectingGps(false);
        let msg = 'Could not access device GPS location.';
        if (error.code === error.PERMISSION_DENIED) {
          msg = 'Location permission was denied. You can type your location manually or select from the Karwi & Chitrakoot locations below.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          msg = 'GPS satellite signal unavailable. Please type address manually or select a local landmark.';
        } else if (error.code === error.TIMEOUT) {
          msg = 'GPS request timed out. Please select from local landmarks or enter address manually.';
        }
        setGpsError(msg);
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 }
    );
  };

  // Apply Manual Location Entry
  const handleApplyManualLocation = (target: 'pickup' | 'drop') => {
    if (!manualName.trim()) return;

    // Use a centroid approximation in Karwi / Chitrakoot area with slight variation
    const baseLat = target === 'pickup' ? 25.2162 : 25.1760;
    const baseLng = target === 'pickup' ? 80.9168 : 80.8660;
    const offset = (Math.random() - 0.5) * 0.04;

    const manualPoint: LocationPoint = {
      name: manualName.trim(),
      address: manualAddress.trim() || `${manualName.trim()}, Karwi / Chitrakoot, UP`,
      lat: Number((baseLat + offset).toFixed(4)),
      lng: Number((baseLng + offset).toFixed(4)),
      landmark: 'Manually Entered Location',
      isManual: true,
      category: 'custom',
    };

    if (target === 'pickup') {
      setPickup(manualPoint);
    } else {
      setDrop(manualPoint);
    }

    setManualName('');
    setManualAddress('');
    setShowManualForm(false);
    setSearchTarget(null);
  };

  // Handle Book Ride Action
  const handleBookNow = async () => {
    setBookingError(null);
    setIsBookingLoading(true);
    try {
      await bookRide(
        pickup,
        drop,
        selectedVehicle,
        distanceKm,
        currentFareCalc.estimatedMinutes,
        paymentMethod
      );
    } catch (e: any) {
      setBookingError(e?.message || 'Unable to create booking. Please check your details and try again.');
    } finally {
      setIsBookingLoading(false);
    }
  };

  // Handle Wallet Top-Up
  const handleTopUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(topUpAmount);
    if (!amt || amt <= 0) return;
    setTopUpLoading(true);
    try {
      await topUpWallet(amt, topUpMethod);
      setShowTopUpModal(false);
      setProfileSavedNotice(`₹${amt} credited to your Maya Wallet!`);
      setTimeout(() => setProfileSavedNotice(null), 4000);
    } finally {
      setTopUpLoading(false);
    }
  };

  // Handle File Complaint
  const handleComplaintSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!complaintSubject.trim() || !complaintDetails.trim()) return;
    setComplaintLoading(true);
    try {
      await fileComplaint({
        rideId: complaintRideId,
        driverName: complaintDriverName,
        category: complaintCategory,
        subject: complaintSubject,
        details: complaintDetails,
      });
      setShowComplaintModal(false);
      setComplaintSubject('');
      setComplaintDetails('');
      setComplaintRideId(undefined);
      setComplaintDriverName(undefined);
      setProfileSavedNotice('Support ticket logged! Maya Admin will review and respond.');
      setTimeout(() => setProfileSavedNotice(null), 4000);
    } finally {
      setComplaintLoading(false);
    }
  };

  // Submit Rating
  const handleRatingSubmit = async () => {
    if (!showRatingModal) return;
    await rateRide(showRatingModal.id, ratingScore, ratingComment);
    confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
    setShowRatingModal(null);
    setRatingComment('');
  };

  // Swap locations
  const handleSwapLocations = () => {
    const temp = pickup;
    setPickup(drop);
    setDrop(temp);
  };

  // Filtered locations for search
  const filteredLocations = POPULAR_LOCATIONS.filter((l) => {
    const matchesQuery =
      l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (l.landmark && l.landmark.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesQuery) return false;
    if (activeCategoryFilter !== 'all' && l.category !== activeCategoryFilter) return false;
    return true;
  });

  return (
    <div className="w-full flex justify-center py-4 px-2 sm:px-4">
      {/* Mobile Shell Container */}
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col min-h-[720px] text-slate-100">
        {/* Mobile Header Bar */}
        <div className="px-5 py-4 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 font-black flex items-center justify-center text-sm shadow-md">
              M
            </div>
            <div>
              <h2 className="font-bold text-sm tracking-tight text-white flex items-center gap-1.5">
                Maya Ride <span className="text-[10px] text-amber-400 font-semibold">KARWI • CHITRAKOOT</span>
              </h2>
              <p className="text-[11px] text-slate-400 truncate max-w-[170px]">
                Welcome, {currentUser.name}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShowNotifDrawer(!showNotifDrawer)}
              className={`relative p-2 rounded-xl border transition-all ${
                showNotifDrawer
                  ? 'bg-amber-400/20 text-amber-400 border-amber-400/40'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-slate-950 font-black text-[9px] flex items-center justify-center">
                  {unreadNotifCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowAuthModal(true)}
              className="px-2.5 py-1.5 rounded-xl border bg-slate-900 hover:bg-slate-800 text-amber-300 border-slate-800 hover:border-amber-400/40 transition-all flex items-center gap-1.5 text-xs font-semibold"
              title="Sign In / Register with Email & Password or OTP"
            >
              <LogIn className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Sign In</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`p-2 rounded-xl border transition-all ${
                activeTab === 'history'
                  ? 'bg-amber-400/20 text-amber-400 border-amber-400/40'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
              title="Booking History"
            >
              <History className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className={`p-2 rounded-xl border transition-all ${
                activeTab === 'profile'
                  ? 'bg-amber-400/20 text-amber-400 border-amber-400/40'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
              title="Passenger Profile & Wallet"
            >
              <UserIcon className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notification Slide-Down Drawer */}
        {showNotifDrawer && (
          <div className="bg-slate-950 border-b border-slate-800 p-3.5 space-y-2.5 max-h-64 overflow-y-auto">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase text-amber-400 tracking-wider flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5" /> Notifications ({unreadNotifCount} unread)
              </span>
              <span className="text-[9px] text-slate-500">
                {fcmToken ? 'Browser Alerts Enabled' : 'In-App Alerts Active'}
              </span>
            </div>
            {customerNotifications.length === 0 ? (
              <p className="text-xs text-slate-500 py-2 text-center">No notifications yet.</p>
            ) : (
              <div className="space-y-1.5">
                {customerNotifications.slice(0, 8).map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => markNotificationRead(n.id)}
                    className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all ${
                      n.read
                        ? 'bg-slate-900/60 border-slate-800/80 text-slate-400'
                        : 'bg-amber-400/10 border-amber-400/30 text-slate-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{n.title}</span>
                      <span className="text-[9px] text-slate-500">
                        {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-[11px] mt-0.5 leading-snug">{n.body}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Blocked Account Warning */}
        {currentUser.status === 'blocked' && (
          <div className="p-3 bg-red-500/20 border-b border-red-500/40 text-red-200 text-xs flex items-center gap-2 px-4">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
            <span>
              Account Blocked by Maya Admin. Ride booking is disabled.
            </span>
          </div>
        )}

        {/* Booking Error Alert */}
        {bookingError && (
          <div className="p-3 bg-red-500/20 border-b border-red-500/30 text-red-200 text-xs flex items-center justify-between gap-2 px-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
              <span className="text-[11px] leading-snug">{bookingError}</span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {bookingError.toLowerCase().includes('wallet') && (
                <button
                  type="button"
                  onClick={() => {
                    setBookingError(null);
                    setShowTopUpModal(true);
                  }}
                  className="px-2 py-1 rounded bg-amber-400 text-slate-950 font-bold text-[10px]"
                >
                  Top Up
                </button>
              )}
              <button
                type="button"
                onClick={() => setBookingError(null)}
                className="text-red-300 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* GPS Success Notice Banner */}
        {gpsSuccessNotice && (
          <div className="p-2.5 bg-emerald-500/20 border-b border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 px-4">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span className="truncate">{gpsSuccessNotice}</span>
          </div>
        )}

        {/* GPS Error Banner */}
        {gpsError && (
          <div className="p-2.5 bg-red-500/20 border-b border-red-500/30 text-red-300 text-xs flex items-center justify-between gap-2 px-4">
            <div className="flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
              <span className="text-[11px] leading-tight">{gpsError}</span>
            </div>
            <button
              type="button"
              onClick={() => setGpsError(null)}
              className="text-red-300 hover:text-white text-xs font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Tab 1: BOOK RIDE */}
        {activeTab === 'book' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* If there is an active ongoing ride, show Live Tracker Card */}
            {activeRide ? (
              <div className="space-y-4">
                {/* Active Ride Map */}
                <InteractiveMap
                  pickup={activeRide.pickupCoords}
                  drop={activeRide.dropCoords}
                  vehicleType={activeRide.vehicleType}
                  status={activeRide.status}
                  height="h-56"
                />

                {/* Ride Status Card */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-400/30">
                      {activeRide.status.replace('_', ' ')}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Ride ID: {activeRide.id}
                    </span>
                  </div>

                  {/* Driver matched or searching */}
                  {activeRide.status === 'requested' ? (
                    <div className="text-center py-4 space-y-2">
                      <div className="w-12 h-12 rounded-full border-2 border-amber-400 border-t-transparent animate-spin mx-auto" />
                      <h4 className="font-semibold text-white text-sm">
                        Finding nearby Maya Captain in Karwi & Chitrakoot...
                      </h4>
                      <p className="text-xs text-slate-400">
                        Broadcasting to verified local {activeRide.vehicleType.toUpperCase()} drivers
                      </p>
                      <button
                        type="button"
                        onClick={() => setShowCancelModal(true)}
                        className="mt-2 text-xs text-red-400 hover:text-red-300 font-medium underline"
                      >
                        Cancel Ride Request
                      </button>
                    </div>
                  ) : (
                    /* Driver Found Details */
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              activeRide.driverAvatar ||
                              'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120'
                            }
                            alt="Driver"
                            className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-400"
                          />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="font-bold text-white text-sm">
                                {activeRide.driverName || 'Maya Captain'}
                              </h4>
                              <span className="flex items-center gap-0.5 text-xs text-amber-400 font-semibold">
                                <Star className="w-3 h-3 fill-amber-400" /> 4.9
                              </span>
                            </div>
                            <p className="text-xs text-amber-300 font-medium">
                              {activeRide.vehicleModel}
                            </p>
                            <span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                              {activeRide.vehicleNumber}
                            </span>
                          </div>
                        </div>

                        {/* Start OTP Display */}
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                            Start OTP
                          </span>
                          <span className="text-lg font-black font-mono tracking-widest text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
                            {activeRide.otp}
                          </span>
                        </div>
                      </div>

                      {/* Route Summary */}
                      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs space-y-2">
                        <div className="flex items-start gap-2">
                          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 mt-0.5 shrink-0" />
                          <div className="text-slate-300">
                            <span className="text-slate-400 text-[10px] block">PICKUP</span>
                            {activeRide.pickupAddress}
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 mt-0.5 shrink-0" />
                          <div className="text-slate-300">
                            <span className="text-slate-400 text-[10px] block">DROP</span>
                            {activeRide.dropAddress}
                          </div>
                        </div>
                      </div>

                      {/* External Google Maps Turn-by-Turn Link */}
                      <a
                        href={`https://www.google.com/maps/dir/?api=1&origin=${activeRide.pickupCoords.lat},${activeRide.pickupCoords.lng}&destination=${activeRide.dropCoords.lat},${activeRide.dropCoords.lng}&travelmode=driving`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1.5"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>View Live Directions in Google Maps</span>
                      </a>

                      {contactNotice && (
                        <div className="p-2.5 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-200 text-[11px] flex items-center justify-between">
                          <span>{contactNotice}</span>
                          <button
                            type="button"
                            onClick={() => setContactNotice(null)}
                            className="text-cyan-300 font-bold ml-2"
                          >
                            ✕
                          </button>
                        </div>
                      )}

                      {/* Fare & Call Actions */}
                      <div className="flex items-center justify-between pt-1">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase">Estimated Fare</span>
                          <p className="text-lg font-extrabold text-white">
                            ₹{activeRide.fare}
                            <span className="text-xs font-normal text-slate-400 ml-1">
                              ({activeRide.paymentMethod.toUpperCase()})
                            </span>
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <a
                            href={`tel:${activeRide.driverPhone || '+919839011223'}`}
                            onClick={() =>
                              setContactNotice(`Captain Phone: ${activeRide.driverPhone || '+91 98390 11223'}`)
                            }
                            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                            title="Call Driver"
                          >
                            <Phone className="w-4 h-4 text-emerald-400" />
                          </a>
                          <button
                            type="button"
                            onClick={() =>
                              setContactNotice(
                                `Message sent to ${activeRide.driverName || 'Captain'}: "I am waiting at ${activeRide.pickupAddress}."`
                              )
                            }
                            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                            title="Send Quick Pickup Note"
                          >
                            <MessageSquare className="w-4 h-4 text-cyan-400" />
                          </button>
                          {activeRide.status !== 'in_progress' && (
                            <button
                              type="button"
                              onClick={() => setShowCancelModal(true)}
                              className="px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 text-xs font-semibold"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* New Ride Booking Screen */
              <div className="space-y-4">
                {/* Route Schematics / Map Component */}
                <InteractiveMap
                  pickup={pickup}
                  drop={drop}
                  vehicleType={selectedVehicle}
                  height="h-44 sm:h-48"
                />

                {/* GPS Quick Detect Action Button */}
                <div className="flex items-center justify-between px-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Service Area: Karwi & Chitrakoot
                  </span>
                  <button
                    type="button"
                    onClick={() => handleDetectGps('pickup')}
                    disabled={isDetectingGps}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-all active:scale-95"
                  >
                    {isDetectingGps ? (
                      <>
                        <div className="w-3 h-3 border-2 border-cyan-400 border-t-transparent animate-spin rounded-full" />
                        <span>Detecting GPS...</span>
                      </>
                    ) : (
                      <>
                        <LocateFixed className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Detect GPS Location</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Pickup and Drop Location Card */}
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 relative space-y-2.5 shadow-md">
                  {/* Pickup Row */}
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                          Pickup Location
                        </label>
                        {pickup.isGpsDetected && (
                          <span className="text-[9px] text-emerald-400 font-semibold">Real GPS</span>
                        )}
                        {pickup.isManual && (
                          <span className="text-[9px] text-amber-400 font-semibold">Custom</span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setSearchTarget('pickup');
                          setSearchQuery('');
                          setShowManualForm(false);
                        }}
                        className="w-full text-left text-xs font-semibold text-slate-100 hover:text-amber-400 truncate block py-0.5"
                      >
                        {pickup.name}
                      </button>
                      <p className="text-[10px] text-slate-400 truncate">
                        {pickup.address}
                      </p>
                    </div>
                  </div>

                  {/* Divider with Swap Button */}
                  <div className="relative py-1 flex items-center justify-center">
                    <div className="w-full border-t border-slate-800" />
                    <button
                      type="button"
                      onClick={handleSwapLocations}
                      className="absolute p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 shadow"
                      title="Swap Pickup and Drop"
                    >
                      <RotateCcw className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Drop Row */}
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                      <Navigation className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                          Drop Destination
                        </label>
                        {drop.isManual && (
                          <span className="text-[9px] text-amber-400 font-semibold">Custom</span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setSearchTarget('drop');
                          setSearchQuery('');
                          setShowManualForm(false);
                        }}
                        className="w-full text-left text-xs font-semibold text-slate-100 hover:text-amber-400 truncate block py-0.5"
                      >
                        {drop.name}
                      </button>
                      <p className="text-[10px] text-slate-400 truncate">
                        {drop.address}
                      </p>
                    </div>
                  </div>

                  {/* Distance and Duration Summary */}
                  <div className="pt-1.5 border-t border-slate-900 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Navigation className="w-3 h-3 text-cyan-400" /> {distanceKm} km route
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" /> ~{currentFareCalc.estimatedMinutes} mins
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setSearchTarget('drop');
                        setShowManualForm(true);
                      }}
                      className="text-amber-400 hover:text-amber-300 text-[10px] font-semibold underline flex items-center gap-0.5"
                    >
                      <Edit3 className="w-3 h-3" /> Manual Address
                    </button>
                  </div>
                </div>

                {/* Popular Karwi & Chitrakoot Quick Chips */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                      Popular Local Destinations
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setSearchTarget('drop');
                        setSearchQuery('');
                      }}
                      className="text-[10px] text-amber-400 font-semibold hover:underline"
                    >
                      View All ({POPULAR_LOCATIONS.length})
                    </button>
                  </div>

                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                    {POPULAR_LOCATIONS.slice(0, 7).map((loc) => (
                      <button
                        key={loc.name}
                        type="button"
                        onClick={() => setDrop(loc)}
                        className={`px-3 py-1.5 rounded-xl text-xs whitespace-nowrap shrink-0 border transition-all ${
                          drop.name === loc.name
                            ? 'bg-amber-400/20 text-amber-300 border-amber-400/50 shadow-sm'
                            : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {loc.name.split(' ')[0]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Vehicle Selection Options (Bike, Auto, Car) */}
                <div className="space-y-2">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Choose Vehicle Option
                  </span>

                  <div className="grid grid-cols-3 gap-2">
                    {/* BIKE */}
                    {(() => {
                      const bikeCalc = calculateFare('bike', distanceKm);
                      const isSelected = selectedVehicle === 'bike';
                      return (
                        <div
                          onClick={() => setSelectedVehicle('bike')}
                          className={`cursor-pointer p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                            isSelected
                              ? 'bg-gradient-to-b from-amber-400/20 to-slate-900 border-amber-400 shadow-lg shadow-amber-400/10'
                              : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-amber-400 uppercase">
                              Moto Bike
                            </span>
                            <span className="text-[10px] text-slate-400">1 seat</span>
                          </div>
                          <div className="my-2 flex justify-center text-amber-400">
                            <Bike className="w-8 h-8" />
                          </div>
                          <div>
                            <p className="text-base font-extrabold text-white">
                              ₹{bikeCalc.totalFare}
                            </p>
                            <span className="text-[10px] text-slate-400 block">
                              ₹7/km • Quickest
                            </span>
                          </div>
                        </div>
                      );
                    })()}

                    {/* AUTO */}
                    {(() => {
                      const autoCalc = calculateFare('auto', distanceKm);
                      const isSelected = selectedVehicle === 'auto';
                      return (
                        <div
                          onClick={() => setSelectedVehicle('auto')}
                          className={`cursor-pointer p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                            isSelected
                              ? 'bg-gradient-to-b from-amber-400/20 to-slate-900 border-amber-400 shadow-lg shadow-amber-400/10'
                              : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-amber-400 uppercase">
                              Maya Auto
                            </span>
                            <span className="text-[10px] text-slate-400">3 seats</span>
                          </div>
                          <div className="my-2 flex justify-center text-amber-400">
                            <div className="w-8 h-8 rounded-lg bg-amber-400/10 flex items-center justify-center font-bold text-sm">
                              🛺
                            </div>
                          </div>
                          <div>
                            <p className="text-base font-extrabold text-white">
                              ₹{autoCalc.totalFare}
                            </p>
                            <span className="text-[10px] text-slate-400 block">
                              ₹11/km • Popular
                            </span>
                          </div>
                        </div>
                      );
                    })()}

                    {/* CAR */}
                    {(() => {
                      const carCalc = calculateFare('car', distanceKm);
                      const isSelected = selectedVehicle === 'car';
                      return (
                        <div
                          onClick={() => setSelectedVehicle('car')}
                          className={`cursor-pointer p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                            isSelected
                              ? 'bg-gradient-to-b from-amber-400/20 to-slate-900 border-amber-400 shadow-lg shadow-amber-400/10'
                              : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-amber-400 uppercase">
                              Prime Cab
                            </span>
                            <span className="text-[10px] text-slate-400">4 seats</span>
                          </div>
                          <div className="my-2 flex justify-center text-amber-400">
                            <Car className="w-8 h-8" />
                          </div>
                          <div>
                            <p className="text-base font-extrabold text-white">
                              ₹{carCalc.totalFare}
                            </p>
                            <span className="text-[10px] text-slate-400 block">
                              ₹18/km • AC Prime
                            </span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </div>

                {/* Fare Breakdown Sheet */}
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-1.5 shadow-sm">
                  <div className="flex justify-between text-slate-400">
                    <span>Base Fare</span>
                    <span>₹{currentFareCalc.baseFare}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Distance Fare ({currentFareCalc.distanceKm} km)</span>
                    <span>₹{currentFareCalc.distanceFare}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Government Tax & Platform (GST 5%)</span>
                    <span>₹{currentFareCalc.tax}</span>
                  </div>
                  <div className="border-t border-slate-800 pt-1.5 flex justify-between font-bold text-white text-sm">
                    <span className="flex items-center gap-1">
                      Total Fare <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    </span>
                    <span className="text-amber-400">₹{currentFareCalc.totalFare}</span>
                  </div>
                </div>

                {/* Payment Option Selector */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Payment Mode:</span>
                    <div className="flex gap-1.5">
                      {(['cash', 'online', 'wallet'] as const).map((method) => (
                        <button
                          key={method}
                          type="button"
                          onClick={() => setPaymentMethod(method)}
                          className={`px-2.5 py-1 rounded-lg uppercase text-[10px] font-bold transition-all ${
                            paymentMethod === method
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-slate-900 text-slate-400 hover:text-white'
                          }`}
                        >
                          {method}
                        </button>
                      ))}
                    </div>
                  </div>
                  {paymentMethod === 'wallet' && (
                    <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-900">
                      <span className="text-slate-400">
                        Maya Wallet Bal:{' '}
                        <strong className={currentUser.walletBalance >= currentFareCalc.totalFare ? 'text-emerald-400' : 'text-red-400'}>
                          ₹{currentUser.walletBalance || 0}
                        </strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowTopUpModal(true)}
                        className="text-amber-400 hover:underline font-semibold flex items-center gap-0.5"
                      >
                        <PlusCircle className="w-3 h-3" /> Top Up
                      </button>
                    </div>
                  )}
                  {paymentMethod === 'online' && (
                    <p className="text-[10px] text-slate-400 pt-1 border-t border-slate-900">
                      Structured UPI/Card checkout (test settlement active; merchant keys required for live Razorpay/Cashfree charges).
                    </p>
                  )}
                </div>

                {/* Primary Booking Button */}
                <button
                  type="button"
                  onClick={handleBookNow}
                  disabled={isBookingLoading}
                  className="w-full py-3.5 px-4 rounded-2xl bg-amber-400 hover:bg-amber-300 active:scale-[0.99] text-slate-950 font-extrabold text-sm shadow-xl shadow-amber-400/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  {isBookingLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent animate-spin rounded-full" />
                      <span>Requesting Karwi Captain...</span>
                    </>
                  ) : (
                    <>
                      <span>Book {selectedVehicle.toUpperCase()} • ₹{currentFareCalc.totalFare}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: BOOKING HISTORY */}
        {activeTab === 'history' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-white">Your Past Trips in Karwi & Chitrakoot</h3>
              <span className="text-xs text-slate-400">
                {customerRides.length} rides total
              </span>
            </div>

            {customerRides.length === 0 ? (
              <div className="text-center py-12 text-slate-400 space-y-2">
                <History className="w-10 h-10 mx-auto text-slate-600" />
                <p className="text-xs">No rides booked yet in Karwi/Chitrakoot.</p>
              </div>
            ) : (
              customerRides.map((ride) => (
                <div
                  key={ride.id}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5 hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-400/20 text-amber-300 border border-amber-400/30">
                        {ride.vehicleType}
                      </span>
                      <span className="text-xs font-mono text-slate-400">
                        {new Date(ride.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        ride.status === 'completed'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : ride.status === 'cancelled'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                          : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                      }`}
                    >
                      {ride.status}
                    </span>
                  </div>

                  <div className="text-xs space-y-1">
                    <p className="text-slate-300 truncate">
                      <span className="text-cyan-400 mr-1.5">•</span>
                      {ride.pickupAddress}
                    </p>
                    <p className="text-slate-300 truncate">
                      <span className="text-amber-400 mr-1.5">•</span>
                      {ride.dropAddress}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-xs">
                    <span className="font-extrabold text-white">₹{ride.fare}</span>

                    <div className="flex items-center gap-2">
                      {ride.status === 'completed' && !ride.rating && (
                        <button
                          type="button"
                          onClick={() => {
                            setShowRatingModal(ride);
                            setRatingScore(5);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-amber-400/20 text-amber-300 text-[11px] font-semibold hover:bg-amber-400/30"
                        >
                          Rate Trip
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setComplaintRideId(ride.id);
                          setComplaintDriverName(ride.driverName || undefined);
                          setComplaintSubject(`Issue with Ride ${ride.id}`);
                          setShowComplaintModal(true);
                        }}
                        className="px-2 py-1 rounded-lg bg-slate-900 text-slate-400 hover:text-amber-300 text-[11px] font-semibold border border-slate-800"
                        title="Report an issue with this ride"
                      >
                        Help
                      </button>
                      <button
                        type="button"
                        onClick={() => setReceiptRide(ride)}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 text-slate-300 text-[11px] font-semibold border border-slate-800 hover:text-white"
                      >
                        Receipt
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 3: PASSENGER PROFILE */}
        {activeTab === 'profile' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {profileSavedNotice && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{profileSavedNotice}</span>
              </div>
            )}

            {/* Profile Overview Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center gap-3">
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                  alt={currentUser.name}
                  className="w-14 h-14 rounded-2xl object-cover ring-2 ring-amber-400"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-white text-base truncate">{currentUser.name}</h3>
                    <span className="text-[10px] px-2 py-0.5 rounded uppercase font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                      {currentUser.role}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 truncate">{currentUser.email}</p>
                  <p className="text-xs font-mono text-amber-400 mt-0.5">{currentUser.phone}</p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-900 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" /> Karwi, Chitrakoot, UP
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setIsEditingProfile(!isEditingProfile);
                    setEditName(currentUser.name);
                    setEditPhone(currentUser.phone);
                  }}
                  className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 text-xs"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>{isEditingProfile ? 'Cancel' : 'Edit Profile'}</span>
                </button>
              </div>

              {/* Edit Customer Profile Form (Name & Mobile Phone) */}
              {isEditingProfile && (
                <div className="p-3 mt-2 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5 text-xs">
                  <h4 className="font-bold text-white text-xs">Update Profile Details</h4>
                  <div>
                    <label className="text-slate-400 block mb-1 text-[11px]">Full Name</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-amber-400"
                      placeholder="Enter full name"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1 text-[11px]">Mobile Phone</label>
                    <input
                      type="tel"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-amber-400"
                      placeholder="+91 94501 23456"
                    />
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsEditingProfile(false)}
                      className="flex-1 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-semibold text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!editName.trim() || !editPhone.trim()) return;
                        await updateCustomerProfile(editName, editPhone);
                        setIsEditingProfile(false);
                        setProfileSavedNotice('Profile updated successfully!');
                        setTimeout(() => setProfileSavedNotice(null), 3500);
                      }}
                      className="flex-1 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
                    >
                      Save Profile
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Maya Wallet Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-tr from-slate-950 via-slate-900 to-amber-950/40 border border-amber-400/30 space-y-3 shadow-md">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Maya Wallet Balance
                </span>
                <Wallet className="w-4 h-4 text-amber-400" />
              </div>
              <div className="flex items-center justify-between">
                <p className="text-2xl font-black text-white">
                  ₹{(currentUser.walletBalance || 0).toFixed(2)}
                </p>
                <button
                  type="button"
                  onClick={() => setShowTopUpModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1 shadow"
                >
                  <PlusCircle className="w-3.5 h-3.5" /> Add Money
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                Automatic instant refunds on cancelled prepaid rides in Karwi & Chitrakoot!
              </p>

              {/* Wallet Payment History */}
              {customerTransactions.length > 0 && (
                <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Recent Payment & Wallet Ledger
                  </span>
                  <div className="space-y-1.5 max-h-40 overflow-y-auto pr-0.5">
                    {customerTransactions.slice(0, 6).map((t) => (
                      <div
                        key={t.id}
                        className="p-2 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-[11px]"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          {t.type === 'credit' ? (
                            <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          ) : (
                            <ArrowUpRight className="w-3.5 h-3.5 text-red-400 shrink-0" />
                          )}
                          <div className="min-w-0">
                            <p className="text-slate-200 font-medium truncate">{t.description}</p>
                            <p className="text-[9px] text-slate-500">
                              {new Date(t.createdAt).toLocaleDateString()} • {t.category.replace('_', ' ')}
                            </p>
                          </div>
                        </div>
                        <span
                          className={`font-bold shrink-0 ml-2 ${
                            t.type === 'credit' ? 'text-emerald-400' : 'text-slate-200'
                          }`}
                        >
                          {t.type === 'credit' ? '+' : '-'}₹{t.amount}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Support & Complaints Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <LifeBuoy className="w-4 h-4 text-cyan-400" /> Support & Grievances
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setComplaintRideId(undefined);
                    setComplaintDriverName(undefined);
                    setComplaintSubject('');
                    setShowComplaintModal(true);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold hover:bg-cyan-500/25"
                >
                  + File Complaint
                </button>
              </div>

              {customerComplaints.length === 0 ? (
                <p className="text-[11px] text-slate-500">
                  No open support tickets. Facing a fare or driver issue? Log a complaint anytime.
                </p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-y-auto">
                  {customerComplaints.map((c) => (
                    <div
                      key={c.id}
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] text-amber-400">{c.id}</span>
                        <span
                          className={`text-[9px] px-2 py-0.5 rounded-full uppercase font-bold ${
                            c.status === 'resolved'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : c.status === 'in_progress'
                              ? 'bg-cyan-500/20 text-cyan-400'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}
                        >
                          {c.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="font-bold text-white text-[11px]">{c.subject}</p>
                      <p className="text-[10px] text-slate-400">{c.details}</p>
                      {c.resolutionNote && (
                        <p className="text-[10px] text-emerald-300 pt-1 border-t border-slate-800">
                          Admin Note: {c.resolutionNote}
                          {c.refundIssued ? ` (Refunded ₹${c.refundIssued})` : ''}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Account Management & Auth */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => setShowAuthModal(true)}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/30 text-amber-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-amber-400" />
                <span>Switch / Sign In with Firebase Account</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  await logoutAccount();
                  setProfileSavedNotice('Signed out of passenger session.');
                  setTimeout(() => setProfileSavedNotice(null), 3000);
                }}
                className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white text-xs font-medium flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out Passenger</span>
              </button>

              <button
                type="button"
                onClick={() => switchRole('driver')}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-400 border border-slate-800 text-xs font-semibold"
              >
                Switch to Driver (Captain) Mode
              </button>
            </div>
          </div>
        )}

        {/* Mobile Bottom Navigation Dock */}
        <div className="p-2 bg-slate-950 border-t border-slate-800 flex items-center justify-around">
          <button
            type="button"
            onClick={() => setActiveTab('book')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl text-[11px] font-semibold transition-all ${
              activeTab === 'book' ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Car className="w-4 h-4" />
            <span>Book</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl text-[11px] font-semibold transition-all ${
              activeTab === 'history' ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Trips</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl text-[11px] font-semibold transition-all ${
              activeTab === 'profile' ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserIcon className="w-4 h-4" />
            <span>Profile</span>
          </button>
        </div>
      </div>

      {/* COMPREHENSIVE LOCATION SEARCH & MANUAL ENTRY MODAL */}
      {searchTarget && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-4 sm:p-5 space-y-3.5 shadow-2xl max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div>
                <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">
                  Karwi & Chitrakoot Location Search
                </span>
                <h3 className="font-bold text-sm text-white">
                  Select {searchTarget === 'pickup' ? 'Pickup Location' : 'Destination'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSearchTarget(null)}
                className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-xs"
              >
                ✕
              </button>
            </div>

            {/* GPS Detection Quick Action Button */}
            <button
              type="button"
              onClick={() => handleDetectGps(searchTarget)}
              disabled={isDetectingGps}
              className="w-full py-2.5 px-3 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              {isDetectingGps ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent animate-spin rounded-full" />
                  <span>Accessing Device GPS Sensor...</span>
                </>
              ) : (
                <>
                  <LocateFixed className="w-4 h-4 text-cyan-400" />
                  <span>Use My Current Device GPS Location</span>
                </>
              )}
            </button>

            {/* Toggle Manual Entry vs Pre-filled Search */}
            <div className="flex items-center justify-between pt-0.5">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">
                {showManualForm ? 'Enter Address Manually' : 'Search Karwi, Chitrakoot & Villages'}
              </span>
              <button
                type="button"
                onClick={() => setShowManualForm(!showManualForm)}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
              >
                <Edit3 className="w-3 h-3" />
                <span>{showManualForm ? 'Search Landmark List' : 'Enter Manually'}</span>
              </button>
            </div>

            {/* View A: MANUAL LOCATION INPUT FORM */}
            {showManualForm ? (
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                    Location / Landmark / House Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Near Hanuman Temple, Purani Bazar Karwi"
                    value={manualName}
                    onChange={(e) => setManualName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                    Street / Village / Area Details (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Village Bhaunri, Pahari Road, Chitrakoot UP"
                    value={manualAddress}
                    onChange={(e) => setManualAddress(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="pt-1 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowManualForm(false)}
                    className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyManualLocation(searchTarget)}
                    disabled={!manualName.trim()}
                    className="flex-1 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bold text-xs"
                  >
                    Set Location
                  </button>
                </div>
              </div>
            ) : (
              /* View B: SEARCH BAR & CATEGORY TABS */
              <>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search Karwi, Chitrakoot, temples, villages..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Category Filters */}
                <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {[
                    { id: 'all', label: 'All' },
                    { id: 'station', label: '🚉 Karwi Hubs' },
                    { id: 'temple', label: '🏛️ Temples' },
                    { id: 'market', label: '🛍️ Markets' },
                    { id: 'village', label: '🌾 Villages' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setActiveCategoryFilter(cat.id as any)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold whitespace-nowrap border transition-all ${
                        activeCategoryFilter === cat.id
                          ? 'bg-amber-400 text-slate-950 border-amber-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Location Results List */}
                <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5 max-h-64 scrollbar-none">
                  {filteredLocations.length === 0 ? (
                    <div className="text-center py-6 text-slate-500 text-xs space-y-2">
                      <p>No locations matched "{searchQuery}".</p>
                      <button
                        type="button"
                        onClick={() => {
                          setManualName(searchQuery);
                          setShowManualForm(true);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-amber-400/20 text-amber-300 font-semibold text-xs border border-amber-400/30"
                      >
                        Use "{searchQuery}" as Custom Address
                      </button>
                    </div>
                  ) : (
                    filteredLocations.map((loc) => (
                      <button
                        key={loc.name}
                        type="button"
                        onClick={() => {
                          if (searchTarget === 'pickup') setPickup(loc);
                          else setDrop(loc);
                          setSearchTarget(null);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-slate-800 bg-slate-950/60 border border-slate-800/80 transition-colors flex items-start gap-2.5"
                      >
                        <MapPin className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="text-xs font-bold text-white truncate">{loc.name}</p>
                            <span className="text-[9px] uppercase font-semibold text-slate-500 px-1 rounded bg-slate-900">
                              {loc.category}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 truncate">
                            {loc.address}
                          </p>
                          {loc.landmark && (
                            <p className="text-[10px] text-cyan-400 truncate">
                              Landmark: {loc.landmark}
                            </p>
                          )}
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* CANCEL RIDE MODAL */}
      {showCancelModal && activeRide && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-red-400">
              <AlertTriangle className="w-5 h-5" />
              <h3 className="font-bold text-sm text-white">Cancel Ride?</h3>
            </div>

            <p className="text-xs text-slate-400">
              Please let us know why you need to cancel this ride:
            </p>

            <div className="space-y-1.5">
              {[
                'Driver is taking too long to arrive',
                'Changed my travel plans',
                'Selected wrong pickup/drop location',
                'Found alternative local conveyance',
              ].map((reason) => (
                <label
                  key={reason}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs cursor-pointer ${
                    cancelReason === reason
                      ? 'bg-amber-400/10 border-amber-400 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="cancelReason"
                    checked={cancelReason === reason}
                    onChange={() => setCancelReason(reason)}
                    className="accent-amber-400"
                  />
                  <span>{reason}</span>
                </label>
              ))}
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCancelModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Keep Ride
              </button>
              <button
                type="button"
                onClick={async () => {
                  await cancelRide(activeRide.id, cancelReason, 'customer');
                  setShowCancelModal(false);
                }}
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold"
              >
                Confirm Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RATING MODAL */}
      {showRatingModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center mx-auto text-xl">
              ⭐
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Rate Your Captain</h3>
              <p className="text-xs text-slate-400">
                How was your ride with {showRatingModal.driverName || 'Maya Captain'}?
              </p>
            </div>

            {/* Star selector */}
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRatingScore(star)}
                  className="p-1 transition-transform active:scale-125"
                >
                  <Star
                    className={`w-7 h-7 ${
                      star <= ratingScore
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-slate-600'
                    }`}
                  />
                </button>
              ))}
            </div>

            <textarea
              placeholder="Leave feedback for driver (polite, clean vehicle, knew the routes...)"
              value={ratingComment}
              onChange={(e) => setRatingComment(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 h-20 resize-none"
            />

            <button
              type="button"
              onClick={handleRatingSubmit}
              className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
            >
              Submit Rating
            </button>
          </div>
        </div>
      )}

      {/* DIGITAL RECEIPT MODAL */}
      {receiptRide && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm text-white">Maya Ride Receipt</h3>
              </div>
              <button
                type="button"
                onClick={() => setReceiptRide(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="text-xs space-y-3">
              <div className="flex justify-between text-slate-400">
                <span>Invoice ID</span>
                <span className="font-mono text-white">{receiptRide.id}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Date & Time</span>
                <span className="text-white">
                  {new Date(receiptRide.createdAt).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Vehicle Type</span>
                <span className="text-amber-400 uppercase font-semibold">
                  {receiptRide.vehicleType}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Captain</span>
                <span className="text-white">{receiptRide.driverName || 'Maya Captain'}</span>
              </div>

              <div className="border-t border-slate-800 pt-2 space-y-1.5">
                <div className="flex justify-between text-slate-400">
                  <span>Base Rate</span>
                  <span>₹{receiptRide.baseFare}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Distance Fare ({receiptRide.distanceKm} km)</span>
                  <span>₹{receiptRide.distanceFare}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>GST (5%)</span>
                  <span>₹{receiptRide.tax}</span>
                </div>
                <div className="border-t border-slate-800 pt-1.5 flex justify-between font-bold text-white text-sm">
                  <span>Total Paid</span>
                  <span className="text-amber-400">₹{receiptRide.fare}</span>
                </div>
                <div className="flex justify-between text-[11px] text-emerald-400">
                  <span>Payment Status</span>
                  <span>PAID via {receiptRide.paymentMethod.toUpperCase()}</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setReceiptRide(null)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs"
            >
              Close Receipt
            </button>
          </div>
        </div>
      )}

      {/* WALLET TOP-UP MODAL */}
      {showTopUpModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                <Wallet className="w-4 h-4 text-amber-400" /> Top Up Maya Wallet
              </h3>
              <button
                type="button"
                onClick={() => setShowTopUpModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleTopUpSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Amount (INR ₹)</label>
                <input
                  type="number"
                  min={50}
                  max={10000}
                  required
                  value={topUpAmount}
                  onChange={(e) => setTopUpAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold text-sm focus:outline-none focus:border-amber-400"
                />
                <div className="flex gap-1.5 mt-2">
                  {['100', '250', '500', '1000'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setTopUpAmount(preset)}
                      className={`flex-1 py-1 rounded-lg border text-[11px] font-bold ${
                        topUpAmount === preset
                          ? 'bg-amber-400/20 text-amber-300 border-amber-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      +₹{preset}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Recharge Method</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['upi', 'card', 'netbanking'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setTopUpMethod(m)}
                      className={`py-2 rounded-xl border uppercase text-[10px] font-bold ${
                        topUpMethod === m
                          ? 'bg-amber-400 text-slate-950 border-amber-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <p className="text-[10px] text-slate-400 leading-snug">
                Adds test credits to your Maya Wallet ledger. Live UPI/Razorpay charges require merchant gateway configuration.
              </p>

              <button
                type="submit"
                disabled={topUpLoading}
                className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-md"
              >
                {topUpLoading ? 'Processing...' : `Add ₹${topUpAmount || 0} to Wallet`}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* FILE COMPLAINT / SUPPORT MODAL */}
      {showComplaintModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                <LifeBuoy className="w-4 h-4 text-cyan-400" /> Report Ride / Fare Issue
              </h3>
              <button
                type="button"
                onClick={() => setShowComplaintModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleComplaintSubmit} className="space-y-3 text-xs">
              {complaintRideId && (
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-amber-300 font-mono">
                  Linked Trip: {complaintRideId} {complaintDriverName ? `• ${complaintDriverName}` : ''}
                </div>
              )}
              <div>
                <label className="text-slate-400 block mb-1">Issue Category</label>
                <select
                  value={complaintCategory}
                  onChange={(e) => setComplaintCategory(e.target.value as CustomerComplaint['category'])}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="overcharging">Overcharging / Fare Dispute</option>
                  <option value="driver_behavior">Driver Behavior</option>
                  <option value="vehicle_condition">Vehicle Condition</option>
                  <option value="route_issue">Route / Navigation Issue</option>
                  <option value="cancellation_dispute">Cancellation Fee Dispute</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Subject</label>
                <input
                  type="text"
                  required
                  placeholder="Brief summary of the issue"
                  value={complaintSubject}
                  onChange={(e) => setComplaintSubject(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Details</label>
                <textarea
                  required
                  placeholder="Describe what happened so our Karwi Admin team can help..."
                  value={complaintDetails}
                  onChange={(e) => setComplaintDetails(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white h-20 resize-none focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                type="submit"
                disabled={complaintLoading}
                className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-md"
              >
                {complaintLoading ? 'Submitting...' : 'Submit Support Ticket'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Customer Registration and Login with Firebase */}
      <CustomerAuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />
    </div>
  );
};
