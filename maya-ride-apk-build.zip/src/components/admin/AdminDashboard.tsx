import React, { useEffect, useState } from 'react';
import { useRide } from '../../context/RideContext';
import { CustomerComplaint, Driver, FareSetting, Ride, User, VehicleType } from '../../types';
import {
  Car,
  Bike,
  LayoutDashboard,
  Users,
  CheckCircle2,
  XCircle,
  Sliders,
  DollarSign,
  TrendingUp,
  FileText,
  Search,
  Filter,
  ShieldCheck,
  AlertTriangle,
  Award,
  Calendar,
  Percent,
  Check,
  Download,
  Eye,
  RefreshCw,
  Clock,
  Sparkles,
  Lock,
  LogOut,
  KeyRound,
  CreditCard,
  LifeBuoy,
  FileCheck,
  Wallet,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    drivers,
    rides,
    users,
    currentUser,
    fareSettings,
    complaints,
    transactions,
    approveDriver,
    rejectDriver,
    verifyDriverDocument,
    updateFareSetting,
    toggleAccountBlock,
    updateComplaintStatus,
    requestDriverPayout,
    cancelRide,
    resetToDemoData,
    isAdminAuthenticated,
    loginAdminAccount,
    loginWithGoogle,
    logoutAccount,
  } = useRide();

  // Admin Login Form State
  const [adminEmail, setAdminEmail] = useState('dps8318.la9312@gmail.com');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminLoading, setAdminLoading] = useState(false);
  const [adminAuthError, setAdminAuthError] = useState<string | null>(null);

  // Admin section tabs
  const [adminTab, setAdminTab] = useState<
    'overview' | 'approvals' | 'bookings' | 'payments' | 'complaints' | 'fares' | 'users' | 'reports'
  >('overview');

  // Search & Filters
  const [bookingFilter, setBookingFilter] = useState<'all' | 'live' | 'completed' | 'cancelled'>('all');
  const [bookingSearch, setBookingSearch] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'customer' | 'driver'>('all');
  const [complaintFilter, setComplaintFilter] = useState<'all' | 'open' | 'in_progress' | 'resolved'>('all');

  // Modals: Booking inspection, Driver Document inspection, Complaint resolution
  const [selectedBooking, setSelectedBooking] = useState<Ride | null>(null);
  const [inspectingDriver, setInspectingDriver] = useState<Driver | null>(null);
  const [docRejectReason, setDocRejectReason] = useState('');
  const [resolvingComplaint, setResolvingComplaint] = useState<CustomerComplaint | null>(null);
  const [resolutionStatus, setResolutionStatus] = useState<CustomerComplaint['status']>('resolved');
  const [resolutionNote, setResolutionNote] = useState('');
  const [refundAmount, setRefundAmount] = useState('0');
  const [adminToast, setAdminToast] = useState<string | null>(null);

  // Editable fare settings state
  const [editingFares, setEditingFares] = useState<Record<VehicleType, Partial<FareSetting>>>(() => {
    const map: Record<string, Partial<FareSetting>> = {};
    fareSettings.forEach((f) => {
      map[f.vehicleType] = { ...f };
    });
    return map as Record<VehicleType, Partial<FareSetting>>;
  });

  useEffect(() => {
    const map: Record<string, Partial<FareSetting>> = {};
    fareSettings.forEach((f) => {
      map[f.vehicleType] = { ...f };
    });
    setEditingFares(map as Record<VehicleType, Partial<FareSetting>>);
  }, [fareSettings]);

  const [fareSavedToast, setFareSavedToast] = useState(false);

  // KPI calculations
  const totalRidesCount = rides.length;
  const completedRides = rides.filter((r) => r.status === 'completed');
  const activeRides = rides.filter(
    (r) => r.status === 'requested' || r.status === 'accepted' || r.status === 'arriving' || r.status === 'in_progress'
  );
  const totalGrossRevenue = completedRides.reduce((sum, r) => sum + r.fare, 0);
  const totalCommissionEarned = completedRides.reduce((sum, r) => sum + r.platformFee, 0);
  const pendingDrivers = drivers.filter((d) => d.approvalStatus === 'pending' || d.documentStatus === 'pending');
  const approvedDrivers = drivers.filter((d) => d.approvalStatus === 'approved');
  const openComplaints = complaints.filter((c) => c.status !== 'resolved');
  const totalRefunded = transactions
    .filter((t) => t.category === 'refund')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalDriverWalletPayable = drivers.reduce((sum, d) => sum + (d.walletBalance || 0), 0);

  const showToast = (msg: string) => {
    setAdminToast(msg);
    setTimeout(() => setAdminToast(null), 3500);
  };

  // Save fare card changes
  const handleSaveFares = (vType: VehicleType) => {
    const data = editingFares[vType];
    if (data) {
      updateFareSetting(vType, data);
      setFareSavedToast(true);
      setTimeout(() => setFareSavedToast(false), 3000);
    }
  };

  // Filtered Bookings
  const filteredBookings = rides.filter((r) => {
    const matchesSearch =
      r.id.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      r.customerName.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      (r.driverName && r.driverName.toLowerCase().includes(bookingSearch.toLowerCase())) ||
      r.pickupAddress.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      r.dropAddress.toLowerCase().includes(bookingSearch.toLowerCase());

    if (!matchesSearch) return false;

    if (bookingFilter === 'live') {
      return (
        r.status === 'requested' ||
        r.status === 'accepted' ||
        r.status === 'arriving' ||
        r.status === 'in_progress'
      );
    }
    if (bookingFilter === 'completed') return r.status === 'completed';
    if (bookingFilter === 'cancelled') return r.status === 'cancelled';
    return true;
  });

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.phone.toLowerCase().includes(userSearch.toLowerCase());

    if (!matchesSearch) return false;
    if (userRoleFilter !== 'all' && u.role !== userRoleFilter) return false;
    return true;
  });

  // Export report summary
  const handleExportReport = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      ['RideID,Customer,Driver,Vehicle,DistanceKM,Fare,Commission,Status,Date']
        .concat(
          rides.map(
            (r) =>
              `${r.id},"${r.customerName}","${r.driverName || 'N/A'}",${r.vehicleType},${r.distanceKm},${r.fare},${r.platformFee},${r.status},${r.createdAt}`
          )
        )
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Maya_Ride_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAdminLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminLoading(true);
    setAdminAuthError(null);
    try {
      await loginAdminAccount(adminEmail, adminPassword);
    } catch (err: any) {
      setAdminAuthError(err.message || 'Authentication failed. Please verify admin credentials.');
    } finally {
      setAdminLoading(false);
    }
  };

  const handleAdminGoogleLogin = async () => {
    setAdminLoading(true);
    setAdminAuthError(null);
    try {
      const user = await loginWithGoogle();
      if (user.role !== 'admin') {
        setAdminAuthError('Signed in Google account does not have Maya Ride Admin privileges.');
      }
    } catch (err: any) {
      setAdminAuthError(err.message || 'Google Admin sign-in failed.');
    } finally {
      setAdminLoading(false);
    }
  };

  // Secure Gate: If not authenticated as Admin, show locked authentication portal
  if (!isAdminAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-12">
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl space-y-4 text-center">
          <div className="w-14 h-14 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center mx-auto shadow-lg shadow-amber-400/20">
            <Lock className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">Maya Admin Security Gate</h2>
            <p className="text-xs text-slate-400 mt-1">
              Restricted to authorized Maya Ride administrators. Customers and Drivers are strictly forbidden from accessing admin controls or database records.
            </p>
          </div>

          {adminAuthError && (
            <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs flex items-center gap-2 text-left">
              <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{adminAuthError}</span>
            </div>
          )}

          <form onSubmit={handleAdminLoginSubmit} className="space-y-3 text-left text-xs">
            <div>
              <label className="text-slate-400 block mb-1 font-semibold">Admin Authorized Email</label>
              <input
                type="email"
                required
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                placeholder="admin@mayaride.in"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1 font-semibold">Admin Password</label>
              <input
                type="password"
                required
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Enter password (minimum 6 characters)"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
              />
            </div>
            <button
              type="submit"
              disabled={adminLoading}
              className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-md mt-1 flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {adminLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent animate-spin rounded-full" />
                  <span>Verifying with Firebase...</span>
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>Authenticate Admin</span>
                </>
              )}
            </button>
          </form>

          <div className="relative flex items-center justify-center py-1">
            <div className="w-full border-t border-slate-800" />
            <span className="px-2 bg-slate-900 text-[10px] text-slate-500 uppercase font-bold">
              OR
            </span>
          </div>

          <button
            type="button"
            disabled={adminLoading}
            onClick={handleAdminGoogleLogin}
            className="w-full py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            <span>Sign in with Google (Authorized Admin)</span>
          </button>

          <p className="text-[11px] text-slate-500 pt-2 border-t border-slate-800/80">
            Governed by Role-Based Firebase Security Rules • Never hardcoded
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner / Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-xl shadow-lg shadow-amber-400/20">
            👑
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
              Maya Ride Command Center
              <span className="px-2 py-0.5 rounded text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/30 uppercase font-bold">
                Karwi • Chitrakoot
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Karwi & Chitrakoot, Uttar Pradesh fleet operations, driver onboarding, live bookings, rate card configuration & analytics.
            </p>
          </div>
        </div>

        {/* Navigation Tabs & Lock Console Action */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 overflow-x-auto scrollbar-none">
            {[
              { id: 'overview', label: 'Overview', icon: LayoutDashboard },
              { id: 'approvals', label: `Approvals (${pendingDrivers.length})`, icon: ShieldCheck, alert: pendingDrivers.length > 0 },
              { id: 'bookings', label: 'Bookings', icon: Car },
              { id: 'payments', label: 'Payments', icon: CreditCard },
              { id: 'complaints', label: `Complaints (${openComplaints.length})`, icon: LifeBuoy, alert: openComplaints.length > 0 },
              { id: 'fares', label: 'Fares & Commission', icon: Sliders },
              { id: 'users', label: 'Users & Drivers', icon: Users },
              { id: 'reports', label: 'Reports', icon: TrendingUp },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = adminTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setAdminTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/10'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.alert && (
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  )}
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={async () => {
              await logoutAccount();
            }}
            className="p-2.5 rounded-2xl bg-slate-950 hover:bg-red-500/20 text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-500/30 transition-all text-xs font-semibold flex items-center gap-1.5 shrink-0"
            title="Lock Admin Console & Sign Out"
          >
            <Lock className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Lock Console</span>
          </button>
        </div>
      </div>

      {/* Admin Action Toast */}
      {adminToast && (
        <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-200 text-xs font-semibold flex items-center justify-between">
          <span>{adminToast}</span>
          <button type="button" onClick={() => setAdminToast(null)} className="font-bold">
            ✕
          </button>
        </div>
      )}

      {/* KPI METRIC CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Total Revenue */}
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Gross Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-white">₹{totalGrossRevenue.toLocaleString()}</p>
          <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> +14.8% this week
          </span>
        </div>

        {/* Maya Commission Earned */}
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Platform Commission</span>
            <Percent className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-400">
            ₹{totalCommissionEarned.toLocaleString()}
          </p>
          <span className="text-[11px] text-slate-400">Net platform revenue</span>
        </div>

        {/* Total Trips */}
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Bookings</span>
            <Car className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-black text-white">{totalRidesCount}</p>
          <span className="text-[11px] text-cyan-400 font-semibold">
            {activeRides.length} active right now
          </span>
        </div>

        {/* Active Captains */}
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Approved Captains</span>
            <Users className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-black text-white">{approvedDrivers.length}</p>
          <span className="text-[11px] text-amber-400 font-semibold">
            {pendingDrivers.length} waiting approval
          </span>
        </div>
      </div>

      {/* SECTION 1: OVERVIEW */}
      {adminTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Live Fleet & Ongoing Rides */}
          <div className="lg:col-span-2 space-y-4">
            <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <h3 className="font-bold text-sm text-white">Live Ongoing Rides</h3>
                </div>
                <span className="text-xs text-slate-400">{activeRides.length} in transit</span>
              </div>

              {activeRides.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  No active rides currently. Open Customer App to book a demo ride!
                </div>
              ) : (
                <div className="space-y-3">
                  {activeRides.map((ride) => (
                    <div
                      key={ride.id}
                      className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-amber-400">{ride.id}</span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] uppercase font-bold bg-amber-400/20 text-amber-300">
                            {ride.vehicleType}
                          </span>
                          <span className="text-slate-400">• Passenger: {ride.customerName}</span>
                        </div>
                        <p className="text-slate-300 text-[11px] truncate max-w-md">
                          {ride.pickupAddress} → {ride.dropAddress}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                          {ride.status.replace('_', ' ')}
                        </span>
                        <p className="text-xs font-bold text-white mt-1">₹{ride.fare}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Vehicle Category Fleet Share */}
            <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <h3 className="font-bold text-sm text-white">Fleet Distribution</h3>
              <div className="grid grid-cols-3 gap-3">
                {(['bike', 'auto', 'car'] as const).map((v) => {
                  const count = drivers.filter((d) => d.vehicleType === v).length;
                  const ridesCount = rides.filter((r) => r.vehicleType === v).length;
                  return (
                    <div
                      key={v}
                      className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-1"
                    >
                      <span className="text-xs uppercase font-bold text-amber-400">
                        {v}
                      </span>
                      <p className="text-xl font-black text-white">{count} Drivers</p>
                      <p className="text-[11px] text-slate-400">{ridesCount} Total Trips</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Quick Pending Approvals Sidebar */}
          <div className="space-y-4">
            <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-white">Pending Captain Approvals</h3>
                <span className="text-xs font-bold text-amber-400">
                  {pendingDrivers.length} pending
                </span>
              </div>

              {pendingDrivers.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  All registered drivers are verified & approved!
                </div>
              ) : (
                <div className="space-y-3">
                  {pendingDrivers.map((d) => (
                    <div
                      key={d.id}
                      className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={d.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                          alt={d.name}
                          className="w-10 h-10 rounded-xl object-cover ring-1 ring-amber-400"
                        />
                        <div>
                          <h4 className="font-bold text-white">{d.name}</h4>
                          <p className="text-[11px] text-amber-300 font-medium">
                            {d.vehicleModel} ({d.vehicleType.toUpperCase()})
                          </p>
                          <span className="text-[10px] font-mono text-slate-400">
                            {d.vehicleNumber}
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setInspectingDriver(d);
                            setDocRejectReason(d.documentRejectionReason || '');
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-[11px]"
                        >
                          Docs
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await approveDriver(d.id);
                            showToast(`Approved captain ${d.name}`);
                          }}
                          className="flex-1 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[11px]"
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await rejectDriver(d.id);
                            showToast(`Rejected captain ${d.name}`);
                          }}
                          className="flex-1 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 font-bold text-[11px]"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: DRIVER APPROVALS & DOCUMENT VERIFICATION HUB */}
      {adminTab === 'approvals' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white">Driver Verification & Document Inspection</h2>
              <p className="text-xs text-slate-400">
                Inspect Driving Licence & Vehicle RC uploads, verify KYC status, and approve or reject driver partners.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold border border-amber-400/30">
              {pendingDrivers.length} Awaiting Review
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3">Driver Profile</th>
                  <th className="p-3">Vehicle Type</th>
                  <th className="p-3">Model & Plate</th>
                  <th className="p-3">License & KYC Docs</th>
                  <th className="p-3">Account Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {drivers.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-950/60 transition-colors">
                    <td className="p-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={d.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                          alt={d.name}
                          className="w-9 h-9 rounded-xl object-cover"
                        />
                        <div>
                          <p className="font-bold text-white">{d.name}</p>
                          <p className="text-[11px] text-slate-400">{d.phone}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                        {d.vehicleType}
                      </span>
                    </td>
                    <td className="p-3">
                      <p className="text-white font-medium">{d.vehicleModel}</p>
                      <p className="font-mono text-slate-400 text-[11px]">{d.vehicleNumber}</p>
                    </td>
                    <td className="p-3">
                      <p className="font-mono text-slate-300">{d.licenseNumber}</p>
                      <span
                        className={`inline-block mt-1 px-2 py-0.5 rounded text-[9px] uppercase font-bold ${
                          d.documentStatus === 'verified'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : d.documentStatus === 'rejected'
                            ? 'bg-red-500/20 text-red-400'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        Docs: {d.documentStatus || 'pending'}
                      </span>
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold ${
                          d.approvalStatus === 'approved'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : d.approvalStatus === 'pending'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-red-500/20 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {d.approvalStatus}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setInspectingDriver(d);
                            setDocRejectReason(d.documentRejectionReason || '');
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold flex items-center gap-1"
                        >
                          <FileCheck className="w-3.5 h-3.5" /> Inspect Docs
                        </button>
                        {d.approvalStatus === 'pending' ? (
                          <>
                            <button
                              type="button"
                              onClick={() => approveDriver(d.id)}
                              className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                            >
                              Approve
                            </button>
                            <button
                              type="button"
                              onClick={() => rejectDriver(d.id)}
                              className="px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs font-semibold"
                            >
                              Reject
                            </button>
                          </>
                        ) : d.approvalStatus === 'approved' ? (
                          <button
                            type="button"
                            onClick={() => rejectDriver(d.id)}
                            className="text-[11px] text-red-400 hover:underline px-2"
                          >
                            Revoke
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => approveDriver(d.id)}
                            className="text-[11px] text-emerald-400 hover:underline px-2"
                          >
                            Re-Approve
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 3: BOOKINGS MANAGER */}
      {adminTab === 'bookings' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white">All Ride Bookings</h2>
              <p className="text-xs text-slate-400">
                Track live requests, completed journeys, customer fares, and platform commissions.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Search */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search ride ID, name, location..."
                  value={bookingSearch}
                  onChange={(e) => setBookingSearch(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 w-56"
                />
              </div>

              {/* Status Filter */}
              <select
                value={bookingFilter}
                onChange={(e) => setBookingFilter(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-amber-400 font-semibold focus:outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="live">Live Only</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3">Ride ID</th>
                  <th className="p-3">Vehicle</th>
                  <th className="p-3">Passenger</th>
                  <th className="p-3">Captain</th>
                  <th className="p-3">Route (Distance)</th>
                  <th className="p-3">Total Fare</th>
                  <th className="p-3">Maya Commission</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredBookings.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-950/60 transition-colors">
                    <td className="p-3 font-mono font-bold text-amber-400">{r.id}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                        {r.vehicleType}
                      </span>
                    </td>
                    <td className="p-3">
                      <p className="font-semibold text-white">{r.customerName}</p>
                      <p className="text-[10px] text-slate-400">{r.customerPhone}</p>
                    </td>
                    <td className="p-3">
                      {r.driverName ? (
                        <div>
                          <p className="font-semibold text-white">{r.driverName}</p>
                          <p className="text-[10px] font-mono text-slate-400">{r.vehicleNumber}</p>
                        </div>
                      ) : (
                        <span className="text-slate-500 italic">Searching...</span>
                      )}
                    </td>
                    <td className="p-3 max-w-[200px]">
                      <p className="truncate text-slate-300 text-[11px]">{r.pickupAddress}</p>
                      <p className="truncate text-amber-300/80 text-[11px]">→ {r.dropAddress}</p>
                      <span className="text-[10px] text-slate-500">{r.distanceKm} km</span>
                    </td>
                    <td className="p-3 font-bold text-white">₹{r.fare}</td>
                    <td className="p-3 font-bold text-emerald-400">+₹{r.platformFee}</td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold ${
                          r.status === 'completed'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : r.status === 'cancelled'
                            ? 'bg-red-500/20 text-red-400'
                            : 'bg-cyan-500/20 text-cyan-400'
                        }`}
                      >
                        {r.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        type="button"
                        onClick={() => setSelectedBooking(r)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-semibold"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 3B: PAYMENTS, WALLET & DRIVER EARNINGS SETTLEMENT */}
      {adminTab === 'payments' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-xs text-slate-400">Transactions Recorded</span>
              <p className="text-2xl font-black text-white">{transactions.length}</p>
              <span className="text-[11px] text-cyan-400">Wallet, Online & Payout Ledger</span>
            </div>
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-xs text-slate-400">Driver Wallet Payable</span>
              <p className="text-2xl font-black text-amber-400">₹{totalDriverWalletPayable.toLocaleString()}</p>
              <span className="text-[11px] text-slate-400">Ready for captain settlement</span>
            </div>
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-xs text-slate-400">Total Refunds Issued</span>
              <p className="text-2xl font-black text-emerald-400">₹{totalRefunded.toLocaleString()}</p>
              <span className="text-[11px] text-slate-400">Cancellations & dispute settlements</span>
            </div>
          </div>

          {/* Driver Earnings & Settlement Table */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <div>
              <h2 className="text-base font-bold text-white">Driver Earnings & Commission Balances</h2>
              <p className="text-xs text-slate-400">
                Track captain net revenue, completed trips, and settle pending wallet payouts.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-3">Captain</th>
                    <th className="p-3">Vehicle</th>
                    <th className="p-3">Total Trips</th>
                    <th className="p-3">Lifetime Net Earnings</th>
                    <th className="p-3">Withdrawable Wallet</th>
                    <th className="p-3 text-right">Settlement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {drivers.map((d) => (
                    <tr key={d.id} className="hover:bg-slate-950/60">
                      <td className="p-3 font-bold text-white">{d.name}</td>
                      <td className="p-3 uppercase text-amber-300">{d.vehicleType} ({d.vehicleNumber})</td>
                      <td className="p-3">{d.totalTrips}</td>
                      <td className="p-3 text-emerald-400 font-bold">₹{d.totalEarnings}</td>
                      <td className="p-3 font-black text-white">₹{d.walletBalance}</td>
                      <td className="p-3 text-right">
                        {d.walletBalance > 0 ? (
                          <button
                            type="button"
                            onClick={async () => {
                              const amt = d.walletBalance;
                              await requestDriverPayout(d.id, amt);
                              showToast(`Settled ₹${amt} payout for ${d.name}`);
                            }}
                            className="px-3 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-[11px]"
                          >
                            Settle ₹{d.walletBalance}
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-500">Settled</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* All Wallet & Payment Transactions */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <h2 className="text-base font-bold text-white">Payment, Wallet & Refund Transactions</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-3">Txn ID</th>
                    <th className="p-3">User</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Description</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {transactions.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-950/60">
                      <td className="p-3 font-mono text-amber-400">{t.id}</td>
                      <td className="p-3">
                        <span className="font-bold text-white">{t.userName}</span>{' '}
                        <span className="text-[10px] text-slate-500 uppercase">({t.userRole})</span>
                      </td>
                      <td className="p-3 uppercase text-[10px] font-semibold text-cyan-300">
                        {t.category.replace('_', ' ')}
                      </td>
                      <td className="p-3 text-slate-300">{t.description}</td>
                      <td className={`p-3 font-bold ${t.type === 'credit' ? 'text-emerald-400' : 'text-white'}`}>
                        {t.type === 'credit' ? '+' : '-'}₹{t.amount}
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] uppercase font-bold bg-emerald-500/20 text-emerald-400">
                          {t.status}
                        </span>
                      </td>
                      <td className="p-3 text-slate-400">{new Date(t.createdAt).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3C: CUSTOMER COMPLAINTS & REFUND DISPUTES */}
      {adminTab === 'complaints' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white">Customer Complaints & Dispute Resolution</h2>
              <p className="text-xs text-slate-400">
                Review fare disputes, driver feedback, and issue direct wallet refunds when warranted.
              </p>
            </div>
            <select
              value={complaintFilter}
              onChange={(e) => setComplaintFilter(e.target.value as any)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-amber-400 font-semibold focus:outline-none"
            >
              <option value="all">All Tickets ({complaints.length})</option>
              <option value="open">Open</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>

          <div className="space-y-3">
            {complaints
              .filter((c) => complaintFilter === 'all' || c.status === complaintFilter)
              .map((c) => (
                <div
                  key={c.id}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-amber-400">{c.id}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold ${
                          c.status === 'resolved'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : c.status === 'in_progress'
                            ? 'bg-cyan-500/20 text-cyan-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {c.status.replace('_', ' ')}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] uppercase text-slate-300">
                        {c.category.replace('_', ' ')}
                      </span>
                      {c.rideId && <span className="text-slate-400 font-mono">Ride: {c.rideId}</span>}
                    </div>
                    <h4 className="font-bold text-white text-sm">{c.subject}</h4>
                    <p className="text-slate-300">{c.details}</p>
                    <p className="text-[11px] text-slate-400">
                      Customer: <strong className="text-slate-200">{c.customerName}</strong> ({c.customerPhone})
                      {c.driverName ? ` • Captain: ${c.driverName}` : ''}
                    </p>
                    {c.resolutionNote && (
                      <p className="text-[11px] text-emerald-300 pt-1">
                        Resolution: {c.resolutionNote}
                        {c.refundIssued ? ` • Refund Issued: ₹${c.refundIssued}` : ''}
                      </p>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setResolvingComplaint(c);
                      setResolutionStatus(c.status === 'resolved' ? 'resolved' : 'resolved');
                      setResolutionNote(c.resolutionNote || '');
                      setRefundAmount(String(c.refundIssued || 0));
                    }}
                    className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shrink-0"
                  >
                    {c.status === 'resolved' ? 'Edit Resolution' : 'Review & Resolve'}
                  </button>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* SECTION 4: FARES & COMMISSION MATRIX */}
      {adminTab === 'fares' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white">Rate Card & Commission Matrix</h2>
              <p className="text-xs text-slate-400">
                Configure base fare, per-kilometer rate, minimum charges, and Maya platform commission % per vehicle category.
              </p>
            </div>
            {fareSavedToast && (
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Rate card updated live!
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(['bike', 'auto', 'car'] as const).map((vType) => {
              const currentSetting =
                fareSettings.find((f) => f.vehicleType === vType) || {
                  baseFare: vType === 'bike' ? 15 : vType === 'auto' ? 25 : 60,
                  perKmRate: vType === 'bike' ? 7 : vType === 'auto' ? 11 : 18,
                  minFare: vType === 'bike' ? 25 : vType === 'auto' ? 35 : 90,
                  commissionPercent: vType === 'bike' ? 12 : vType === 'auto' ? 15 : 18,
                };
              const editState = editingFares[vType] || currentSetting;

              // Sample 10km trip calculation preview
              const sampleDist = 10;
              const sampleBase = editState.baseFare || 30;
              const samplePerKm = editState.perKmRate || 10;
              const sampleSubtotal = Math.max(editState.minFare || 40, sampleBase + sampleDist * samplePerKm);
              const sampleComm = Math.round(sampleSubtotal * ((editState.commissionPercent || 15) / 100));

              return (
                <div
                  key={vType}
                  className="p-5 rounded-3xl bg-slate-950 border border-slate-800 space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-lg text-xs font-black uppercase bg-amber-400 text-slate-950">
                        {vType}
                      </span>
                      <span className="text-xs text-slate-400">
                        Last saved: {new Date().toLocaleDateString()}
                      </span>
                    </div>

                    <h3 className="font-bold text-white text-base capitalize">
                      Maya {vType} Rates
                    </h3>
                  </div>

                  {/* Form fields */}
                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="text-slate-400 block mb-1">Base Fare (₹)</label>
                      <input
                        type="number"
                        value={editState.baseFare ?? currentSetting.baseFare}
                        onChange={(e) =>
                          setEditingFares({
                            ...editingFares,
                            [vType]: { ...editState, baseFare: Number(e.target.value) },
                          })
                        }
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1">Per Km Rate (₹/km)</label>
                      <input
                        type="number"
                        value={editState.perKmRate ?? currentSetting.perKmRate}
                        onChange={(e) =>
                          setEditingFares({
                            ...editingFares,
                            [vType]: { ...editState, perKmRate: Number(e.target.value) },
                          })
                        }
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1">Minimum Fare (₹)</label>
                      <input
                        type="number"
                        value={editState.minFare ?? currentSetting.minFare}
                        onChange={(e) =>
                          setEditingFares({
                            ...editingFares,
                            [vType]: { ...editState, minFare: Number(e.target.value) },
                          })
                        }
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1">Maya Commission (%)</label>
                      <input
                        type="number"
                        min={5}
                        max={40}
                        value={editState.commissionPercent ?? currentSetting.commissionPercent}
                        onChange={(e) =>
                          setEditingFares({
                            ...editingFares,
                            [vType]: { ...editState, commissionPercent: Number(e.target.value) },
                          })
                        }
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  {/* Live Simulation Preview */}
                  <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 text-[11px] space-y-1">
                    <span className="text-slate-400 uppercase font-semibold text-[10px] block">
                      Formula Preview (10 km trip)
                    </span>
                    <div className="flex justify-between text-slate-300">
                      <span>Customer Total:</span>
                      <span className="font-bold text-white">₹{sampleSubtotal}</span>
                    </div>
                    <div className="flex justify-between text-emerald-400">
                      <span>Maya Commission ({editState.commissionPercent}%):</span>
                      <span className="font-bold">₹{sampleComm}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSaveFares(vType)}
                    className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer"
                  >
                    Save {vType.toUpperCase()} Rates
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 5: USERS & DRIVERS DIRECTORY */}
      {adminTab === 'users' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white">Users & Captains Directory</h2>
              <p className="text-xs text-slate-400">
                Manage all registered customers, drivers, and admin accounts.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Search user name, email, phone..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 w-56"
              />

              <select
                value={userRoleFilter}
                onChange={(e) => setUserRoleFilter(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-amber-400 font-semibold focus:outline-none"
              >
                <option value="all">All Roles</option>
                <option value="customer">Customers Only</option>
                <option value="driver">Drivers Only</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3">User Profile</th>
                  <th className="p-3">Role</th>
                  <th className="p-3">Phone</th>
                  <th className="p-3">Joined Date</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-950/60 transition-colors">
                    <td className="p-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={u.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                          alt={u.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <p className="font-bold text-white">{u.name}</p>
                          <p className="text-[11px] text-slate-400">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-slate-800 text-slate-200 border border-slate-700">
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-slate-300">{u.phone}</td>
                    <td className="p-3 text-slate-400">
                      {new Date(u.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold ${
                          u.status === 'active'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : u.status === 'pending'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {u.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      {u.role !== 'admin' && (
                        <button
                          type="button"
                          onClick={async () => {
                            const willBlock = u.status !== 'blocked';
                            await toggleAccountBlock(u.id, willBlock);
                            showToast(
                              willBlock
                                ? `Blocked account ${u.name}`
                                : `Unblocked account ${u.name}`
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold ${
                            u.status !== 'blocked'
                              ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                              : 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30'
                          }`}
                        >
                          {u.status !== 'blocked' ? 'Block' : 'Unblock'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 6: ANALYTICS & REPORTS */}
      {adminTab === 'reports' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white">Business Intelligence & Export</h2>
              <p className="text-xs text-slate-400">
                Performance trends, vehicle volume analytics, and exportable financial reports.
              </p>
            </div>

            <button
              type="button"
              onClick={handleExportReport}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV Report</span>
            </button>
          </div>

          {/* Revenue Bar Breakdown */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <h3 className="font-bold text-sm text-white">Revenue Split & Platform Retention</h3>
            <div className="h-6 w-full rounded-full bg-slate-800 overflow-hidden flex">
              <div
                style={{ width: `${Math.round(((totalGrossRevenue - totalCommissionEarned) / (totalGrossRevenue || 1)) * 100)}%` }}
                className="bg-emerald-500 h-full flex items-center justify-center text-[10px] font-bold text-slate-950"
                title="Driver Payouts"
              >
                Captains (82%)
              </div>
              <div
                style={{ width: `${Math.round((totalCommissionEarned / (totalGrossRevenue || 1)) * 100)}%` }}
                className="bg-amber-400 h-full flex items-center justify-center text-[10px] font-bold text-slate-950"
                title="Maya Commission"
              >
                Maya (18%)
              </div>
            </div>
            <div className="flex justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                Driver Net Payouts: ₹{(totalGrossRevenue - totalCommissionEarned).toLocaleString()}
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                Maya Commission: ₹{totalCommissionEarned.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Fleet Performance Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {(['bike', 'auto', 'car'] as const).map((v) => {
              const vRides = rides.filter((r) => r.vehicleType === v);
              const vRev = vRides.reduce((s, r) => s + r.fare, 0);
              const vComm = vRides.reduce((s, r) => s + r.platformFee, 0);

              return (
                <div key={v} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-extrabold uppercase text-amber-400 text-sm">{v} Segment</span>
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Total Trips:</span>
                      <span className="text-white font-bold">{vRides.length}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Gross Bookings:</span>
                      <span className="text-white font-bold">₹{vRev}</span>
                    </div>
                    <div className="flex justify-between text-emerald-400">
                      <span>Platform Commission:</span>
                      <span className="font-bold">₹{vComm}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SELECTED BOOKING DETAILS MODAL */}
      {selectedBooking && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-mono block">
                  Trip Details
                </span>
                <h3 className="font-bold text-sm text-white">{selectedBooking.id}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedBooking(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="text-xs space-y-2.5">
              <div className="p-3 rounded-xl bg-slate-950 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase">Passenger Details</span>
                <p className="font-bold text-white">{selectedBooking.customerName}</p>
                <p className="text-slate-400">{selectedBooking.customerPhone}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase">Driver & Vehicle</span>
                <p className="font-bold text-white">{selectedBooking.driverName || 'None Assigned'}</p>
                <p className="text-amber-400 uppercase">{selectedBooking.vehicleType} • {selectedBooking.vehicleModel || 'N/A'}</p>
                <p className="font-mono text-slate-400">{selectedBooking.vehicleNumber || 'N/A'}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 space-y-1.5">
                <span className="text-[10px] text-slate-400 uppercase">Route Details</span>
                <p className="text-slate-300">
                  <span className="text-cyan-400 mr-1 font-bold">P:</span> {selectedBooking.pickupAddress}
                </p>
                <p className="text-slate-300">
                  <span className="text-amber-400 mr-1 font-bold">D:</span> {selectedBooking.dropAddress}
                </p>
                <p className="text-slate-500">{selectedBooking.distanceKm} km • ~{selectedBooking.estimatedMinutes} mins</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Customer Fare</span>
                  <span className="font-bold text-white">₹{selectedBooking.fare}</span>
                </div>
                <div className="flex justify-between text-emerald-400 font-semibold">
                  <span>Maya Platform Commission</span>
                  <span>+₹{selectedBooking.platformFee}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Driver Payout</span>
                  <span>₹{selectedBooking.fare - selectedBooking.platformFee}</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              {selectedBooking.status !== 'completed' && selectedBooking.status !== 'cancelled' && (
                <button
                  type="button"
                  onClick={async () => {
                    await cancelRide(selectedBooking.id, 'Admin override cancellation', 'admin');
                    setSelectedBooking(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs"
                >
                  Force Cancel Ride
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedBooking(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
      {/* DRIVER DOCUMENT VERIFICATION MODAL */}
      {inspectingDriver && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] text-amber-400 uppercase font-bold block">
                  KYC Document Verification
                </span>
                <h3 className="font-bold text-sm text-white">
                  {inspectingDriver.name} • {inspectingDriver.vehicleNumber}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setInspectingDriver(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">
                  Driving Licence ({inspectingDriver.licenseNumber})
                </span>
                {inspectingDriver.licenseDocUrl ? (
                  <img
                    src={inspectingDriver.licenseDocUrl}
                    alt="Driving Licence"
                    className="w-full h-36 object-cover rounded-xl border border-slate-700"
                  />
                ) : (
                  <div className="h-36 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500">
                    No DL Image Uploaded
                  </div>
                )}
              </div>

              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">
                  Vehicle RC ({inspectingDriver.vehicleModel})
                </span>
                {inspectingDriver.vehicleRcDocUrl ? (
                  <img
                    src={inspectingDriver.vehicleRcDocUrl}
                    alt="Vehicle RC"
                    className="w-full h-36 object-cover rounded-xl border border-slate-700"
                  />
                ) : (
                  <div className="h-36 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500">
                    No RC Image Uploaded
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-1.5 text-xs">
              <label className="text-slate-400 block font-semibold">
                Rejection Note (Required only if rejecting)
              </label>
              <input
                type="text"
                placeholder="e.g. Driving licence photo is blurry, please re-upload."
                value={docRejectReason}
                onChange={(e) => setDocRejectReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={async () => {
                  await verifyDriverDocument(
                    inspectingDriver.id,
                    'rejected',
                    docRejectReason || 'Uploaded documents could not be verified.'
                  );
                  showToast(`Marked ${inspectingDriver.name}'s documents as rejected.`);
                  setInspectingDriver(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 font-bold text-xs"
              >
                Reject Documents
              </button>
              <button
                type="button"
                onClick={async () => {
                  await verifyDriverDocument(inspectingDriver.id, 'verified');
                  showToast(`Verified documents & approved ${inspectingDriver.name}!`);
                  setInspectingDriver(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs"
              >
                Verify Docs & Approve
              </button>
            </div>
          </div>
        </div>
      )}

      {/* COMPLAINT RESOLUTION & REFUND MODAL */}
      {resolvingComplaint && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] text-amber-400 font-mono block">
                  {resolvingComplaint.id}
                </span>
                <h3 className="font-bold text-sm text-white">{resolvingComplaint.subject}</h3>
              </div>
              <button
                type="button"
                onClick={() => setResolvingComplaint(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
                {resolvingComplaint.details}
              </p>

              <div>
                <label className="text-slate-400 block mb-1">Ticket Status</label>
                <select
                  value={resolutionStatus}
                  onChange={(e) => setResolutionStatus(e.target.value as CustomerComplaint['status'])}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="in_progress">In Progress</option>
                  <option value="resolved">Resolved</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Wallet Refund Amount (₹, optional)</label>
                <input
                  type="number"
                  min={0}
                  value={refundAmount}
                  onChange={(e) => setRefundAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Admin Resolution Note</label>
                <textarea
                  value={resolutionNote}
                  onChange={(e) => setResolutionNote(e.target.value)}
                  placeholder="Describe action taken or refund issued..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white h-20 resize-none focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                type="button"
                onClick={async () => {
                  const refAmt = Number(refundAmount) || 0;
                  await updateComplaintStatus(
                    resolvingComplaint.id,
                    resolutionStatus,
                    resolutionNote,
                    refAmt > 0 ? refAmt : undefined
                  );
                  showToast(
                    `Ticket ${resolvingComplaint.id} updated${refAmt > 0 ? ` with ₹${refAmt} wallet refund` : ''}.`
                  );
                  setResolvingComplaint(null);
                }}
                className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
              >
                Save Resolution & Notify Customer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
