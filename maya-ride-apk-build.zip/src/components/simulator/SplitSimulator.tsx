import React from 'react';
import { CustomerApp } from '../customer/CustomerApp';
import { DriverApp } from '../driver/DriverApp';
import { useRide } from '../../context/RideContext';
import { Smartphone, Car, Sparkles, ArrowRightLeft } from 'lucide-react';

export const SplitSimulator: React.FC = () => {
  const { rides } = useRide();
  const liveRides = rides.filter(
    (r) =>
      r.status === 'requested' ||
      r.status === 'accepted' ||
      r.status === 'arriving' ||
      r.status === 'in_progress'
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Simulator instructions & banner */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-md">
            <ArrowRightLeft className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Maya Ride Connected Dual Simulator
              <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase font-bold">
                Live 2-Way Sync
              </span>
            </h2>
            <p className="text-slate-400 text-[11px]">
              Book a ride on the Customer screen (Left) and watch it pop up in real-time on the Captain Driver screen (Right)!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-slate-950 text-amber-400 border border-slate-800 font-mono font-bold text-xs">
            {liveRides.length} Active Ride in Sync
          </span>
        </div>
      </div>

      {/* Dual Mobile Frames Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start justify-center">
        {/* Left Frame: Customer App */}
        <div className="flex flex-col items-center">
          <div className="mb-2 flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300">
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>Customer Mobile Screen</span>
          </div>
          <div className="w-full flex justify-center">
            <CustomerApp />
          </div>
        </div>

        {/* Right Frame: Driver App */}
        <div className="flex flex-col items-center">
          <div className="mb-2 flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300">
            <Car className="w-3.5 h-3.5 text-cyan-400" />
            <span>Driver (Captain) Mobile Screen</span>
          </div>
          <div className="w-full flex justify-center">
            <DriverApp />
          </div>
        </div>
      </div>
    </div>
  );
};
