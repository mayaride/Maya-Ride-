import React, { useEffect, useRef, useState } from 'react';
import { LocationPoint, RideStatus, VehicleType } from '../types';
import {
  MapPin,
  Navigation,
  Clock,
  Compass,
  AlertCircle,
  ExternalLink,
  ShieldAlert,
  Info,
  CheckCircle2,
  Route,
} from 'lucide-react';

interface InteractiveMapProps {
  pickup?: LocationPoint | { lat: number; lng: number; address?: string; name?: string; isManual?: boolean; isGpsDetected?: boolean };
  drop?: LocationPoint | { lat: number; lng: number; address?: string; name?: string; isManual?: boolean; isGpsDetected?: boolean };
  vehicleType?: VehicleType;
  status?: RideStatus;
  height?: string;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  pickup,
  drop,
  vehicleType = 'auto',
  status,
  height = 'h-52 sm:h-60',
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapsApiKey = (import.meta as any).env?.VITE_GOOGLE_MAPS_API_KEY;
  const isMapsConfigured = Boolean(mapsApiKey && mapsApiKey !== 'MY_GOOGLE_MAPS_API_KEY' && mapsApiKey !== '');

  const [mapLoaded, setMapLoaded] = useState(false);
  const [showConfigHelper, setShowConfigHelper] = useState(false);

  // Load actual Google Maps only if valid API key is present
  useEffect(() => {
    if (!isMapsConfigured || !mapRef.current) return;

    // Check if google maps script is already on page
    if (!(window as any).google?.maps) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${mapsApiKey}&libraries=places,geometry`;
      script.async = true;
      script.defer = true;
      script.onload = () => initRealMap();
      document.head.appendChild(script);
    } else {
      initRealMap();
    }

    function initRealMap() {
      if (!mapRef.current || !(window as any).google?.maps) return;
      const center = pickup ? { lat: pickup.lat, lng: pickup.lng } : { lat: 25.2162, lng: 80.9168 }; // Karwi, Chitrakoot
      const map = new (window as any).google.maps.Map(mapRef.current, {
        center,
        zoom: 13,
        mapId: 'DEMO_MAP_ID',
        disableDefaultUI: true,
        zoomControl: true,
      });

      if (pickup) {
        new (window as any).google.maps.Marker({
          position: { lat: pickup.lat, lng: pickup.lng },
          map,
          title: pickup.name || 'Pickup',
          label: 'P',
        });
      }

      if (drop) {
        new (window as any).google.maps.Marker({
          position: { lat: drop.lat, lng: drop.lng },
          map,
          title: drop.name || 'Drop',
          label: 'D',
        });
      }

      setMapLoaded(true);
    }
  }, [isMapsConfigured, pickup, drop]);

  // If actual Maps API is configured and loaded
  if (isMapsConfigured) {
    return (
      <div className={`relative w-full ${height} rounded-2xl overflow-hidden border border-slate-700 bg-slate-950`}>
        <div ref={mapRef} className="w-full h-full" />
        <div className="absolute top-2 left-2 px-2.5 py-1 rounded-md bg-slate-900/90 text-[10px] text-emerald-400 font-medium border border-slate-700 shadow flex items-center gap-1">
          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          <span>Google Maps Active</span>
        </div>
      </div>
    );
  }

  // If Maps API is NOT configured:
  // Strictly comply with "Never show fake live GPS locations" & "Show actual map only when Maps API is configured".
  // Render an honest, beautifully styled Route Schematic Card.
  return (
    <div className={`relative w-full ${height} rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 p-4 flex flex-col justify-between select-none shadow-inner`}>
      {/* Top Header: Route Identification & Status */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-amber-400/10 text-amber-400 flex items-center justify-center">
            <Route className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
              Trip Navigation Route
            </span>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Karwi - Chitrakoot Sector</span>
              <span className="text-[10px] text-amber-400 uppercase font-semibold">({vehicleType})</span>
            </h4>
          </div>
        </div>

        {/* Maps API Notice Badge */}
        <button
          type="button"
          onClick={() => setShowConfigHelper(!showConfigHelper)}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-[10px] text-slate-300 font-medium transition-colors"
          title="Click to view Maps API status"
        >
          <Info className="w-3 h-3 text-amber-400" />
          <span>Maps API Offline</span>
        </button>
      </div>

      {/* Center Route Diagram (Clear schematic representation, no fake satellite movement) */}
      <div className="my-2 p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-2.5">
        {/* Pickup Item */}
        <div className="flex items-start gap-2.5">
          <div className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5 font-bold text-[10px] border border-cyan-500/40">
            P
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wide">
                Pickup Location
              </span>
              {pickup?.isGpsDetected && (
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                  Real Device GPS
                </span>
              )}
              {pickup?.isManual && (
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 font-semibold border border-amber-400/30">
                  Manual Entry
                </span>
              )}
            </div>
            <p className="text-xs font-semibold text-white truncate">
              {pickup?.name || 'Select Pickup Location'}
            </p>
            {pickup && 'lat' in pickup && (
              <p className="text-[10px] font-mono text-slate-500">
                Coords: {pickup.lat.toFixed(4)}° N, {pickup.lng.toFixed(4)}° E
              </p>
            )}
          </div>
        </div>

        {/* Connecting Track Line */}
        <div className="ml-2.5 pl-3 border-l-2 border-dashed border-slate-700 py-0.5 flex items-center justify-between text-[10px] text-slate-400">
          <span>Via Karwi-Chitrakoot NH-35 / Link Road</span>
          <span className="text-amber-400 font-semibold">Local Regional Transit</span>
        </div>

        {/* Drop Item */}
        <div className="flex items-start gap-2.5">
          <div className="w-5 h-5 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5 font-bold text-[10px] border border-amber-400/40">
            D
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wide">
                Destination
              </span>
              {drop?.isManual && (
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 font-semibold border border-amber-400/30">
                  Manual Entry
                </span>
              )}
            </div>
            <p className="text-xs font-semibold text-white truncate">
              {drop?.name || 'Select Destination'}
            </p>
            {drop && 'lat' in drop && (
              <p className="text-[10px] font-mono text-slate-500">
                Coords: {drop.lat.toFixed(4)}° N, {drop.lng.toFixed(4)}° E
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Status Bar */}
      <div className="flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          <span className="text-slate-300 font-medium">
            {status === 'requested' && 'Searching for Captains in Karwi & Chitrakoot...'}
            {status === 'accepted' && 'Captain assigned • Heading to your location'}
            {status === 'arriving' && 'Captain has arrived at pickup'}
            {status === 'in_progress' && 'Trip ongoing • In-transit'}
            {status === 'completed' && 'Trip reached destination'}
            {(!status || status === 'cancelled') && 'Ready to book Maya Ride'}
          </span>
        </div>

        <span className="text-[10px] font-mono text-slate-500">
          Schematic Navigation
        </span>
      </div>

      {/* Expandable Maps API Info Drawer */}
      {showConfigHelper && (
        <div className="absolute inset-x-2 bottom-2 p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 space-y-2 shadow-2xl z-20">
          <div className="flex items-center justify-between font-bold text-white">
            <span className="flex items-center gap-1.5 text-amber-400">
              <Info className="w-4 h-4" /> Google Maps Integration
            </span>
            <button
              type="button"
              onClick={() => setShowConfigHelper(false)}
              className="text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>
          <p className="text-[11px] text-slate-400">
            Maya Ride shows actual Google Maps tiles when <code className="text-amber-300 font-mono">VITE_GOOGLE_MAPS_API_KEY</code> is configured in environment secrets.
          </p>
          <p className="text-[11px] text-emerald-400">
            All Karwi & Chitrakoot booking, fare calculation, driver matching, and ride status updates work completely without requiring an external map API.
          </p>
        </div>
      )}
    </div>
  );
};
