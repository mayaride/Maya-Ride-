import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import {
  Lock,
  Mail,
  User as UserIcon,
  Phone,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Smartphone,
  ShieldCheck,
  Send,
  RotateCw,
} from 'lucide-react';
import { sendPhoneOtp, setupRecaptcha } from '../../services/firebase';

interface CustomerAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CustomerAuthModal: React.FC<CustomerAuthModalProps> = ({ isOpen, onClose }) => {
  const {
    registerCustomer,
    loginCustomer,
    loginWithPhoneOtp,
    loginWithGoogle,
    users,
    setCurrentUser,
  } = useRide();

  // Tab: 'phone' | 'email' | 'signup'
  const [authMethod, setAuthMethod] = useState<'phone' | 'email' | 'signup'>('phone');

  // Phone OTP state
  const [phoneNumber, setPhoneNumber] = useState('+91 94501 23456');
  const [passengerName, setPassengerName] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<any>(null);
  const [timerCount, setTimerCount] = useState(30);

  // Email/Password state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Status indicators
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle Send OTP
  const handleSendPhoneOtp = async () => {
    const raw = phoneNumber.trim();
    if (!raw || raw.replace(/[^0-9]/g, '').length < 10) {
      setErrorMsg('Please enter a valid 10-digit Indian mobile number (+91).');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      // In web preview environment, setup recaptcha and trigger Firebase sendPhoneOtp
      let verifier: any = null;
      try {
        verifier = setupRecaptcha('recaptcha-container');
      } catch {
        // Fallback
      }

      const res = await sendPhoneOtp(raw, verifier);
      setConfirmationResult(res);
      setOtpSent(true);
      setTimerCount(30);
      setSuccessMsg(`6-digit OTP dispatched via Firebase SMS to ${raw}.`);
    } catch (err: any) {
      console.warn('Phone OTP preview notice:', err?.message);
      setConfirmationResult(null);
      setOtpSent(true);
      setSuccessMsg(
        `Preview OTP Mode for ${raw}: Enter 6 digits (e.g. 123456) to test, or configure Firebase Authorized Domains for live SMS.`
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Verify OTP
  const handleVerifyOtp = async () => {
    if (otpCode.trim().length !== 6) {
      setErrorMsg('Please enter a valid 6-digit verification code.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    try {
      if (confirmationResult && confirmationResult.confirm) {
        await confirmationResult.confirm(otpCode.trim());
      }

      await loginWithPhoneOtp(phoneNumber, passengerName);
      setSuccessMsg('Phone verified successfully! Logged in.');
      setTimeout(() => onClose(), 1000);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Invalid OTP verification code. Please check and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Email/Password Form
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      if (authMethod === 'signup') {
        if (!name.trim() || !phone.trim() || !email.trim() || !password) {
          throw new Error('Please fill in all required registration fields.');
        }
        if (password.length < 6) {
          throw new Error('Password must be at least 6 characters.');
        }

        await registerCustomer(name, email, phone, password);
        setSuccessMsg('Passenger account created with Firebase Auth!');
        setTimeout(() => onClose(), 1200);
      } else {
        if (!email.trim() || !password) {
          throw new Error('Please enter email and password.');
        }

        await loginCustomer(email, password);
        setSuccessMsg('Signed in successfully!');
        setTimeout(() => onClose(), 1000);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Google Login
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      await loginWithGoogle();
      setSuccessMsg('Google authentication successful!');
      setTimeout(() => onClose(), 1000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Google sign-in could not be completed.');
    } finally {
      setIsLoading(false);
    }
  };

  // Quick Demo Customer Login
  const handleQuickDemoCustomer = () => {
    const demoCust = users.find((u) => u.role === 'customer') || {
      id: 'user_customer_1',
      name: 'Abhishek Mishra',
      email: 'abhishek.karwi@example.com',
      phone: '+91 94501 23456',
      role: 'customer' as const,
      status: 'active' as const,
      walletBalance: 450,
      totalRides: 12,
      createdAt: new Date().toISOString(),
    };
    setCurrentUser(demoCust);
    setSuccessMsg('Logged in as Abhishek Mishra (Karwi Passenger)');
    setTimeout(() => onClose(), 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      {/* Invisible Recaptcha target container */}
      <div id="recaptcha-container" className="hidden" />

      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-4 sm:p-5 space-y-3.5 shadow-2xl max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 font-black flex items-center justify-center text-sm shadow">
              M
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Passenger Portal</h3>
              <p className="text-[11px] text-amber-400 font-semibold">Maya Ride • Karwi & Chitrakoot</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-xs"
          >
            ✕
          </button>
        </div>

        {/* Method Toggle Tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-semibold">
          <button
            type="button"
            onClick={() => {
              setAuthMethod('phone');
              setErrorMsg(null);
            }}
            className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              authMethod === 'phone'
                ? 'bg-amber-400 text-slate-950 shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            <span>Mobile OTP</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMethod('email');
              setErrorMsg(null);
            }}
            className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              authMethod === 'email'
                ? 'bg-amber-400 text-slate-950 shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-3 h-3" />
            <span>Sign In</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMethod('signup');
              setErrorMsg(null);
            }}
            className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              authMethod === 'signup'
                ? 'bg-amber-400 text-slate-950 shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserIcon className="w-3 h-3" />
            <span>Register</span>
          </button>
        </div>

        {/* Status Alerts */}
        {errorMsg && (
          <div className="p-2.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span className="leading-tight">{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span className="leading-tight">{successMsg}</span>
          </div>
        )}

        {/* TAB 1: PHONE NUMBER OTP AUTHENTICATION */}
        {authMethod === 'phone' && (
          <div className="space-y-3 text-xs">
            {!otpSent ? (
              <div className="space-y-2.5">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                    Your Name (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Priyanshu Shukla"
                    value={passengerName}
                    onChange={(e) => setPassengerName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                    Mobile Phone Number *
                  </label>
                  <div className="relative flex items-center">
                    <span className="absolute left-3 text-amber-400 font-bold text-xs">🇮🇳 +91</span>
                    <input
                      type="tel"
                      required
                      placeholder="94501 23456"
                      value={phoneNumber.replace('+91 ', '').replace('+91', '')}
                      onChange={(e) => setPhoneNumber(`+91 ${e.target.value.replace(/[^0-9]/g, '')}`)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-16 pr-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1">
                    Standard 10-digit Indian SIM required for ride SMS alerts.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleSendPhoneOtp}
                  disabled={isLoading}
                  className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md flex items-center justify-center gap-1.5 cursor-pointer mt-1"
                >
                  {isLoading ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent animate-spin rounded-full" />
                      <span>Sending OTP...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Send 6-Digit OTP</span>
                    </>
                  )}
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block">OTP Sent To:</span>
                    <span className="font-mono font-bold text-white">{phoneNumber}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="text-[10px] text-amber-400 underline"
                  >
                    Change
                  </button>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                    Enter 6-Digit Verification Code *
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    placeholder="1 2 3 4 5 6"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-center text-lg font-mono tracking-widest text-amber-400 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleVerifyOtp}
                  disabled={isLoading}
                  className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {isLoading ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent animate-spin rounded-full" />
                      <span>Verifying OTP...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>Verify & Sign In</span>
                    </>
                  )}
                </button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={handleSendPhoneOtp}
                    className="text-[11px] text-slate-400 hover:text-amber-400 flex items-center justify-center gap-1 mx-auto"
                  >
                    <RotateCw className="w-3 h-3" />
                    <span>Resend OTP Code</span>
                  </button>
                </div>
              </div>
            )}

            {/* Google Quick Sign In */}
            <div className="pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-all"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2 & 3: EMAIL / PASSWORD */}
        {(authMethod === 'email' || authMethod === 'signup') && (
          <form onSubmit={handleEmailSubmit} className="space-y-2.5 text-xs">
            {authMethod === 'signup' && (
              <>
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                    Full Name *
                  </label>
                  <div className="relative">
                    <UserIcon className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Abhishek Mishra"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                    Mobile Phone *
                  </label>
                  <div className="relative">
                    <Phone className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="tel"
                      required
                      placeholder="e.g. +91 94501 23456"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                Email Address *
              </label>
              <div className="relative">
                <Mail className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  placeholder="passenger@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                Password *
              </label>
              <div className="relative">
                <Lock className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Minimum 6 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-9 py-2 text-white focus:outline-none focus:border-amber-400"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md mt-1 cursor-pointer"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-1.5">
                  <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent animate-spin rounded-full" />
                  <span>Processing with Firebase...</span>
                </span>
              ) : authMethod === 'signup' ? (
                'Create Passenger Account'
              ) : (
                'Sign In'
              )}
            </button>
          </form>
        )}

        {/* Quick Demo 1-Tap Login */}
        <div className="pt-2 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-400 mb-1.5">Or test immediately with demo profile:</p>
          <button
            type="button"
            onClick={handleQuickDemoCustomer}
            className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-xs border border-slate-700 flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>1-Tap Demo Passenger Login</span>
          </button>
        </div>
      </div>
    </div>
  );
};
