import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { VehicleType } from '../../types';
import {
  Lock,
  Mail,
  User as UserIcon,
  Phone,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Car,
  Bike,
  FileText,
  Clock,
  ShieldCheck,
} from 'lucide-react';

interface DriverAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DriverAuthModal: React.FC<DriverAuthModalProps> = ({ isOpen, onClose }) => {
  const { registerDriverAccount, loginDriverAccount, drivers, setCurrentUser } = useRide();
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [licenseNumber, setLicenseNumber] = useState('');
  const [vehicleType, setVehicleType] = useState<VehicleType>('auto');
  const [vehicleModel, setVehicleModel] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [licenseDocUrl, setLicenseDocUrl] = useState<string>('');
  const [vehicleRcDocUrl, setVehicleRcDocUrl] = useState<string>('');
  const [licenseFileName, setLicenseFileName] = useState<string>('');
  const [rcFileName, setRcFileName] = useState<string>('');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'license' | 'rc') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (type === 'license') {
      setLicenseFileName(file.name);
    } else {
      setRcFileName(file.name);
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Url = reader.result as string;
      if (type === 'license') {
        setLicenseDocUrl(base64Url);
      } else {
        setVehicleRcDocUrl(base64Url);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      if (authMode === 'signup') {
        if (!name.trim() || !phone.trim() || !email.trim() || !password || !licenseNumber.trim() || !vehicleNumber.trim()) {
          throw new Error('Please fill in all vehicle and driver profile details.');
        }
        if (password.length < 6) {
          throw new Error('Password must be at least 6 characters.');
        }

        const newDriver = await registerDriverAccount({
          name,
          email,
          phone,
          pass: password,
          licenseNumber,
          vehicleType,
          vehicleModel: vehicleModel.trim() || (vehicleType === 'bike' ? 'Hero Splendor Plus' : vehicleType === 'auto' ? 'Bajaj RE Auto' : 'Maruti Dzire AC'),
          vehicleNumber: vehicleNumber.trim().toUpperCase(),
          licenseDocUrl: licenseDocUrl || 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?w=500&auto=format&fit=crop&q=80',
          vehicleRcDocUrl: vehicleRcDocUrl || 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=500&auto=format&fit=crop&q=80',
        });

        setSuccessMsg('Registration submitted with documents! Account is PENDING admin approval.');
        setTimeout(() => {
          onClose();
        }, 1500);
      } else {
        if (!email.trim() || !password) {
          throw new Error('Please enter email and password.');
        }

        const driver = await loginDriverAccount(email, password);
        setSuccessMsg(`Welcome back, Captain ${driver.name}!`);
        setTimeout(() => {
          onClose();
        }, 1000);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Driver authentication failed.');
    } finally {
      setIsLoading(false);
    }
  };

  // Quick 1-Tap Demo Captain Switch
  const handleQuickDemoDriver = (vType: VehicleType) => {
    const matched = drivers.find((d) => d.vehicleType === vType && d.approvalStatus === 'approved') || drivers[0];
    if (matched) {
      setCurrentUser({
        id: matched.id,
        name: matched.name,
        email: matched.email,
        phone: matched.phone,
        role: 'driver',
        avatar: matched.avatar,
        status: 'active',
        walletBalance: matched.walletBalance || 0,
        totalRides: matched.totalTrips || 0,
        createdAt: matched.createdAt,
      });
      setSuccessMsg(`Logged in as ${matched.name} (${matched.vehicleType.toUpperCase()} Captain)`);
      setTimeout(() => onClose(), 800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-4 sm:p-5 space-y-3.5 shadow-2xl max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 font-black flex items-center justify-center text-sm">
              🚖
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">
                {authMode === 'signup' ? 'Captain Registration' : 'Captain Portal Login'}
              </h3>
              <p className="text-[11px] text-amber-400 font-semibold">Maya Captain • Karwi & Chitrakoot</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-xs"
          >
            ✕
          </button>
        </div>

        {/* Auth Toggle Tabs */}
        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setErrorMsg(null);
            }}
            className={`py-1.5 rounded-lg transition-all ${
              authMode === 'login'
                ? 'bg-amber-400 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('signup');
              setErrorMsg(null);
            }}
            className={`py-1.5 rounded-lg transition-all ${
              authMode === 'signup'
                ? 'bg-amber-400 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Register Captain
          </button>
        </div>

        {/* Notice for Approval Rule */}
        {authMode === 'signup' && (
          <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] space-y-1">
            <span className="font-bold flex items-center gap-1 text-amber-400">
              <Clock className="w-3.5 h-3.5" /> Admin Approval Required
            </span>
            <p className="leading-tight text-slate-300">
              All registered driver accounts remain in <strong>PENDING</strong> status until verified and approved by the Maya Administrator.
            </p>
          </div>
        )}

        {/* Status Alerts */}
        {errorMsg && (
          <div className="p-2.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span className="leading-tight">{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span className="leading-tight">{successMsg}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-2.5 text-xs">
          {authMode === 'signup' && (
            <>
              <div>
                <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                  Captain Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramsewak Soni"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                  Mobile Phone *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +91 97950 33445"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                  Driving License Number *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. UP962022003411"
                  value={licenseNumber}
                  onChange={(e) => setLicenseNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400 font-mono uppercase"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                  Vehicle Category *
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['bike', 'auto', 'car'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setVehicleType(t)}
                      className={`py-1.5 rounded-lg border text-xs font-bold uppercase transition-all ${
                        vehicleType === t
                          ? 'bg-amber-400 text-slate-950 border-amber-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                  Vehicle Make & Model *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bajaj RE Auto / Hero Splendor / Dzire"
                  value={vehicleModel}
                  onChange={(e) => setVehicleModel(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
                  Registration Number (Chitrakoot UP-96) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. UP-96-T-4890"
                  value={vehicleNumber}
                  onChange={(e) => setVehicleNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400 font-mono uppercase"
                />
              </div>

              {/* Driving Licence Document Upload */}
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-semibold text-[11px] flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-amber-400" />
                    <span>Upload Driving Licence Document *</span>
                  </label>
                  {licenseDocUrl && (
                    <span className="text-[10px] text-emerald-400 font-bold">Attached</span>
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={(e) => handleFileUpload(e, 'license')}
                  className="w-full text-[11px] text-slate-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[10px] file:font-semibold file:bg-amber-400 file:text-slate-950 hover:file:bg-amber-300 cursor-pointer"
                />
                {licenseFileName && (
                  <p className="text-[10px] text-amber-300/80 truncate">File: {licenseFileName}</p>
                )}
              </div>

              {/* Vehicle Registration (RC) Document Upload */}
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-semibold text-[11px] flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Upload Vehicle Registration (RC) *</span>
                  </label>
                  {vehicleRcDocUrl && (
                    <span className="text-[10px] text-emerald-400 font-bold">Attached</span>
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={(e) => handleFileUpload(e, 'rc')}
                  className="w-full text-[11px] text-slate-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[10px] file:font-semibold file:bg-cyan-400 file:text-slate-950 hover:file:bg-cyan-300 cursor-pointer"
                />
                {rcFileName && (
                  <p className="text-[10px] text-cyan-300/80 truncate">File: {rcFileName}</p>
                )}
              </div>
            </>
          )}

          <div>
            <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
              Email Address *
            </label>
            <input
              type="email"
              required
              placeholder="captain@mayaride.in"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1 font-semibold text-[11px]">
              Password *
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Minimum 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 pr-9 py-2 text-white focus:outline-none focus:border-amber-400"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md mt-1 cursor-pointer"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-1.5">
                <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent animate-spin rounded-full" />
                <span>Processing with Firebase...</span>
              </span>
            ) : authMode === 'signup' ? (
              'Submit Captain Application'
            ) : (
              'Sign In to Duty'
            )}
          </button>
        </form>

        {/* 1-Tap Quick Demo Captains */}
        <div className="pt-2 border-t border-slate-800">
          <p className="text-[11px] text-slate-400 mb-1.5 text-center">Quick demo captain sign-in:</p>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              onClick={() => handleQuickDemoDriver('bike')}
              className="py-1.5 px-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold border border-slate-700 text-center"
            >
              🏍️ Bike
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemoDriver('auto')}
              className="py-1.5 px-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold border border-slate-700 text-center"
            >
              🛺 Auto
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemoDriver('car')}
              className="py-1.5 px-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold border border-slate-700 text-center"
            >
              🚗 Car
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
