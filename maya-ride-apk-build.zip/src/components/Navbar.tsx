import React, { useState } from 'react';
import { useRide, ActivePanel } from '../context/RideContext';
import {
  Car,
  Compass,
  LayoutDashboard,
  Smartphone,
  UserCheck,
  RefreshCw,
  ShieldCheck,
  CheckCircle2,
  Sliders,
  SplitSquareVertical,
  Check,
  X,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    activePanel,
    setActivePanel,
    currentUser,
    switchRole,
    resetToDemoData,
    drivers,
    rides,
  } = useRide();

  const [confirmReset, setConfirmReset] = useState(false);

  const pendingApprovals = drivers.filter((d) => d.approvalStatus === 'pending').length;
  const activeTripsCount = rides.filter(
    (r) => r.status === 'requested' || r.status === 'accepted' || r.status === 'arriving' || r.status === 'in_progress'
  ).length;

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-300 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950 font-black text-xl">
              M
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-tight text-white">
                  Maya<span className="text-amber-400">Ride</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30 uppercase">
                  v5.0
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Karwi & Chitrakoot, Uttar Pradesh
              </p>
            </div>
          </div>

          {/* Connected Panels Switcher */}
          <nav className="flex items-center p-1 bg-slate-950/80 rounded-xl border border-slate-800">
            {/* Customer Tab */}
            <button
              type="button"
              onClick={() => {
                switchRole('customer');
                setActivePanel('customer');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activePanel === 'customer'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Customer</span>
            </button>

            {/* Driver Tab */}
            <button
              type="button"
              onClick={() => {
                switchRole('driver');
                setActivePanel('driver');
              }}
              className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activePanel === 'driver'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>Driver App</span>
              {activeTripsCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              )}
            </button>

            {/* Admin Tab */}
            <button
              type="button"
              onClick={() => setActivePanel('admin')}
              className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activePanel === 'admin'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Admin</span>
              <span className="md:hidden">Admin</span>
              {pendingApprovals > 0 && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[10px] font-bold">
                  {pendingApprovals}
                </span>
              )}
            </button>

            {/* Dual Simulator View */}
            <button
              type="button"
              onClick={() => setActivePanel('simulator')}
              className={`hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activePanel === 'simulator'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
              title="Dual Screen Customer & Driver live simulator"
            >
              <SplitSquareVertical className="w-3.5 h-3.5" />
              <span>Dual Simulator</span>
            </button>
          </nav>

          {/* Right Action: User profile & Reset */}
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700/60 text-xs">
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                alt={currentUser.name}
                className="w-5 h-5 rounded-full object-cover ring-1 ring-amber-400"
              />
              <span className="text-slate-200 font-medium max-w-[100px] truncate">
                {currentUser.name.split(' ')[0]}
              </span>
              <span className="text-[10px] text-amber-400 uppercase font-bold tracking-wider">
                ({currentUser.role})
              </span>
            </div>

            {confirmReset ? (
              <div className="flex items-center gap-1 bg-slate-800 border border-amber-400/50 rounded-lg px-2 py-1 text-[11px]">
                <span className="text-amber-300 font-semibold">Reset?</span>
                <button
                  type="button"
                  onClick={() => {
                    resetToDemoData();
                    setConfirmReset(false);
                  }}
                  title="Confirm Reset Demo Data"
                  className="p-1 rounded bg-amber-400 text-slate-950 hover:bg-amber-300"
                >
                  <Check className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  title="Cancel Reset"
                  className="p-1 rounded bg-slate-700 text-slate-300 hover:bg-slate-600"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                title="Reset Demo Data"
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-amber-400 transition-colors border border-slate-700"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
