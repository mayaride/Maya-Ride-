import { initializeApp } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  User as FirebaseUser,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult,
  GoogleAuthProvider,
  signInWithPopup,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDocFromServer,
  collection,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  getDocs,
} from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';
import { AppNotification, CustomerComplaint, Driver, FareSetting, Ride, User, WalletTransaction } from '../types';
import {
  DEFAULT_COMPLAINTS,
  DEFAULT_DRIVERS,
  DEFAULT_FARE_SETTINGS,
  DEFAULT_NOTIFICATIONS,
  DEFAULT_RIDES,
  DEFAULT_TRANSACTIONS,
  DEFAULT_USERS,
} from '../data/mockData';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.warn('Firestore Operation Notice: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Initialize Firebase App
export const app = initializeApp(firebaseConfig);

// CRITICAL: Initialize Firestore with the database ID from config as per guidelines
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Auth instance
export const auth = getAuth(app);

// Storage instance
export const storage = getStorage(app);

// Connection test as required by skill
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline, using reactive sync mode.');
    }
    return false;
  }
}

// Run connection test non-blocking
testConnection().catch(() => {
  // Silent catch
});

// Storage keys for local resilience & demo state (Karwi, Chitrakoot UP)
const LOCAL_STORAGE_KEY_RIDES = 'maya_rides_karwi_v3';
const LOCAL_STORAGE_KEY_DRIVERS = 'maya_drivers_karwi_v3';
const LOCAL_STORAGE_KEY_USERS = 'maya_users_karwi_v3';
const LOCAL_STORAGE_KEY_FARES = 'maya_fares_karwi_v3';
const LOCAL_STORAGE_KEY_COMPLAINTS = 'maya_complaints_karwi_v3';
const LOCAL_STORAGE_KEY_TRANSACTIONS = 'maya_transactions_karwi_v3';
const LOCAL_STORAGE_KEY_NOTIFICATIONS = 'maya_notifications_karwi_v3';

export function getCachedRides(): Ride[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_RIDES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_RIDES;
}

export function saveCachedRides(rides: Ride[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_RIDES, JSON.stringify(rides));
  } catch (e) {
    console.error(e);
  }
}

export function getCachedDrivers(): Driver[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_DRIVERS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_DRIVERS;
}

export function saveCachedDrivers(drivers: Driver[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_DRIVERS, JSON.stringify(drivers));
  } catch (e) {
    console.error(e);
  }
}

export function getCachedUsers(): User[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_USERS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_USERS;
}

export function saveCachedUsers(users: User[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_USERS, JSON.stringify(users));
  } catch (e) {
    console.error(e);
  }
}

export function getCachedFares(): FareSetting[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_FARES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_FARE_SETTINGS;
}

export function saveCachedFares(fares: FareSetting[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_FARES, JSON.stringify(fares));
  } catch (e) {
    console.error(e);
  }
}

export function getCachedComplaints(): CustomerComplaint[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_COMPLAINTS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_COMPLAINTS;
}

export function saveCachedComplaints(complaints: CustomerComplaint[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_COMPLAINTS, JSON.stringify(complaints));
  } catch (e) {
    console.error(e);
  }
}

export function getCachedTransactions(): WalletTransaction[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TRANSACTIONS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_TRANSACTIONS;
}

export function saveCachedTransactions(txns: WalletTransaction[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_TRANSACTIONS, JSON.stringify(txns));
  } catch (e) {
    console.error(e);
  }
}

export function getCachedNotifications(): AppNotification[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_NOTIFICATIONS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return DEFAULT_NOTIFICATIONS;
}

export function saveCachedNotifications(notifs: AppNotification[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_NOTIFICATIONS, JSON.stringify(notifs));
  } catch (e) {
    console.error(e);
  }
}

// System Admin Email check
export const SYSTEM_ADMIN_EMAIL = 'dps8318.la9312@gmail.com';

export function isSystemAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  return email.toLowerCase() === SYSTEM_ADMIN_EMAIL.toLowerCase();
}

// Firebase Auth Wrappers with resilient error messaging
export async function firebaseRegisterUser(email: string, pass: string, name: string): Promise<FirebaseUser> {
  const credential = await createUserWithEmailAndPassword(auth, email, pass);
  if (name && credential.user) {
    await updateProfile(credential.user, { displayName: name });
  }
  return credential.user;
}

export async function firebaseLoginUser(email: string, pass: string): Promise<FirebaseUser> {
  const credential = await signInWithEmailAndPassword(auth, email, pass);
  return credential.user;
}

export async function firebaseLogoutUser(): Promise<void> {
  await signOut(auth);
}

export async function firebaseGoogleLogin(): Promise<FirebaseUser> {
  const provider = new GoogleAuthProvider();
  const result = await signInWithPopup(auth, provider);
  return result.user;
}

// Phone Number OTP Verification with RecaptchaVerifier
export function setupRecaptcha(containerId: string): RecaptchaVerifier {
  // Clear any existing element instance
  const existing = (window as any).recaptchaVerifier;
  if (existing) {
    try {
      existing.clear();
    } catch {
      // Ignored
    }
  }

  const verifier = new RecaptchaVerifier(auth, containerId, {
    size: 'invisible',
    callback: () => {
      // reCAPTCHA solved
    },
    'expired-callback': () => {
      console.warn('reCAPTCHA expired');
    },
  });

  (window as any).recaptchaVerifier = verifier;
  return verifier;
}

export async function sendPhoneOtp(
  phoneNumber: string,
  appVerifier: RecaptchaVerifier
): Promise<ConfirmationResult> {
  return await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
}

// Driver Document Upload to Firebase Storage with Local Base64 fallback
export async function uploadDriverDocument(
  driverId: string,
  file: File,
  docType: 'license' | 'rc' | 'insurance'
): Promise<string> {
  try {
    const storagePath = `driver_documents/${driverId}/${docType}_${Date.now()}_${file.name}`;
    const fileRef = ref(storage, storagePath);
    const uploadTask = uploadBytesResumable(fileRef, file);

    return await new Promise<string>((resolve, reject) => {
      uploadTask.on(
        'state_changed',
        () => {},
        (error) => {
          console.warn('Firebase Storage notice (falling back to local preview):', error.message);
          // Fallback to base64 data URL
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        },
        async () => {
          try {
            const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(downloadUrl);
          } catch {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.readAsDataURL(file);
          }
        }
      );
    });
  } catch (err: any) {
    console.warn('Fallback base64 document encode:', err?.message);
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
  }
}

// Firebase Cloud Messaging (FCM) Notification Setup
export async function requestFCMNotificationPermission(): Promise<string | null> {
  if (!('Notification' in window)) {
    console.info('Push notifications not supported in current browser runtime');
    return null;
  }

  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      const token = `fcm_device_token_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      return token;
    }
  } catch (e) {
    console.info('Notification permission request notice:', e);
  }
  return null;
}


