/**
 * Maya Ride - Types and Data Models
 */

export type VehicleType = 'bike' | 'auto' | 'car';

export type UserRole = 'customer' | 'driver' | 'admin';

export type AccountStatus = 'active' | 'blocked' | 'pending';

export type DriverApprovalStatus = 'pending' | 'approved' | 'rejected';

export type RideStatus =
  | 'requested'
  | 'accepted'
  | 'arriving'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export interface LocationPoint {
  name: string;
  address: string;
  lat: number;
  lng: number;
  landmark?: string;
  isManual?: boolean;
  isGpsDetected?: boolean;
  category?: 'station' | 'temple' | 'market' | 'village' | 'landmark' | 'custom' | 'gps';
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  status: AccountStatus;
  walletBalance: number;
  totalRides?: number;
  createdAt: string;
}

export interface Driver {
  id: string;
  name: string;
  email: string;
  phone: string;
  vehicleType: VehicleType;
  vehicleModel: string;
  vehicleNumber: string;
  licenseNumber: string;
  licenseDocUrl?: string;
  vehicleRcDocUrl?: string;
  insuranceDocUrl?: string;
  documentStatus: 'pending' | 'verified' | 'rejected';
  documentRejectionReason?: string;
  approvalStatus: DriverApprovalStatus;
  isOnline: boolean;
  currentLocation?: LocationPoint;
  rating: number;
  totalTrips: number;
  totalEarnings: number;
  todayEarnings: number;
  monthEarnings: number;
  walletBalance: number;
  createdAt: string;
  avatar?: string;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  category: 'trip_payment' | 'wallet_topup' | 'driver_payout' | 'cashback' | 'refund';
  rideId?: string;
  status: 'completed' | 'pending' | 'failed';
  createdAt: string;
}

export interface CustomerComplaint {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  rideId?: string;
  driverName?: string;
  category: 'overcharging' | 'driver_behavior' | 'vehicle_condition' | 'route_issue' | 'cancellation_dispute' | 'other';
  subject: string;
  details: string;
  status: 'open' | 'in_progress' | 'resolved';
  resolutionNote?: string;
  refundIssued?: number;
  createdAt: string;
  updatedAt: string;
}

export interface AppNotification {
  id: string;
  userId?: string;
  role: 'customer' | 'driver' | 'admin' | 'all';
  title: string;
  body: string;
  type: 'booking' | 'driver_accepted' | 'ride_started' | 'ride_completed' | 'payment' | 'admin_alert';
  rideId?: string;
  read: boolean;
  createdAt: string;
}

export interface Ride {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  driverId: string | null;
  driverName: string | null;
  driverPhone: string | null;
  driverAvatar?: string;
  vehicleType: VehicleType;
  vehicleModel: string | null;
  vehicleNumber: string | null;
  pickupAddress: string;
  pickupCoords: { lat: number; lng: number };
  dropAddress: string;
  dropCoords: { lat: number; lng: number };
  distanceKm: number;
  estimatedMinutes: number;
  fare: number;
  baseFare: number;
  distanceFare: number;
  platformFee: number;
  tax: number;
  status: RideStatus;
  otp: string;
  paymentStatus: 'pending' | 'paid';
  paymentMethod: 'cash' | 'online' | 'wallet';
  rating?: number | null;
  ratingFeedback?: string;
  cancellationReason?: string | null;
  cancelledBy?: 'customer' | 'driver' | 'admin' | null;
  createdAt: string;
  updatedAt: string;
}

export interface FareSetting {
  id: string;
  vehicleType: VehicleType;
  name: string;
  baseFare: number;
  perKmRate: number;
  minFare: number;
  commissionPercent: number;
  capacity: number;
  etaMinutes: number;
  description: string;
  imageIcon: string;
  updatedAt: string;
}

export interface FareCalculation {
  baseFare: number;
  distanceFare: number;
  platformFee: number;
  tax: number;
  totalFare: number;
  driverEarnings: number;
  distanceKm: number;
  estimatedMinutes: number;
}
