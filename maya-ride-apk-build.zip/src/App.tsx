/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RideProvider, useRide } from './context/RideContext';
import { Navbar } from './components/Navbar';
import { CustomerApp } from './components/customer/CustomerApp';
import { DriverApp } from './components/driver/DriverApp';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { SplitSimulator } from './components/simulator/SplitSimulator';
import { Bike, Car, Shield, Sparkles } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activePanel } = useRide();

  return (
    <div className="min-h-screen bg-[#070e1b] text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      {/* Top Navigation */}
      <Navbar />

      {/* Main Panel View */}
      <main className="flex-1 pb-12">
        {activePanel === 'customer' && <CustomerApp />}
        {activePanel === 'driver' && <DriverApp />}
        {activePanel === 'admin' && <AdminDashboard />}
        {activePanel === 'simulator' && <SplitSimulator />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-6 px-4 text-center text-xs text-slate-500 space-y-2">
        <div className="flex items-center justify-center gap-4 text-slate-400">
          <span className="flex items-center gap-1">
            <Bike className="w-3.5 h-3.5 text-amber-400" /> Maya Moto Bike
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            🛺 Maya Auto Rickshaw
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Car className="w-3.5 h-3.5 text-cyan-400" /> Maya Prime Car
          </span>
        </div>
        <p className="text-[11px] text-slate-500">
          Maya Ride • Karwi & Chitrakoot, Uttar Pradesh © {new Date().getFullYear()} • Powered by React, Vite, and Firebase Cloud Firestore
        </p>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <RideProvider>
      <AppContent />
    </RideProvider>
  );
}
