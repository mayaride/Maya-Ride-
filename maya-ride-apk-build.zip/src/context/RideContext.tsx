import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AppNotification,
  CustomerComplaint,
  Driver,
  FareCalculation,
  FareSetting,
  LocationPoint,
  Ride,
  RideStatus,
  User,
  VehicleType,
  WalletTransaction,
} from '../types';
import {
  DEFAULT_COMPLAINTS,
  DEFAULT_DRIVERS,
  DEFAULT_FARE_SETTINGS,
  DEFAULT_NOTIFICATIONS,
  DEFAULT_RIDES,
  DEFAULT_TRANSACTIONS,
  DEFAULT_USERS,
} from '../data/mockData';
import {
  auth,
  db,
  firebaseGoogleLogin,
  firebaseLoginUser,
  firebaseLogoutUser,
  firebaseRegisterUser,
  getCachedComplaints,
  getCachedDrivers,
  getCachedFares,
  getCachedNotifications,
  getCachedRides,
  getCachedTransactions,
  getCachedUsers,
  handleFirestoreError,
  isSystemAdminEmail,
  OperationType,
  requestFCMNotificationPermission,
  saveCachedComplaints,
  saveCachedDrivers,
  saveCachedFares,
  saveCachedNotifications,
  saveCachedRides,
  saveCachedTransactions,
  saveCachedUsers,
  SYSTEM_ADMIN_EMAIL,
  uploadDriverDocument,
} from '../services/firebase';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

export type ActivePanel = 'customer' | 'driver' | 'admin' | 'simulator';

interface RideContextType {
  activePanel: ActivePanel;
  setActivePanel: (panel: ActivePanel) => void;
  currentUser: User;
  setCurrentUser: (user: User) => void;
  firebaseUser: FirebaseUser | null;
  authLoading: boolean;
  rides: Ride[];
  drivers: Driver[];
  users: User[];
  fareSettings: FareSetting[];
  activeDriver: Driver | undefined;
  isAdminAuthenticated: boolean;
  complaints: CustomerComplaint[];
  transactions: WalletTransaction[];
  notifications: AppNotification[];
  fcmToken: string | null;
  // Auth & Profile Actions
  registerCustomer: (name: string, email: string, phone: string, pass: string) => Promise<User>;
  loginCustomer: (email: string, pass: string) => Promise<User>;
  loginWithPhoneOtp: (phoneNumber: string, name?: string) => Promise<User>;
  loginWithGoogle: () => Promise<User>;
  registerDriverAccount: (data: {
    name: string;
    email: string;
    phone: string;
    pass: string;
    licenseNumber: string;
    vehicleType: VehicleType;
    vehicleModel: string;
    vehicleNumber: string;
    licenseDocUrl?: string;
    vehicleRcDocUrl?: string;
  }) => Promise<Driver>;
  loginDriverAccount: (email: string, pass: string) => Promise<Driver>;
  loginAdminAccount: (email: string, pass: string) => Promise<User>;
  logoutAccount: () => Promise<void>;
  updateCustomerProfile: (name: string, phone: string) => Promise<void>;
  updateDriverProfile: (driverId: string, updates: Partial<Driver>) => Promise<void>;
  // Driver Documents & Verification
  uploadAndSetDriverDocument: (
    driverId: string,
    file: File,
    docType: 'license' | 'rc' | 'insurance'
  ) => Promise<string>;
  verifyDriverDocument: (
    driverId: string,
    status: 'verified' | 'rejected',
    reason?: string
  ) => Promise<void>;
  // Ride Operations
  switchRole: (role: 'customer' | 'driver' | 'admin') => void;
  calculateFare: (vehicleType: VehicleType, distanceKm: number) => FareCalculation;
  bookRide: (
    pickup: LocationPoint,
    drop: LocationPoint,
    vehicleType: VehicleType,
    distanceKm: number,
    estimatedMinutes: number,
    paymentMethod: 'cash' | 'online' | 'wallet'
  ) => Promise<Ride>;
  cancelRide: (rideId: string, reason: string, cancelledBy: 'customer' | 'driver' | 'admin') => Promise<void>;
  acceptRide: (rideId: string, driverId: string) => Promise<void>;
  rejectRide: (rideId: string, driverId: string) => Promise<void>;
  updateRideStatus: (rideId: string, status: RideStatus, extra?: Partial<Ride>) => Promise<void>;
  rateRide: (rideId: string, rating: number, feedback?: string) => Promise<void>;
  registerDriver: (driverData: Partial<Driver>) => Promise<Driver>;
  approveDriver: (driverId: string) => Promise<void>;
  rejectDriver: (driverId: string, reason?: string) => Promise<void>;
  toggleDriverOnline: (driverId: string, isOnline: boolean) => Promise<void>;
  updateFareSetting: (vehicleType: VehicleType, updates: Partial<FareSetting>) => Promise<void>;
  toggleUserStatus: (userId: string) => Promise<void>;
  toggleAccountBlock: (userId: string, isBlocked: boolean) => Promise<void>;
  // Wallet & Payments
  topUpWallet: (amount: number, method?: 'upi' | 'card' | 'netbanking') => Promise<void>;
  requestDriverPayout: (driverId: string, amount: number) => Promise<void>;
  // Complaints & Support
  fileComplaint: (data: {
    rideId?: string;
    driverName?: string;
    category: CustomerComplaint['category'];
    subject: string;
    details: string;
  }) => Promise<CustomerComplaint>;
  updateComplaintStatus: (
    complaintId: string,
    status: CustomerComplaint['status'],
    resolutionNote?: string,
    refundAmount?: number
  ) => Promise<void>;
  // Notifications
  sendAppNotification: (notif: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) => void;
  markNotificationRead: (notificationId: string) => void;
  // Driver Reports
  getDriverDailySummary: (driverId: string) => {
    trips: number;
    grossFare: number;
    netEarnings: number;
    commission: number;
    avgRating: number;
  };
  getDriverMonthlySummary: (driverId: string) => {
    trips: number;
    grossFare: number;
    netEarnings: number;
    commission: number;
  };
  resetToDemoData: () => void;
}

const RideContext = createContext<RideContextType | undefined>(undefined);

export const RideProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePanel, setActivePanel] = useState<ActivePanel>('customer');
  const [users, setUsers] = useState<User[]>(() => getCachedUsers());
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const list = getCachedUsers();
    return list.find((u) => u.role === 'customer') || DEFAULT_USERS[0];
  });
  const [drivers, setDrivers] = useState<Driver[]>(() => getCachedDrivers());
  const [rides, setRides] = useState<Ride[]>(() => getCachedRides());
  const [fareSettings, setFareSettings] = useState<FareSetting[]>(() => getCachedFares());
  const [complaints, setComplaints] = useState<CustomerComplaint[]>(() => getCachedComplaints());
  const [transactions, setTransactions] = useState<WalletTransaction[]>(() => getCachedTransactions());
  const [notifications, setNotifications] = useState<AppNotification[]>(() => getCachedNotifications());
  const [fcmToken, setFcmToken] = useState<string | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Check if current user is an authenticated Firebase Admin (never auto-unlock from demo state)
  const isAdminAuthenticated = Boolean(
    firebaseUser &&
      (isSystemAdminEmail(firebaseUser.email) ||
        users.some((u) => u.id === firebaseUser.uid && u.role === 'admin'))
  );

  // Active driver matching current user ID or email
  const activeDriver =
    drivers.find((d) => d.id === currentUser.id || d.email === currentUser.email) ||
    drivers[0];

  // Save to localStorage whenever state changes
  useEffect(() => {
    saveCachedRides(rides);
  }, [rides]);

  useEffect(() => {
    saveCachedDrivers(drivers);
  }, [drivers]);

  useEffect(() => {
    saveCachedUsers(users);
  }, [users]);

  useEffect(() => {
    saveCachedFares(fareSettings);
  }, [fareSettings]);

  useEffect(() => {
    saveCachedComplaints(complaints);
  }, [complaints]);

  useEffect(() => {
    saveCachedTransactions(transactions);
  }, [transactions]);

  useEffect(() => {
    saveCachedNotifications(notifications);
  }, [notifications]);

  useEffect(() => {
    requestFCMNotificationPermission().then((token) => {
      if (token) setFcmToken(token);
    });
  }, []);

  // Firebase Auth listener (mount once; do not re-subscribe on users state changes)
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setAuthLoading(false);

      if (user) {
        let matchedUser: User | undefined;

        try {
          const userSnap = await getDoc(doc(db, 'users', user.uid));
          if (userSnap.exists()) {
            matchedUser = userSnap.data() as User;
          }
        } catch {
          // Local fallback
        }

        if (!matchedUser) {
          setUsers((prev) => {
            const localMatch = prev.find((u) => u.id === user.uid || u.email === user.email);
            if (localMatch) {
              matchedUser = localMatch;
              return prev;
            }
            if (isSystemAdminEmail(user.email)) {
              const adminProfile: User = {
                id: user.uid,
                name: user.displayName || 'Maya Administrator',
                email: user.email || SYSTEM_ADMIN_EMAIL,
                phone: '+91 80000 00001',
                role: 'admin',
                status: 'active',
                walletBalance: 0,
                totalRides: 0,
                createdAt: new Date().toISOString(),
              };
              matchedUser = adminProfile;
              return [adminProfile, ...prev];
            }
            return prev;
          });
        } else {
          setUsers((prev) => {
            const exists = prev.some((u) => u.id === matchedUser!.id);
            return exists
              ? prev.map((u) => (u.id === matchedUser!.id ? matchedUser! : u))
              : [matchedUser!, ...prev];
          });
        }

        if (matchedUser) {
          setCurrentUser(matchedUser);
        }
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Role-scoped real-time Firestore sync with local resilience
  useEffect(() => {
    const unsubscribers: Array<() => void> = [];

    // 1. Fare settings are public read
    try {
      unsubscribers.push(
        onSnapshot(
          collection(db, 'fareSettings'),
          (snapshot) => {
            if (!snapshot.empty) {
              const remoteFares: FareSetting[] = [];
              snapshot.forEach((docSnap) => {
                remoteFares.push({ id: docSnap.id, ...docSnap.data() } as FareSetting);
              });
              setFareSettings(remoteFares);
            }
          },
          (err) => {
            console.info('Firestore fares listener notice:', err.message);
          }
        )
      );
    } catch {
      // Offline fallback
    }

    if (firebaseUser) {
      const uid = firebaseUser.uid;
      const adminScope = isAdminAuthenticated;
      const driverScope = !adminScope && currentUser.role === 'driver';

      const mergeRides = (snapshotDocs: Ride[]) => {
        setRides((prev) => {
          const map = new Map<string, Ride>();
          prev.forEach((r) => map.set(r.id, r));
          snapshotDocs.forEach((r) => map.set(r.id, r));
          return Array.from(map.values()).sort(
            (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
        });
      };

      // 2. Rides (role-scoped per security rules)
      try {
        if (adminScope) {
          unsubscribers.push(
            onSnapshot(
              collection(db, 'rides'),
              (snapshot) => {
                const list: Ride[] = [];
                snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as Ride));
                if (list.length > 0) mergeRides(list);
              },
              (err) => console.info('Firestore admin rides notice:', err.message)
            )
          );
        } else if (driverScope) {
          unsubscribers.push(
            onSnapshot(
              query(collection(db, 'rides'), where('status', '==', 'requested')),
              (snapshot) => {
                const list: Ride[] = [];
                snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as Ride));
                if (list.length > 0) mergeRides(list);
              },
              (err) => console.info('Firestore requested rides notice:', err.message)
            )
          );
          unsubscribers.push(
            onSnapshot(
              query(collection(db, 'rides'), where('driverId', '==', uid)),
              (snapshot) => {
                const list: Ride[] = [];
                snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as Ride));
                if (list.length > 0) mergeRides(list);
              },
              (err) => console.info('Firestore driver rides notice:', err.message)
            )
          );
        } else {
          unsubscribers.push(
            onSnapshot(
              query(collection(db, 'rides'), where('customerId', '==', uid)),
              (snapshot) => {
                const list: Ride[] = [];
                snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as Ride));
                if (list.length > 0) mergeRides(list);
              },
              (err) => console.info('Firestore customer rides notice:', err.message)
            )
          );
        }
      } catch {
        // Offline fallback
      }

      // 3. Drivers (Admin reads all; Customer/Driver reads approved or own)
      try {
        const driversQuery = adminScope
          ? collection(db, 'drivers')
          : driverScope
          ? query(collection(db, 'drivers'), where('id', '==', uid))
          : query(collection(db, 'drivers'), where('approvalStatus', '==', 'approved'));

        unsubscribers.push(
          onSnapshot(
            driversQuery,
            (snapshot) => {
              if (!snapshot.empty) {
                const remoteDrivers: Driver[] = [];
                snapshot.forEach((docSnap) => {
                  remoteDrivers.push({ id: docSnap.id, ...docSnap.data() } as Driver);
                });
                setDrivers((prev) => {
                  const map = new Map<string, Driver>();
                  prev.forEach((d) => map.set(d.id, d));
                  remoteDrivers.forEach((d) => map.set(d.id, d));
                  return Array.from(map.values());
                });
              }
            },
            (err) => console.info('Firestore drivers listener notice:', err.message)
          )
        );
      } catch {
        // Offline fallback
      }

      // 4. Users (Admin full list sync)
      if (adminScope) {
        try {
          unsubscribers.push(
            onSnapshot(
              collection(db, 'users'),
              (snapshot) => {
                if (!snapshot.empty) {
                  const remoteUsers: User[] = [];
                  snapshot.forEach((d) => remoteUsers.push({ id: d.id, ...d.data() } as User));
                  setUsers((prev) => {
                    const map = new Map<string, User>();
                    prev.forEach((u) => map.set(u.id, u));
                    remoteUsers.forEach((u) => map.set(u.id, u));
                    return Array.from(map.values());
                  });
                }
              },
              (err) => console.info('Firestore users listener notice:', err.message)
            )
          );
        } catch {
          // Offline fallback
        }
      }

      // 5. Complaints (Admin all; Customer own)
      if (adminScope || !driverScope) {
        try {
          const complaintsQuery = adminScope
            ? collection(db, 'complaints')
            : query(collection(db, 'complaints'), where('customerId', '==', uid));
          unsubscribers.push(
            onSnapshot(
              complaintsQuery,
              (snapshot) => {
                if (!snapshot.empty) {
                  const remoteComplaints: CustomerComplaint[] = [];
                  snapshot.forEach((docSnap) => {
                    remoteComplaints.push({ id: docSnap.id, ...docSnap.data() } as CustomerComplaint);
                  });
                  setComplaints((prev) => {
                    const map = new Map<string, CustomerComplaint>();
                    prev.forEach((c) => map.set(c.id, c));
                    remoteComplaints.forEach((c) => map.set(c.id, c));
                    return Array.from(map.values()).sort(
                      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                    );
                  });
                }
              },
              (err) => console.info('Firestore complaints listener notice:', err.message)
            )
          );
        } catch {
          // Offline fallback
        }
      }

      // 6. Transactions (Admin all; User/Driver own)
      try {
        const txnsQuery = adminScope
          ? collection(db, 'transactions')
          : query(collection(db, 'transactions'), where('userId', '==', uid));
        unsubscribers.push(
          onSnapshot(
            txnsQuery,
            (snapshot) => {
              if (!snapshot.empty) {
                const remoteTxns: WalletTransaction[] = [];
                snapshot.forEach((docSnap) => {
                  remoteTxns.push({ id: docSnap.id, ...docSnap.data() } as WalletTransaction);
                });
                setTransactions((prev) => {
                  const map = new Map<string, WalletTransaction>();
                  prev.forEach((t) => map.set(t.id, t));
                  remoteTxns.forEach((t) => map.set(t.id, t));
                  return Array.from(map.values()).sort(
                    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                  );
                });
              }
            },
            (err) => console.info('Firestore transactions listener notice:', err.message)
          )
        );
      } catch {
        // Offline fallback
      }

      // 7. Notifications (Admin all; User/Driver own)
      try {
        const notifsQuery = adminScope
          ? collection(db, 'notifications')
          : query(collection(db, 'notifications'), where('userId', '==', uid));
        unsubscribers.push(
          onSnapshot(
            notifsQuery,
            (snapshot) => {
              if (!snapshot.empty) {
                const remoteNotifs: AppNotification[] = [];
                snapshot.forEach((docSnap) => {
                  remoteNotifs.push({ id: docSnap.id, ...docSnap.data() } as AppNotification);
                });
                setNotifications((prev) => {
                  const map = new Map<string, AppNotification>();
                  prev.forEach((n) => map.set(n.id, n));
                  remoteNotifs.forEach((n) => map.set(n.id, n));
                  return Array.from(map.values()).sort(
                    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                  );
                });
              }
            },
            (err) => console.info('Firestore notifications listener notice:', err.message)
          )
        );
      } catch {
        // Offline fallback
      }
    }

    return () => {
      unsubscribers.forEach((unsub) => {
        try {
          unsub();
        } catch {
          // Ignore
        }
      });
    };
  }, [firebaseUser, isAdminAuthenticated, currentUser.role]);

  // Quick switch role (admin panel requires real Firebase Admin sign-in)
  const switchRole = (role: 'customer' | 'driver' | 'admin') => {
    if (role === 'admin') {
      setActivePanel('admin');
      return;
    }
    const targetUser = users.find((u) => u.role === role) || DEFAULT_USERS.find((u) => u.role === role)!;
    setCurrentUser(targetUser);
    if (role === 'customer') setActivePanel('customer');
    else setActivePanel('driver');
  };

  const shouldAllowOfflineFallback = (err: any) => {
    const code = err?.code || '';
    return (
      code === 'auth/operation-not-allowed' ||
      code === 'auth/configuration-not-found' ||
      code === 'auth/network-request-failed'
    );
  };

  // Customer Email/Password Registration
  const registerCustomer = async (
    name: string,
    email: string,
    phone: string,
    pass: string
  ): Promise<User> => {
    const cleanEmail = email.trim().toLowerCase();
    let uid = `cust_${Date.now()}`;

    try {
      const fbUser = await firebaseRegisterUser(cleanEmail, pass, name.trim());
      uid = fbUser.uid;
    } catch (err: any) {
      if (!shouldAllowOfflineFallback(err)) {
        throw new Error(err?.message || 'Registration failed. Please verify your email and password.');
      }
      console.warn('Firebase Auth unavailable (using local profile fallback):', err?.message);
    }

    const newUser: User = {
      id: uid,
      name: name.trim(),
      email: cleanEmail,
      phone: phone.trim(),
      role: 'customer',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      status: 'active',
      walletBalance: 500,
      totalRides: 0,
      createdAt: new Date().toISOString(),
    };

    setUsers((prev) => [newUser, ...prev.filter((u) => u.id !== uid)]);
    setCurrentUser(newUser);

    try {
      await setDoc(doc(db, 'users', uid), newUser);
    } catch {
      // Local fallback
    }

    return newUser;
  };

  // Customer Email/Password Login
  const loginCustomer = async (email: string, pass: string): Promise<User> => {
    const cleanEmail = email.trim().toLowerCase();
    let fbUid: string | null = null;

    try {
      const fbUser = await firebaseLoginUser(cleanEmail, pass);
      fbUid = fbUser.uid;
    } catch (err: any) {
      if (
        err?.code === 'auth/wrong-password' ||
        err?.code === 'auth/invalid-credential' ||
        err?.code === 'auth/user-disabled' ||
        err?.code === 'auth/too-many-requests' ||
        err?.code === 'auth/invalid-email'
      ) {
        throw new Error('Invalid email or password. Please check your credentials.');
      }
      const localMatch = users.find((u) => u.email.toLowerCase() === cleanEmail && u.role === 'customer');
      if (!localMatch && !shouldAllowOfflineFallback(err)) {
        throw new Error('Account not found in Firebase. Please register first.');
      }
      console.warn('Firebase Auth login notice:', err?.message);
    }

    const matched = users.find(
      (u) => (fbUid && u.id === fbUid) || u.email.toLowerCase() === cleanEmail
    );
    if (matched) {
      if (matched.status === 'blocked') {
        throw new Error('Your passenger account has been blocked by Maya Admin.');
      }
      setCurrentUser(matched);
      return matched;
    }

    const fallbackUser: User = {
      id: fbUid || `cust_${Date.now()}`,
      name: cleanEmail.split('@')[0],
      email: cleanEmail,
      phone: '+91 94501 23456',
      role: 'customer',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      status: 'active',
      walletBalance: 450,
      totalRides: 0,
      createdAt: new Date().toISOString(),
    };
    setUsers((prev) => [fallbackUser, ...prev]);
    setCurrentUser(fallbackUser);
    return fallbackUser;
  };

  // Customer Phone OTP Login
  const loginWithPhoneOtp = async (phoneNumber: string, name?: string): Promise<User> => {
    const cleanPhone = phoneNumber.trim();
    const activeFbUser = auth.currentUser;
    let matched = users.find(
      (u) =>
        (activeFbUser && u.id === activeFbUser.uid) ||
        (u.phone === cleanPhone && u.role === 'customer')
    );

    if (!matched) {
      const newId = activeFbUser?.uid || `cust_${Date.now()}`;
      matched = {
        id: newId,
        name: name?.trim() || activeFbUser?.displayName || `Customer ${cleanPhone.slice(-4)}`,
        email: `passenger_${cleanPhone.replace(/[^0-9]/g, '')}@mayaride.in`,
        phone: cleanPhone,
        role: 'customer',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
        status: 'active',
        walletBalance: 300,
        totalRides: 0,
        createdAt: new Date().toISOString(),
      };
      setUsers((prev) => [matched!, ...prev]);
      try {
        await setDoc(doc(db, 'users', newId), matched);
      } catch {
        // Local fallback
      }
    }

    if (matched.status === 'blocked') {
      throw new Error('Your passenger account has been blocked by Maya Admin.');
    }

    setCurrentUser(matched);
    return matched;
  };

  // Google Sign-In with popup
  const loginWithGoogle = async (): Promise<User> => {
    const gUser = await firebaseGoogleLogin();
    const gEmail = gUser.email || `google_user_${gUser.uid}@gmail.com`;
    let matched = users.find(
      (u) => u.id === gUser.uid || u.email.toLowerCase() === gEmail.toLowerCase()
    );

    if (!matched) {
      const newId = gUser.uid;
      matched = {
        id: newId,
        name: gUser.displayName || 'Maya Customer',
        email: gEmail,
        phone: gUser.phoneNumber || '+91 94501 23456',
        role: isSystemAdminEmail(gEmail) ? 'admin' : 'customer',
        avatar: gUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
        status: 'active',
        walletBalance: 500,
        totalRides: 0,
        createdAt: new Date().toISOString(),
      };
      setUsers((prev) => [matched!, ...prev]);
      try {
        await setDoc(doc(db, 'users', newId), matched);
      } catch {
        // Local fallback
      }
    }

    if (matched.status === 'blocked') {
      throw new Error('This account has been blocked by Maya Admin.');
    }

    setCurrentUser(matched);
    return matched;
  };

  // Driver Email/Password Registration
  const registerDriverAccount = async (data: {
    name: string;
    email: string;
    phone: string;
    pass: string;
    licenseNumber: string;
    vehicleType: VehicleType;
    vehicleModel: string;
    vehicleNumber: string;
    licenseDocUrl?: string;
    vehicleRcDocUrl?: string;
  }): Promise<Driver> => {
    const cleanEmail = data.email.trim().toLowerCase();
    let uid = `drv_${Date.now()}`;

    try {
      const fbUser = await firebaseRegisterUser(cleanEmail, data.pass, data.name.trim());
      uid = fbUser.uid;
    } catch (err: any) {
      if (!shouldAllowOfflineFallback(err)) {
        throw new Error(err?.message || 'Driver registration failed. Check email and password.');
      }
      console.warn('Firebase Auth unavailable (using local driver fallback):', err?.message);
    }

    // Driver accounts must remain pending until approved by Admin
    const newDriver: Driver = {
      id: uid,
      name: data.name.trim(),
      email: cleanEmail,
      phone: data.phone.trim(),
      vehicleType: data.vehicleType,
      vehicleModel: data.vehicleModel.trim(),
      vehicleNumber: data.vehicleNumber.trim(),
      licenseNumber: data.licenseNumber.trim(),
      licenseDocUrl: data.licenseDocUrl || 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?w=500&auto=format&fit=crop&q=80',
      vehicleRcDocUrl: data.vehicleRcDocUrl || 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=500&auto=format&fit=crop&q=80',
      documentStatus: 'pending',
      approvalStatus: 'pending', // Mandated Pending status!
      isOnline: false,
      rating: 5.0,
      totalTrips: 0,
      totalEarnings: 0,
      todayEarnings: 0,
      monthEarnings: 0,
      walletBalance: 0,
      createdAt: new Date().toISOString(),
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
    };

    const driverUser: User = {
      id: uid,
      name: newDriver.name,
      email: newDriver.email,
      phone: newDriver.phone,
      role: 'driver',
      avatar: newDriver.avatar,
      status: 'pending',
      walletBalance: 0,
      totalRides: 0,
      createdAt: newDriver.createdAt,
    };

    setDrivers((prev) => [newDriver, ...prev.filter((d) => d.id !== uid)]);
    setUsers((prev) => [driverUser, ...prev.filter((u) => u.id !== uid)]);
    setCurrentUser(driverUser);

    try {
      await setDoc(doc(db, 'drivers', uid), newDriver);
      await setDoc(doc(db, 'users', uid), driverUser);
    } catch {
      // Local fallback
    }

    return newDriver;
  };

  // Driver Email/Password Login
  const loginDriverAccount = async (email: string, pass: string): Promise<Driver> => {
    const cleanEmail = email.trim().toLowerCase();
    let fbUid: string | null = null;

    try {
      const fbUser = await firebaseLoginUser(cleanEmail, pass);
      fbUid = fbUser.uid;
    } catch (err: any) {
      if (
        err?.code === 'auth/wrong-password' ||
        err?.code === 'auth/invalid-credential' ||
        err?.code === 'auth/user-disabled' ||
        err?.code === 'auth/too-many-requests' ||
        err?.code === 'auth/invalid-email'
      ) {
        throw new Error('Invalid captain email or password.');
      }
      console.warn('Firebase Auth driver login notice:', err?.message);
    }

    const matchedDriver = drivers.find(
      (d) => (fbUid && d.id === fbUid) || d.email.toLowerCase() === cleanEmail
    );
    if (matchedDriver) {
      const matchedUser = users.find((u) => u.id === matchedDriver.id) || {
        id: matchedDriver.id,
        name: matchedDriver.name,
        email: matchedDriver.email,
        phone: matchedDriver.phone,
        role: 'driver' as const,
        status: matchedDriver.approvalStatus === 'approved' ? ('active' as const) : ('pending' as const),
        walletBalance: matchedDriver.walletBalance,
        totalRides: matchedDriver.totalTrips,
        createdAt: matchedDriver.createdAt,
      };
      if (matchedUser.status === 'blocked') {
        throw new Error('Your captain account has been blocked by Maya Admin.');
      }
      setCurrentUser(matchedUser);
      return matchedDriver;
    }

    throw new Error('Driver account not found. Please register first.');
  };

  // Secure Admin Login (Requires real Firebase authentication — never bypasses password checks)
  const loginAdminAccount = async (email: string, pass: string): Promise<User> => {
    const cleanEmail = email.trim().toLowerCase();
    if (!isSystemAdminEmail(cleanEmail)) {
      throw new Error('Access Denied: This email does not possess Maya Ride Administrator privileges.');
    }

    let fbAdmin: FirebaseUser;
    try {
      fbAdmin = await firebaseLoginUser(cleanEmail, pass);
    } catch (err: any) {
      if (err?.code === 'auth/operation-not-allowed') {
        throw new Error(
          'Email/Password Sign-In is not enabled in Firebase Console. Use "Sign in with Google (Authorized Admin)" below.'
        );
      }
      if (err?.code === 'auth/user-not-found' || err?.code === 'auth/invalid-credential') {
        throw new Error(
          'Invalid administrator credentials or account not created for Email/Password. Try "Sign in with Google" or verify your password.'
        );
      }
      throw new Error(err?.message || 'Admin authentication failed.');
    }

    const adminUser: User = {
      id: fbAdmin.uid,
      name: fbAdmin.displayName || 'Maya Super Admin',
      email: fbAdmin.email || cleanEmail,
      phone: '+91 80000 00001',
      role: 'admin',
      avatar: fbAdmin.photoURL || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
      status: 'active',
      walletBalance: 85000,
      totalRides: 0,
      createdAt: '2026-01-01T00:00:00Z',
    };
    setUsers((prev) => [adminUser, ...prev.filter((u) => u.id !== adminUser.id)]);
    setCurrentUser(adminUser);
    return adminUser;
  };

  // Logout current user
  const logoutAccount = async () => {
    try {
      await firebaseLogoutUser();
    } catch {
      // Silent catch
    }
    // Reset to default guest customer
    setCurrentUser(DEFAULT_USERS[0]);
  };

  // Update Customer Profile
  const updateCustomerProfile = async (name: string, phone: string) => {
    const updated: User = {
      ...currentUser,
      name: name.trim(),
      phone: phone.trim(),
    };
    setCurrentUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updated : u)));

    try {
      await updateDoc(doc(db, 'users', currentUser.id), {
        name: name.trim(),
        phone: phone.trim(),
      });
    } catch {
      // Local fallback
    }
  };

  // Update Driver Profile
  const updateDriverProfile = async (driverId: string, updates: Partial<Driver>) => {
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, ...updates } : d))
    );
    try {
      await updateDoc(doc(db, 'drivers', driverId), updates);
    } catch {
      // Local fallback
    }
  };

  // Calculate dynamic fare based on Karwi Chitrakoot rates
  const calculateFare = (vehicleType: VehicleType, distanceKm: number): FareCalculation => {
    const setting =
      fareSettings.find((f) => f.vehicleType === vehicleType) ||
      DEFAULT_FARE_SETTINGS.find((f) => f.vehicleType === vehicleType)!;

    const baseFare = setting.baseFare;
    const distanceFare = Math.round(distanceKm * setting.perKmRate);
    const subtotal = Math.max(setting.minFare, baseFare + distanceFare);
    const tax = Math.round(subtotal * 0.05); // 5% GST
    const totalFare = subtotal + tax;
    const platformFee = Math.round(subtotal * (setting.commissionPercent / 100));
    const driverEarnings = totalFare - platformFee;
    const estimatedMinutes = Math.max(5, Math.round(distanceKm * 2.2 + setting.etaMinutes));

    return {
      baseFare,
      distanceFare,
      platformFee,
      tax,
      totalFare,
      driverEarnings,
      distanceKm: Number(distanceKm.toFixed(1)),
      estimatedMinutes,
    };
  };

  // Customer: Book a ride
  const bookRide = async (
    pickup: LocationPoint,
    drop: LocationPoint,
    vehicleType: VehicleType,
    distanceKm: number,
    estimatedMinutes: number,
    paymentMethod: 'cash' | 'online' | 'wallet'
  ): Promise<Ride> => {
    if (currentUser.status === 'blocked') {
      throw new Error(
        'Your passenger account is currently blocked by Maya Ride Admin. Please contact support.'
      );
    }

    const fareCalc = calculateFare(vehicleType, distanceKm);
    const randomOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const rideId = `RIDE-${Math.floor(100 + Math.random() * 900)}`;

    // If paying by wallet, enforce sufficient funds
    if (paymentMethod === 'wallet') {
      const currentBal = currentUser.walletBalance || 0;
      if (currentBal < fareCalc.totalFare) {
        throw new Error(
          `Insufficient Maya Wallet balance (₹${currentBal}). Please top up your wallet or select Cash / Online Payment.`
        );
      }
      // Deduct from customer wallet immediately
      const newBal = currentBal - fareCalc.totalFare;
      const updatedUser = { ...currentUser, walletBalance: newBal };
      setCurrentUser(updatedUser);
      setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));

      const debitTxn: WalletTransaction = {
        id: `TXN-W-${Date.now().toString().slice(-6)}`,
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        rideId,
        amount: fareCalc.totalFare,
        type: 'debit',
        category: 'trip_payment',
        status: 'completed',
        description: `Maya Wallet ride fare for ${vehicleType.toUpperCase()} (${fareCalc.distanceKm} km)`,
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [debitTxn, ...prev]);

      try {
        await updateDoc(doc(db, 'users', currentUser.id), { walletBalance: newBal });
        await setDoc(doc(db, 'transactions', debitTxn.id), debitTxn);
      } catch {
        // Local fallback
      }
    } else if (paymentMethod === 'online') {
      const onlineTxn: WalletTransaction = {
        id: `TXN-ONL-${Date.now().toString().slice(-6)}`,
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        rideId,
        amount: fareCalc.totalFare,
        type: 'debit',
        category: 'trip_payment',
        status: 'completed',
        description: `Online UPI/Card checkout for ${vehicleType.toUpperCase()} (${fareCalc.distanceKm} km)`,
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [onlineTxn, ...prev]);
      try {
        await setDoc(doc(db, 'transactions', onlineTxn.id), onlineTxn);
      } catch {
        // Local fallback
      }
    }

    const newRide: Ride = {
      id: rideId,
      customerId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      driverId: null,
      driverName: null,
      driverPhone: null,
      vehicleType,
      vehicleModel: null,
      vehicleNumber: null,
      pickupAddress: pickup.name || pickup.address,
      pickupCoords: { lat: pickup.lat, lng: pickup.lng },
      dropAddress: drop.name || drop.address,
      dropCoords: { lat: drop.lat, lng: drop.lng },
      distanceKm: fareCalc.distanceKm,
      estimatedMinutes: estimatedMinutes || fareCalc.estimatedMinutes,
      fare: fareCalc.totalFare,
      baseFare: fareCalc.baseFare,
      distanceFare: fareCalc.distanceFare,
      platformFee: fareCalc.platformFee,
      tax: fareCalc.tax,
      status: 'requested',
      otp: randomOtp,
      paymentStatus: paymentMethod === 'wallet' || paymentMethod === 'online' ? 'paid' : 'pending',
      paymentMethod,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setRides((prev) => [newRide, ...prev]);

    sendAppNotification({
      userId: currentUser.id,
      role: 'customer',
      rideId,
      title: 'Ride Requested',
      body: `Searching for nearby ${vehicleType.toUpperCase()} captains in Karwi & Chitrakoot...`,
      type: 'booking',
    });

    try {
      await setDoc(doc(db, 'rides', rideId), newRide);
    } catch {
      // Handled locally
    }

    return newRide;
  };

  // Cancel ride
  const cancelRide = async (
    rideId: string,
    reason: string,
    cancelledBy: 'customer' | 'driver' | 'admin'
  ) => {
    const targetRide = rides.find((r) => r.id === rideId);
    const updatedAt = new Date().toISOString();

    // If ride was prepaid with wallet or online, issue automatic refund to Maya Wallet
    if (
      targetRide &&
      (targetRide.paymentMethod === 'wallet' || targetRide.paymentMethod === 'online') &&
      targetRide.paymentStatus === 'paid'
    ) {
      const customer = users.find((u) => u.id === targetRide.customerId) || currentUser;
      const refundedBal = (customer.walletBalance || 0) + targetRide.fare;

      setUsers((prev) =>
        prev.map((u) => (u.id === targetRide.customerId ? { ...u, walletBalance: refundedBal } : u))
      );
      if (currentUser.id === targetRide.customerId) {
        setCurrentUser({ ...currentUser, walletBalance: refundedBal });
      }

      const refundTxn: WalletTransaction = {
        id: `REFUND-${Date.now().toString().slice(-6)}`,
        userId: targetRide.customerId,
        userName: targetRide.customerName,
        userRole: 'customer',
        rideId: targetRide.id,
        amount: targetRide.fare,
        type: 'credit',
        category: 'refund',
        status: 'completed',
        description: `Full refund for cancelled ride ${targetRide.id}`,
        createdAt: updatedAt,
      };
      setTransactions((prev) => [refundTxn, ...prev]);

      try {
        await updateDoc(doc(db, 'users', targetRide.customerId), { walletBalance: refundedBal });
        await setDoc(doc(db, 'transactions', refundTxn.id), refundTxn);
      } catch {
        // Local fallback
      }

      sendAppNotification({
        userId: targetRide.customerId,
        role: 'customer',
        rideId,
        title: 'Refund Processed',
        body: `₹${targetRide.fare} has been refunded to your Maya Wallet.`,
        type: 'payment',
      });
    }

    setRides((prev) =>
      prev.map((r) =>
        r.id === rideId
          ? {
              ...r,
              status: 'cancelled',
              cancellationReason: reason,
              cancelledBy,
              updatedAt,
            }
          : r
      )
    );

    sendAppNotification({
      userId: targetRide?.customerId || currentUser.id,
      role: 'customer',
      rideId,
      title: 'Ride Cancelled',
      body: `Ride ${rideId} was cancelled (${reason}).`,
      type: 'admin_alert',
    });

    try {
      await updateDoc(doc(db, 'rides', rideId), {
        status: 'cancelled',
        cancellationReason: reason,
        cancelledBy,
        updatedAt,
      });
    } catch {
      // Handled locally
    }
  };

  // Driver: Accept ride
  const acceptRide = async (rideId: string, driverId: string) => {
    const driver = drivers.find((d) => d.id === driverId) || activeDriver;
    const driverUser = users.find((u) => u.id === driverId);
    const targetRide = rides.find((r) => r.id === rideId);

    if (!driver) {
      throw new Error('Captain profile not found.');
    }
    if (driver.approvalStatus !== 'approved' || driverUser?.status === 'blocked') {
      throw new Error('Only approved, active captains can accept rides.');
    }
    if (!targetRide || targetRide.status !== 'requested') {
      throw new Error('This ride request is no longer available.');
    }

    const updatedAt = new Date().toISOString();

    const updates: Partial<Ride> = {
      status: 'accepted',
      driverId: driver.id,
      driverName: driver.name,
      driverPhone: driver.phone,
      driverAvatar: driver.avatar,
      vehicleModel: driver.vehicleModel,
      vehicleNumber: driver.vehicleNumber,
      updatedAt,
    };

    setRides((prev) => prev.map((r) => (r.id === rideId ? { ...r, ...updates } : r)));

    sendAppNotification({
      userId: targetRide.customerId,
      role: 'customer',
      rideId,
      title: 'Captain Assigned',
      body: `${driver.name} (${driver.vehicleNumber}) accepted your ride! ETA ~5 minutes.`,
      type: 'driver_accepted',
    });

    sendAppNotification({
      userId: driver.id,
      role: 'driver',
      rideId,
      title: 'Ride Accepted',
      body: `Head towards pickup: ${targetRide.pickupAddress}`,
      type: 'driver_accepted',
    });

    try {
      await updateDoc(doc(db, 'rides', rideId), updates);
    } catch {
      // Handled locally
    }
  };

  // Driver: Reject ride
  const rejectRide = async (rideId: string, _driverId: string) => {
    const updatedAt = new Date().toISOString();
    setRides((prev) =>
      prev.map((r) =>
        r.id === rideId ? { ...r, updatedAt } : r
      )
    );
  };

  // Driver or Admin: Update ride lifecycle status
  const updateRideStatus = async (
    rideId: string,
    status: RideStatus,
    extra: Partial<Ride> = {}
  ) => {
    const updatedAt = new Date().toISOString();
    const targetRide = rides.find((r) => r.id === rideId);

    const updates: Partial<Ride> = {
      status,
      updatedAt,
      ...extra,
    };

    if (status === 'arriving' && targetRide) {
      sendAppNotification({
        userId: targetRide.customerId,
        role: 'customer',
        rideId,
        title: 'Captain Arrived',
        body: `${targetRide.driverName || 'Captain'} has arrived at your pickup spot. Please share OTP ${targetRide.otp}.`,
        type: 'driver_accepted',
      });
    } else if (status === 'in_progress' && targetRide) {
      sendAppNotification({
        userId: targetRide.customerId,
        role: 'customer',
        rideId,
        title: 'Trip Started',
        body: `Your trip to ${targetRide.dropAddress} has started. Have a safe journey!`,
        type: 'ride_started',
      });
    } else if (status === 'completed' && targetRide) {
      const netEarning = targetRide.fare - targetRide.platformFee;

      // Increment customer completed trips counter
      setUsers((prev) =>
        prev.map((u) =>
          u.id === targetRide.customerId
            ? { ...u, totalRides: (u.totalRides || 0) + 1 }
            : u
        )
      );

      if (targetRide.driverId) {
        const assignedDrv = drivers.find((d) => d.id === targetRide.driverId);
        const drvUpdates = assignedDrv
          ? {
              totalTrips: assignedDrv.totalTrips + 1,
              totalEarnings: assignedDrv.totalEarnings + netEarning,
              todayEarnings: (assignedDrv.todayEarnings || 0) + netEarning,
              monthEarnings: (assignedDrv.monthEarnings || 0) + netEarning,
              walletBalance: assignedDrv.walletBalance + netEarning,
            }
          : null;

        setDrivers((prev) =>
          prev.map((d) =>
            d.id === targetRide.driverId
              ? {
                  ...d,
                  totalTrips: d.totalTrips + 1,
                  totalEarnings: d.totalEarnings + netEarning,
                  todayEarnings: (d.todayEarnings || 0) + netEarning,
                  monthEarnings: (d.monthEarnings || 0) + netEarning,
                  walletBalance: d.walletBalance + netEarning,
                }
              : d
          )
        );

        const earningTxn: WalletTransaction = {
          id: `EARN-${Date.now().toString().slice(-6)}`,
          userId: targetRide.driverId,
          userName: targetRide.driverName || assignedDrv?.name || 'Maya Captain',
          userRole: 'driver',
          rideId: targetRide.id,
          amount: netEarning,
          type: 'credit',
          category: 'trip_payment',
          status: 'completed',
          description: `Net earnings from ${targetRide.id} (₹${targetRide.fare} fare - ₹${targetRide.platformFee} commission)`,
          createdAt: updatedAt,
        };
        setTransactions((prev) => [earningTxn, ...prev]);

        try {
          if (drvUpdates) {
            await updateDoc(doc(db, 'drivers', targetRide.driverId), drvUpdates);
          }
          await setDoc(doc(db, 'transactions', earningTxn.id), earningTxn);
        } catch {
          // Handled locally
        }

        sendAppNotification({
          userId: targetRide.driverId,
          role: 'driver',
          rideId,
          title: 'Trip Completed',
          body: `Trip finished! Earned ₹${netEarning} (₹${targetRide.platformFee} platform commission).`,
          type: 'payment',
        });
      }

      sendAppNotification({
        userId: targetRide.customerId,
        role: 'customer',
        rideId,
        title: 'Reached Destination',
        body: `You've arrived at ${targetRide.dropAddress}. Total paid: ₹${targetRide.fare}. Please rate your captain!`,
        type: 'ride_completed',
      });
    }

    setRides((prev) => prev.map((r) => (r.id === rideId ? { ...r, ...updates } : r)));

    try {
      await updateDoc(doc(db, 'rides', rideId), updates);
    } catch {
      // Handled locally
    }
  };

  // Customer: Rate a completed ride
  const rateRide = async (rideId: string, rating: number, feedback?: string) => {
    const updatedAt = new Date().toISOString();
    const updates = { rating, ratingFeedback: feedback, updatedAt };
    setRides((prev) => prev.map((r) => (r.id === rideId ? { ...r, ...updates } : r)));

    try {
      await updateDoc(doc(db, 'rides', rideId), updates);
    } catch {
      // Handled locally
    }
  };

  // Driver Registration helper
  const registerDriver = async (data: Partial<Driver>): Promise<Driver> => {
    const newId = `user_driver_${Date.now()}`;
    const newDriver: Driver = {
      id: newId,
      name: data.name || 'New Maya Captain',
      email: data.email || `captain_${Date.now()}@mayaride.in`,
      phone: data.phone || '+91 98390 00000',
      vehicleType: data.vehicleType || 'bike',
      vehicleModel: data.vehicleModel || 'Standard Vehicle',
      vehicleNumber: data.vehicleNumber || 'UP-96-XX-0000',
      licenseNumber: data.licenseNumber || 'UP96202400000',
      documentStatus: 'pending',
      approvalStatus: 'pending',
      isOnline: false,
      rating: 5.0,
      totalTrips: 0,
      totalEarnings: 0,
      todayEarnings: 0,
      monthEarnings: 0,
      walletBalance: 0,
      createdAt: new Date().toISOString(),
      avatar:
        data.avatar ||
        'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
    };

    setDrivers((prev) => [newDriver, ...prev]);

    const driverUser: User = {
      id: newId,
      name: newDriver.name,
      email: newDriver.email,
      phone: newDriver.phone,
      role: 'driver',
      avatar: newDriver.avatar,
      status: 'pending',
      walletBalance: 0,
      totalRides: 0,
      createdAt: newDriver.createdAt,
    };
    setUsers((prev) => [driverUser, ...prev]);
    setCurrentUser(driverUser);

    try {
      await setDoc(doc(db, 'drivers', newId), newDriver);
      await setDoc(doc(db, 'users', newId), driverUser);
    } catch {
      // Handled locally
    }

    return newDriver;
  };

  // Admin: Approve driver
  const approveDriver = async (driverId: string) => {
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, approvalStatus: 'approved' } : d))
    );
    setUsers((prev) =>
      prev.map((u) => (u.id === driverId ? { ...u, status: 'active' } : u))
    );

    sendAppNotification({
      userId: driverId,
      role: 'driver',
      title: 'Account Approved!',
      body: 'Your Maya Captain account has been approved by Admin. You can now switch ON duty!',
      type: 'admin_alert',
    });

    try {
      await updateDoc(doc(db, 'drivers', driverId), { approvalStatus: 'approved' });
      await updateDoc(doc(db, 'users', driverId), { status: 'active' });
    } catch {
      // Handled locally
    }
  };

  // Admin: Reject driver
  const rejectDriver = async (driverId: string, reason?: string) => {
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, approvalStatus: 'rejected', isOnline: false } : d))
    );
    sendAppNotification({
      userId: driverId,
      role: 'driver',
      title: 'Captain Approval Revoked / Rejected',
      body: reason || 'Your captain approval status was updated by Maya Admin.',
      type: 'admin_alert',
    });
    try {
      await updateDoc(doc(db, 'drivers', driverId), { approvalStatus: 'rejected', isOnline: false });
    } catch {
      // Handled locally
    }
  };

  // In-App Notification Dispatcher
  const sendAppNotification = (notif: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) => {
    const newNotif: AppNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      read: false,
      ...notif,
    };
    setNotifications((prev) => [newNotif, ...prev.slice(0, 49)]);
    try {
      setDoc(doc(db, 'notifications', newNotif.id), newNotif);
    } catch {
      // Local fallback
    }
  };

  const markNotificationRead = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n))
    );
    try {
      updateDoc(doc(db, 'notifications', notificationId), { read: true }).catch(() => {
        // Local fallback
      });
    } catch {
      // Local fallback
    }
  };

  // Top Up User Wallet Balance
  const topUpWallet = async (amount: number, method: 'upi' | 'card' | 'netbanking' = 'upi') => {
    if (amount <= 0) return;
    const newBal = (currentUser.walletBalance || 0) + amount;
    const updatedUser = { ...currentUser, walletBalance: newBal };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));

    const txn: WalletTransaction = {
      id: `TXN-W-${Date.now().toString().slice(-6)}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      amount,
      type: 'credit',
      category: 'wallet_topup',
      status: 'completed',
      description: `Wallet recharge via ${method.toUpperCase()}`,
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [txn, ...prev]);

    sendAppNotification({
      userId: currentUser.id,
      role: 'customer',
      title: 'Wallet Recharged',
      body: `₹${amount} added successfully to your Maya Wallet. New balance: ₹${newBal}`,
      type: 'payment',
    });

    try {
      await updateDoc(doc(db, 'users', currentUser.id), { walletBalance: newBal });
      await setDoc(doc(db, 'transactions', txn.id), txn);
    } catch {
      // Local fallback
    }
  };

  // Driver Payout Request
  const requestDriverPayout = async (driverId: string, amount: number) => {
    const driver = drivers.find((d) => d.id === driverId);
    if (!driver || driver.walletBalance < amount) {
      throw new Error('Insufficient driver wallet balance for payout.');
    }

    const newDriverBal = driver.walletBalance - amount;
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, walletBalance: newDriverBal } : d))
    );

    const txn: WalletTransaction = {
      id: `PAYOUT-${Date.now().toString().slice(-6)}`,
      userId: driver.id,
      userName: driver.name,
      userRole: 'driver',
      amount,
      type: 'debit',
      category: 'driver_payout',
      status: 'completed',
      description: `Instant payout transfer to captain UPI/Bank account`,
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [txn, ...prev]);

    sendAppNotification({
      userId: driver.id,
      role: 'driver',
      title: 'Payout Dispatched',
      body: `Payout of ₹${amount} initiated to your bank account. Remaining balance: ₹${newDriverBal}`,
      type: 'payment',
    });

    try {
      await updateDoc(doc(db, 'drivers', driverId), { walletBalance: newDriverBal });
      await setDoc(doc(db, 'transactions', txn.id), txn);
    } catch {
      // Local fallback
    }
  };

  // Upload and attach driver document
  const uploadAndSetDriverDocument = async (
    driverId: string,
    file: File,
    docType: 'license' | 'rc' | 'insurance'
  ): Promise<string> => {
    const downloadUrl = await uploadDriverDocument(driverId, file, docType);
    const updates: Partial<Driver> = {
      documentStatus: 'pending',
      ...(docType === 'license' ? { licenseDocUrl: downloadUrl } : {}),
      ...(docType === 'rc' ? { vehicleRcDocUrl: downloadUrl } : {}),
      ...(docType === 'insurance' ? { insuranceDocUrl: downloadUrl } : {}),
    };

    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, ...updates } : d))
    );

    sendAppNotification({
      userId: driverId,
      role: 'driver',
      title: 'Document Uploaded',
      body: `Your ${docType.toUpperCase()} document was uploaded and is undergoing admin verification.`,
      type: 'admin_alert',
    });

    try {
      await updateDoc(doc(db, 'drivers', driverId), updates);
    } catch {
      // Local fallback
    }

    return downloadUrl;
  };

  // Admin Document Verification
  const verifyDriverDocument = async (
    driverId: string,
    status: 'verified' | 'rejected',
    reason?: string
  ) => {
    const updates: Partial<Driver> = {
      documentStatus: status,
      documentRejectionReason: reason || undefined,
      ...(status === 'verified' ? { approvalStatus: 'approved' } : {}),
    };

    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, ...updates } : d))
    );

    if (status === 'verified') {
      setUsers((prev) =>
        prev.map((u) => (u.id === driverId ? { ...u, status: 'active' } : u))
      );
    }

    sendAppNotification({
      userId: driverId,
      role: 'driver',
      title: status === 'verified' ? 'Documents Verified!' : 'Document Review Notice',
      body:
        status === 'verified'
          ? 'Your driving licence & RC have been verified. You may now go ON DUTY!'
          : `Document review failed: ${reason || 'Please upload clearer official documents.'}`,
      type: 'admin_alert',
    });

    try {
      await updateDoc(doc(db, 'drivers', driverId), updates);
      if (status === 'verified') {
        await updateDoc(doc(db, 'users', driverId), { status: 'active' });
      }
    } catch {
      // Local fallback
    }
  };

  // Block / Unblock User or Driver Account
  const toggleAccountBlock = async (userId: string, isBlocked: boolean) => {
    const nextStatus = isBlocked ? 'blocked' : 'active';
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: nextStatus } : u))
    );
    setDrivers((prev) =>
      prev.map((d) =>
        d.id === userId
          ? {
              ...d,
              approvalStatus: isBlocked ? 'rejected' : 'approved',
              isOnline: isBlocked ? false : d.isOnline,
            }
          : d
      )
    );

    try {
      await updateDoc(doc(db, 'users', userId), { status: nextStatus });
      const drv = drivers.find((d) => d.id === userId);
      if (drv) {
        await updateDoc(doc(db, 'drivers', userId), {
          approvalStatus: isBlocked ? 'rejected' : 'approved',
          isOnline: isBlocked ? false : drv.isOnline,
        });
      }
    } catch {
      // Local fallback
    }
  };

  // Customer: File support complaint
  const fileComplaint = async (data: {
    rideId?: string;
    driverName?: string;
    category: CustomerComplaint['category'];
    subject: string;
    details: string;
  }): Promise<CustomerComplaint> => {
    const complaintId = `TICKET-${Math.floor(1000 + Math.random() * 9000)}`;
    const nowIso = new Date().toISOString();
    const newComplaint: CustomerComplaint = {
      id: complaintId,
      rideId: data.rideId,
      customerId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      driverName: data.driverName,
      category: data.category,
      subject: data.subject.trim(),
      details: data.details.trim(),
      status: 'open',
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setComplaints((prev) => [newComplaint, ...prev]);

    sendAppNotification({
      userId: currentUser.id,
      role: 'customer',
      title: 'Ticket Created',
      body: `Your grievance (${complaintId}) has been logged. Maya Support is reviewing it.`,
      type: 'admin_alert',
    });

    try {
      await setDoc(doc(db, 'complaints', complaintId), newComplaint);
    } catch {
      // Local fallback
    }

    return newComplaint;
  };

  // Admin: Update complaint status & issue resolution / refund
  const updateComplaintStatus = async (
    complaintId: string,
    status: CustomerComplaint['status'],
    resolutionNote?: string,
    refundAmount?: number
  ) => {
    const resolvedAt = new Date().toISOString();
    const existingC = complaints.find((c) => c.id === complaintId);

    setComplaints((prev) =>
      prev.map((c) =>
        c.id === complaintId
          ? {
              ...c,
              status,
              resolutionNote: resolutionNote || c.resolutionNote,
              refundIssued: refundAmount ?? c.refundIssued,
              updatedAt: resolvedAt,
            }
          : c
      )
    );

    // If refund was granted, credit customer's wallet
    if (refundAmount && refundAmount > 0 && existingC) {
      setUsers((prev) =>
        prev.map((u) =>
          u.id === existingC.customerId
            ? { ...u, walletBalance: (u.walletBalance || 0) + refundAmount }
            : u
        )
      );

      const refundTxn: WalletTransaction = {
        id: `REFUND-${Date.now().toString().slice(-6)}`,
        userId: existingC.customerId,
        userName: existingC.customerName,
        userRole: 'customer',
        rideId: existingC.rideId,
        amount: refundAmount,
        type: 'credit',
        category: 'refund',
        status: 'completed',
        description: `Dispute refund for ${complaintId}: ${resolutionNote || 'Settlement'}`,
        createdAt: resolvedAt,
      };
      setTransactions((prev) => [refundTxn, ...prev]);

      sendAppNotification({
        userId: existingC.customerId,
        role: 'customer',
        title: 'Refund Credited',
        body: `₹${refundAmount} has been refunded to your Maya Wallet for ticket ${complaintId}.`,
        type: 'payment',
      });
    }

    try {
      await updateDoc(doc(db, 'complaints', complaintId), {
        status,
        resolutionNote: resolutionNote || null,
        refundIssued: refundAmount || null,
        updatedAt: resolvedAt,
      });
    } catch {
      // Local fallback
    }
  };

  // Driver Daily Report Generator
  const getDriverDailySummary = (driverId: string) => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const todayTrips = rides.filter(
      (r) =>
        r.driverId === driverId &&
        r.status === 'completed' &&
        r.createdAt.startsWith(todayStr)
    );

    const grossFare = todayTrips.reduce((acc, r) => acc + r.fare, 0);
    const commission = todayTrips.reduce((acc, r) => acc + r.platformFee, 0);
    const netEarnings = grossFare - commission;
    const ratedTrips = todayTrips.filter((r) => r.rating);
    const avgRating =
      ratedTrips.length > 0
        ? Number(
            (ratedTrips.reduce((acc, r) => acc + (r.rating || 5), 0) / ratedTrips.length).toFixed(1)
          )
        : 4.9;

    return {
      trips: todayTrips.length,
      grossFare,
      netEarnings,
      commission,
      avgRating,
    };
  };

  // Driver Monthly Report Generator
  const getDriverMonthlySummary = (driverId: string) => {
    const monthStr = new Date().toISOString().slice(0, 7);
    const monthTrips = rides.filter(
      (r) =>
        r.driverId === driverId &&
        r.status === 'completed' &&
        r.createdAt.startsWith(monthStr)
    );

    const grossFare = monthTrips.reduce((acc, r) => acc + r.fare, 0);
    const commission = monthTrips.reduce((acc, r) => acc + r.platformFee, 0);
    const netEarnings = grossFare - commission;

    return {
      trips: monthTrips.length,
      grossFare,
      netEarnings,
      commission,
    };
  };

  // Driver: Toggle online status (only approved drivers can go online)
  const toggleDriverOnline = async (driverId: string, isOnline: boolean) => {
    const driver = drivers.find((d) => d.id === driverId);
    if (driver && driver.approvalStatus !== 'approved' && isOnline) {
      sendAppNotification({
        userId: driverId,
        role: 'driver',
        title: 'Approval Required',
        body: 'Your captain account is pending admin verification and cannot go online yet.',
        type: 'admin_alert',
      });
      return;
    }

    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, isOnline } : d))
    );
    try {
      await updateDoc(doc(db, 'drivers', driverId), { isOnline });
    } catch {
      // Handled locally
    }
  };

  // Admin: Update Fare & Commission
  const updateFareSetting = async (vehicleType: VehicleType, updates: Partial<FareSetting>) => {
    const updatedAt = new Date().toISOString();
    setFareSettings((prev) =>
      prev.map((f) => (f.vehicleType === vehicleType ? { ...f, ...updates, updatedAt } : f))
    );

    try {
      const docId = `fare_${vehicleType}`;
      await updateDoc(doc(db, 'fareSettings', docId), { ...updates, updatedAt });
    } catch {
      // Handled locally
    }
  };

  // Admin: Toggle user status
  const toggleUserStatus = async (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const nextStatus = u.status === 'active' ? 'blocked' : 'active';
          return { ...u, status: nextStatus };
        }
        return u;
      })
    );
  };

  // Reset demo data
  const resetToDemoData = () => {
    setRides(DEFAULT_RIDES);
    setDrivers(DEFAULT_DRIVERS);
    setUsers(DEFAULT_USERS);
    setFareSettings(DEFAULT_FARE_SETTINGS);
    setComplaints(DEFAULT_COMPLAINTS);
    setTransactions(DEFAULT_TRANSACTIONS);
    setNotifications(DEFAULT_NOTIFICATIONS);
    setCurrentUser(DEFAULT_USERS[0]);
    saveCachedRides(DEFAULT_RIDES);
    saveCachedDrivers(DEFAULT_DRIVERS);
    saveCachedUsers(DEFAULT_USERS);
    saveCachedFares(DEFAULT_FARE_SETTINGS);
    saveCachedComplaints(DEFAULT_COMPLAINTS);
    saveCachedTransactions(DEFAULT_TRANSACTIONS);
    saveCachedNotifications(DEFAULT_NOTIFICATIONS);
  };

  return (
    <RideContext.Provider
      value={{
        activePanel,
        setActivePanel,
        currentUser,
        setCurrentUser,
        firebaseUser,
        authLoading,
        rides,
        drivers,
        users,
        fareSettings,
        activeDriver,
        isAdminAuthenticated,
        complaints,
        transactions,
        notifications,
        fcmToken,
        registerCustomer,
        loginCustomer,
        loginWithPhoneOtp,
        loginWithGoogle,
        registerDriverAccount,
        loginDriverAccount,
        loginAdminAccount,
        logoutAccount,
        updateCustomerProfile,
        updateDriverProfile,
        uploadAndSetDriverDocument,
        verifyDriverDocument,
        switchRole,
        calculateFare,
        bookRide,
        cancelRide,
        acceptRide,
        rejectRide,
        updateRideStatus,
        rateRide,
        registerDriver,
        approveDriver,
        rejectDriver,
        toggleDriverOnline,
        updateFareSetting,
        toggleUserStatus,
        toggleAccountBlock,
        topUpWallet,
        requestDriverPayout,
        fileComplaint,
        updateComplaintStatus,
        sendAppNotification,
        markNotificationRead,
        getDriverDailySummary,
        getDriverMonthlySummary,
        resetToDemoData,
      }}
    >
      {children}
    </RideContext.Provider>
  );
};

export const useRide = (): RideContextType => {
  const context = useContext(RideContext);
  if (!context) {
    throw new Error('useRide must be used within a RideProvider');
  }
  return context;
};
