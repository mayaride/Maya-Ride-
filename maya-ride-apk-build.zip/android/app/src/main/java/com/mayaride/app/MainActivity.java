package com.mayaride.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
